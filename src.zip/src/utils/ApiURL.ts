import { getAmbiente } from 'core-lib';
import { environment } from '../environments/environment';

export const domain = getAmbiente();
export const server = environment.baseUrl;

// EndPoints
export const baseURL = server + domain;
export const parApiUrl = baseURL + environment.sccParApi;
export const rseExtUrl = baseURL + environment.sliRseExtApi;
export const ddjjExtUrl = baseURL + environment.scnDdjjExtApi;
