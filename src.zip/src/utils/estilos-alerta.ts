export class EstilosAlerta {
  static readonly CSS_SUCCESS = 'success-snackbar';
  static readonly CSS_ERROR = 'error-snackbar';
  static readonly CSS_WARNING = 'warning-snackbar';
  static readonly CSS_INFO = 'info-snackbar';
}
