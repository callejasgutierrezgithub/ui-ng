export const environment = {
  production: true,
  title: 'Produccion',
  environmentName: 'produccion',

  baseUrl: '',
  sccParApi: '/scc-par-ext-rest',
  sliRseExtApi: '/sli-rse-ext-rest',
  scnDdjjExtApi: '/scn-ddjj-ext-rest',
};