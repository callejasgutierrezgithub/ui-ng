export const environment = {
  production: false,
  title: 'Local',
  environmentName: 'desarrollo',

  baseUrl: 'https://desasiatservicios.impuestos.gob.bo',

  sccParApi: '/scc-par-ext-rest',
  sliRseExtApi: '/sli-rse-ext-rest',
  scnDdjjExtApi: '/scn-ddjj-ext-rest',
};
