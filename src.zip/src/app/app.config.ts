import localeEs from '@angular/common/locales/es';
import { ApplicationConfig, importProvidersFrom, LOCALE_ID, provideZoneChangeDetection } from '@angular/core';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { MaterialModule, ToastrConfig } from 'core-lib';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { StrAuthLibModule } from 'str-auth-lib';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { provideRouter, withInMemoryScrolling, withViewTransitions } from '@angular/router';
import { routes } from './app.routes';
import { registerLocaleData } from '@angular/common';

registerLocaleData(localeEs);

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes,
      withViewTransitions({
        onViewTransitionCreated() { },
      }),
      withInMemoryScrolling({
        scrollPositionRestoration: 'enabled',
        anchorScrolling: 'enabled',
      }),
    ),
    provideAnimationsAsync(),
    importProvidersFrom(
      StrAuthLibModule.forRoot({ login: true, realm: 'login2' }),  //login (True) para mostrar el login con el service DatosAuthServerService; login (False) para no tener login con service DatosAuthLocalService
      MaterialModule,
      NgScrollbarModule,
      FormsModule,
      ReactiveFormsModule,
      ...ToastrConfig,
    ), provideAnimationsAsync(), provideAnimationsAsync(),
    { provide: LOCALE_ID, useValue: 'es-ES' },
  ],
};
