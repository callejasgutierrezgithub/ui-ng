import { RespuestaLista } from "core-lib";


export interface ComponenteDocumentoAgrupadorModel {
  impuestoId: Number;
  documentoId: number;
  formularioId: Number;
  numeroOrden: Number;
  periodo: number;
  anio: number;
  tributo: number;
  sancion: number;
  agravante: number;
  multaUfv: number;
  deudaId: number;
  //numeroDeuda:number;
}

export interface ListaComponenteDocAgrupadorTableModel
  extends ComponenteDocumentoAgrupadorModel {}

export interface RepuestaListaComponenteDocumentoAgrupador
  extends RespuestaLista<ComponenteDocumentoAgrupadorModel> {}
export interface RepuestaComponenteDocAgrupadoresModel
  extends ComponenteDocumentoAgrupadorModel {}
