export interface DeudaGenericaDetalle {
  impuestoId: number;
  documentoId: number;
  formularioId: number;
  numeroOrdenDocumento: number;
  periodo: number;
  anio: number;
  multaUfv: number;
  deudaId: number;
  sancionBs: number;
  agravanteBs: number;
  montoDeudaBs: number;
  deudaTotalBs: number;
  montoDeudaUfv: number;
  deudaTotalUfv: number;
  mantenimientoValorBs: number;
  tributoOmitido: number;
  interesBs: number;    
  multaBs: number;    
}

export interface ListaDeudaGenericaDetalleTableModel
  extends DeudaGenericaDetalle {}