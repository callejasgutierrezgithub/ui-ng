import { Respuesta } from 'core-lib';
import { DeudaGenericaDetalle } from './deuda-generica-detalle.model';

export interface RespuestaDetalleDeudas extends Respuesta {
  data: Array<DeudaGenericaDetalle>;
}
