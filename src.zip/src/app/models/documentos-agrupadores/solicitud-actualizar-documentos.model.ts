import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudActualizarDocumentos {
  nitCur: number;
  nuevoDocumentoAgrupadorId: number;
  nuevoNumeroOrdenAgrupador: number;
  nuevaFechaNotificacion: LocalDate | null;
  tramiteId: number;
  origenId: number;
  oficinaId: number;
  dependencia?: string;
  dependenciaId?: number;
  deudas: Array<number>;
}
