import { RespuestaLista } from "core-lib";
import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface DocumentoAgrupadorModel {
  nitCur: number;
  procesoId: number;
  documentoAgrupadorId: number;
  numeroOrdenAgrupador: number;
  fechaNotificacion?: LocalDate | null;
}

export interface ListaDocumentosAgrupadoresTableModel extends DocumentoAgrupadorModel {

}

export interface RepuestaListaDocumentosAgrupadoresModel extends RespuestaLista<DocumentoAgrupadorModel>{

}
export interface RepuestaDocumentosAgrupadoresModel extends DocumentoAgrupadorModel{

}
