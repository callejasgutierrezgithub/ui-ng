import { RespuestaLista } from "core-lib";

export interface ImpuestoModel {
  impuesto: number;
  sigla: string;
  descripcion: string;
}

export interface ListaImpuestoTableModel extends ImpuestoModel {
}
export interface RepuestaListaImpuestoModel extends RespuestaLista<ImpuestoModel>{
  formularios:Array<ImpuestoModel>;
}