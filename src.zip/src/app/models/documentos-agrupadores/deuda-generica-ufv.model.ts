import { Respuesta } from "core-lib";

export interface DeudaGenericaUfvModel {
 impuestoId:number;
 documentoId:number;
 formularioId:number;
 numeroOrdenDocumento:number;
 periodo:number;
 anio:number;
 multaUfv:number;
 numeroDeuda:number;
}

export interface ListaDeudasGenericaUfvTableModel extends DeudaGenericaUfvModel {

}

export interface RepuestaListaDeudasGenericaModel extends Respuesta{
  registro: Array<DeudaGenericaUfvModel>;
}
export interface RepuestaDeudaGenericaUfvModel{
  
}
export interface RespuestaDeudasUfv{   //lista de objetos de tu tabla
  deudasUfv?:DeudaGenericaUfvModel[];
}