import { Respuesta } from 'core-lib';

export interface RespuestaDeudaGenerica extends Respuesta {
  numeroDeuda: number;
}


export interface DeudaMasivaModel {
  numero: number;
  nitCur: number;
  deudaId: number;
  numeroOrdenDocumento: number;
  formularioId: number;
  periodo: number;
  anio: number;
  oficinaId: number;
  montoUfv: number;
  montoBs: number;
}
