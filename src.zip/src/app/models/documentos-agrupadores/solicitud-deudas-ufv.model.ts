import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudDeudaUfv {
  nitCur: number;
  tramiteId: number;
  tipoContribuyenteId: number;
  impuestoId: number;
  formularioId: number;
  impuesto?: string;
  formulario?: string;
  documentoId: number;
  numeroOrdenDocumento: number;
  periodo: number;
  anio: number;
  fechaVencimiento: LocalDate | null;
  fechaNotificacion?: LocalDate | null;
  contravencionId: number;
  asientoId: number;
  procesoId: number;
  origenId: number;
  multaUfv: number;
  oficinaId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  tipoContribuyentePdrId: number;
}

export interface SolicitudXlsxDeudaUfv {
  nitCur: number;
  tramiteId: number;
  tipoContribuyenteId: number;
  impuestoId: number;
  formularioId: number;
  impuesto?: string;
  formulario?: string;
  documentoId: number;
  numeroOrdenDocumento: number;
  periodo: number;
  anio: number;
  fechaVencimiento: string;
  fechaNotificacion: string;
  contravencionId: number;
  asientoId: number;
  procesoId: number;
  origenId: number;
  multaUfv: number;
  oficinaId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  tipoContribuyentePdrId: number;
}