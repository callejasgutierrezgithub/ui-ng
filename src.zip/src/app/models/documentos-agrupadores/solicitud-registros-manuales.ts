export interface SolicitudRegistrosManuales {
  nitCur: number;
  tipoContribuyentePdrId: number;
  documentoAgrupadorId?: number | null;
  numeroOrdenAgrupador?: number | null;
}

export interface SolicitudDeudaMontoCongelarRd {
  nitCur?: number;
  deudaId?: number;
  documentoId?: number;
  documentoAgrupadorId?: number;
  procesoId?: number;
  origenId?: number;
  montoDeudaBs?: number;
} 