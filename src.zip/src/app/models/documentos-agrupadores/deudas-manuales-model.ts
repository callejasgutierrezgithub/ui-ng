import { Respuesta } from "core-lib";

export interface DeudasManualesModel {
  deudaId: number;
  formulario: number;
  periodo: number;
  tributoOmitido: number;
  interes: number;
  sancion: number;
  agravante: number;
  multa: number;
  deudaTotalBs: number;
}

export interface ListaDeudasManualesTableModel extends DeudasManualesModel {}

export interface RepuestaListaDeudasManualesModel extends Respuesta {
  registro: Array<DeudasManualesModel>;
}
export interface RepuestaDeudasManualesModel {}
