import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudDeudaBs {
  nitCur: number;
  tramiteId: number;
  impuestoId: number;
  formularioId: number;
  impuesto?: string;
  formulario?: string;
  documentoId: number;
  numeroOrdenDocumento: number;
  periodo: number;
  anio: number;
  fechaVencimiento?: LocalDate | null;
  fechaNotificacion?: LocalDate | null;
  asientoId: number;
  procesoId: number;
  origenId: number;
  tributoOmitido: number;
  sancionPorcentaje: number;
  agravantePorcentaje: number;
  multaUfv: number;
  oficinaId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  tipoContribuyentePdrId: number;
  monedaId: number;
  moneda: string;
}

export interface SolicitudXlsxDeudaBs {
  nitCur: number;
  tramiteId: number;
  impuestoId: number;
  formularioId: number;
  impuesto?: string;
  formulario?: string;
  documentoId: number;
  numeroOrdenDocumento: number;
  periodo: number;
  anio: number;
  fechaVencimiento: string;
  fechaNotificacion: string;
  asientoId: number;
  procesoId: number;
  origenId: number;
  tributoOmitido: number;
  sancionPorcentaje: number;
  agravantePorcentaje: number;
  multaUfv: number;
  oficinaId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  tipoContribuyentePdrId: number;
  monedaId: number;
  moneda: string;
}