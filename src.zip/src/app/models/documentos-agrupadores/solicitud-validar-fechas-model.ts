import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudValidarFecha {
    fecha?: LocalDate | null;
    administracionId: Number;
  }

export interface SolicitudValidarFechas{
  fechas: Array<SolicitudValidarFecha>
}
export interface SolicitudValidarNitCur{
  nitCurs: Array<Number>
}