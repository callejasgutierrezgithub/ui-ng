import { RespuestaLista } from "core-lib";

export interface FormularioModel {
  formulario: number;
  version: number;
  descripcion: number;
  periocidad: number;
}

export interface ListaFormularioTableModel extends FormularioModel {
}
export interface RepuestaListaFormularioModel extends RespuestaLista<FormularioModel>{
  formularios:Array<FormularioModel>;
}
