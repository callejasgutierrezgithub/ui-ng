export interface SolicitudDeudasManualesModel {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  procesoId?: number;
  documentoAgrupadorId?: number;
  numeroOrdenAgrupador?: number;  
}
