import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudDocumentoAgrupadores {
    nitCur: number;
    tipoContribuyentePdrId: number;
    procesoId: number;
    documentoAgrupadorId: number;
    numeroOrdenAgrupador:number;
    fechaNotificacion?: LocalDate | null;
  }