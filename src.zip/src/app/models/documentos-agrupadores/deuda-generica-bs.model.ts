import { Respuesta } from "core-lib";

export interface DeudaGenericaBsModel {
 impuestoId:number;
 documentoId:number;
 formularioId:number;
 numeroOrdenDocumento:number;
 periodo:number;
 anio:number;
 tributoOmitido:number;
 sancion:number;
 agravante:number;
 numeroDeuda:number;
}

export interface ListaDeudasGenericaBsTableModel extends DeudaGenericaBsModel {

}

export interface RepuestaListaDeudasGenericaModel extends Respuesta{
  registro: Array<DeudaGenericaBsModel>;
}
export interface RepuestaDeudaGenericaBsModel{
  
}