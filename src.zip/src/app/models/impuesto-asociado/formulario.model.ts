import { Respuesta } from "core-lib";


export interface FormularioModel {
  id?: number;
  descripcionLarga?: string;    
  formulario?: number;
  version?: number;
  formularioDescripcion?: string;
  descripcion?: string;
}

export interface RespuestaFormulario extends Respuesta {
  objetosList: Array<FormularioModel>;
}
export interface RespuestaFormularioDdjj extends Respuesta {
  formularios: Array<FormularioModel>;
}
