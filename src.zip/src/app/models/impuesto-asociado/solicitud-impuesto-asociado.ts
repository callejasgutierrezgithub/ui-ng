export interface SolicitudImpuestoAsociado {
  ifc?: number;
  fechaDesde: string;
  fechaHasta: string;
}