import { Respuesta } from "core-lib";


export interface ImpuestoModel {
  id?: number;
  impuesto?: number;
  descripcion?: string;
  descripcionLarga?: string;
  sigla?: string;  
}

export interface RespuestaImpuestos extends Respuesta {
  objetosList: Array<ImpuestoModel>;
}
