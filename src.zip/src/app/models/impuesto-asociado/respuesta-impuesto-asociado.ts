import { Respuesta } from 'core-lib';
import { ImpuestoAsociadoModel } from './impuesto-asociado.model';

export interface RespuestaImpuestoAsociado extends Respuesta {
  data: Array<ImpuestoAsociadoModel>;
}
