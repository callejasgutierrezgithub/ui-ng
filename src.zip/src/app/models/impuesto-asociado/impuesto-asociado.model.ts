export interface ImpuestoAsociadoModel {
  impuesto?: number;
  formulario?: string;
}
