import { UserInfo } from "str-auth-lib";

export interface UserInfoModel {
    userInfo?: UserInfo;
}