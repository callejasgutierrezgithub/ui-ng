export interface BolsaCreditoExternoUsosModel {
    id?: number;
    nitCur?: number;
    tipoContribuyentePdrId?: number;
    bolsaCreditoExternoId?: number;
    deudaId?: number;
    liquidacionId?: number;
    periodoOrigen?: number;
    anioOrigen?: number;
    periodoDestino?: number;
    anioDestino?: number;
    tipoUsoCreditoId?: number;
    montoCreditoBs?: number;
    estadoBolsaId?: number;
    fechaRegistro?: string;
}

export interface SolicitudBolsaCreditosExternoUsos {     
    nitCur?: number;
    tipoContribuyentePdrId?: number;
    creditoExternoId?: number;
}