import { Respuesta } from 'core-lib';

export interface BolsaRcIvaModel {
  nitCur?: number;
  bolsaRcIvaId?: number;
  deudaId?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  tipoCreditoId?: number;
  creditoRcivaBs?: number;
  saldoCreditoRcivaBs?: number;
  monedaId?: number;
}

export interface RespuestaBolsaRcIva extends Respuesta {
  objetosList: Array<BolsaRcIvaModel>;
}

export interface BolsaRcIvaUsosModel {
  nitCur?: number;
  bolsaRcivaUsoId?: number;
  deudaId?: number;
  periodoOrigen?: number;
  anioOrigen?: number;
  periodoUso?: number;
  anioUso?: number;
  formularioId?: number;
  creditoRcivaBs?: number;
  saldoCreditoRcivaBs?: number;
  monedaId?: number;
}

export interface RespuestaBolsaRcIvaUsosModel extends Respuesta {
  objetosList: Array<BolsaRcIvaUsosModel>;
}


export interface SolicitudBolsaRcIvaUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaRcivaId?: number;
}