import { Respuesta } from "core-lib";

export interface BolsaValoresSaldosDetallesModel {
  valoresSaldoDetalleId?: number;
  valoresId?: number;
  nitCur?: number;
  ufvFechaActualizacion?: number;
  impuestoId?: number;
  monedaId?: number;
  montoBs?: number;
  montoUfv?: number;
  saldoBs?: number;
  saldoUfv?: number;
  estadoDetalleValorId?: number;
  deudaId?: number;
  oficinaId?: number;
  documentoId?: number;
  numeroOrdenDocumento?: number;
  documentoAgrupadorId?: number;
  numeroOrdenAgrupador?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  numeroAsiento?: number;   
  }

  export interface RespuestaBolsaValoresSaldosDetalles  extends Respuesta {
    objetosList?: Array<BolsaValoresSaldosDetallesModel>;
  }