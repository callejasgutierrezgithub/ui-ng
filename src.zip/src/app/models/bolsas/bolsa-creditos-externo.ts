export interface BolsaCreditoExternoModel {
    id?: number;
    nitCur?: number;
    tipoContribuyentePdrId?: number;
    deudaId?: number;
    liquidacionId?: number;
    monedaId?: number;
    tipoMontoCreditoId?: number;
    periodo?: number;
    anio?: number;
    formularioId?: number;
    creditoExternoBs?: number;
    saldoCreditoExternoBs?: number;
    tipoCambio?: number;
    casillaConceptoId?: number;
    estadoBolsaId?: number;
    fechaRegistro?: string;
}