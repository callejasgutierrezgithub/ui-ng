import { Respuesta } from 'core-lib';

export interface SieteRgModel {
  id?: number;
  nitCur?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  impuestoId?: number;
  montoBs?: number;
  saldoMontoBs?: number;
  tipoCambio?: number;
  monedaId?: number;
  numeroAsiento?: number;
  tipoSietergId?: number;
  estadoBolsaId?: number;
}

export interface RespuestaSieteRg extends Respuesta {
  objetosList?: Array<SieteRgModel>;
}
