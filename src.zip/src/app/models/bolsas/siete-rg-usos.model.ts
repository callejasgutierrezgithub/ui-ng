import { Respuesta } from 'core-lib';

export interface SieteRgUsosModel {
  bolsaSietergUsoId?: number;
  bolsaSietergId?: number;
  periodoUso?: number;
  anioUso?: number;
  impuestoId?: number;
  asientoId?: number;
  ddjjUsoId?: number;
  deudaId?: number;
  montoBs?: number;
  estadoBolsaUsosId?: number;
}

export interface RespuestaSieteRgUsos extends Respuesta {
  objetosList?: Array<SieteRgUsosModel>;
}

export interface SolicitudSieteRgUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaSietergId?: number;
}
