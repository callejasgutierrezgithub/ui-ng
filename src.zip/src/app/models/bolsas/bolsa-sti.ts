export interface BolsaStiModel {
  bolsaStiId?: number;
  nitCur?: number;
  tipoPdrId?: number;
  deudaId?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  montoBs?: number;
  saldoBs?: number;
  estadoBolsaId?: number;
}

export interface BolsaStiUsosModel {
  nitCur?: number;
  tipoPdrId?: number;
  deudaId?: number;
  bolsaStiId?: number;
  periodoOrigen?: number;
  anioOrigen?: number;
  periodoUso?: number;
  anioUso?: number;
  numeroAsiento?: number;
  montoBs?: number;
  estadoBolsaId?: number;
}

export interface SolicitudBolsaStiUso {
  nitCur?: number;
  tipoPdrId?: number;
  bolsaStiId?: number;
}
