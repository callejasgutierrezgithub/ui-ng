import { Respuesta } from 'core-lib';

export interface CompensacionesIdhUsosModel {
  bolsaCompensacionUsoId?: number;
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaCompensacionId?: number;
  periodoOrigen?: number;
  anioOrigen?: number;
  periodoUso?: number;
  anioUso?: number;
  mantenimientoValorBs?: number;
  numeroAsiento?: number;
  ddjjId?: number;
  deudaId?: number;
  compensacionBs?: number;
  estadoBolsaId?: number;
  monedaId?: number;
  tipoCambio?: number;

  usuarioRegistroId?: number;
  usuarioUltimaModificacionId?: number;
  fechaRegistro?: number;
  fechaUltimaModificacion?: number;
  estadoId?: number;
}

export interface SolicitudCompensacionIhdUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaCompensacionId?: number;
}

export interface RespuestaCompensacionesIdhUsos extends Respuesta {
  objetosList: Array<CompensacionesIdhUsosModel>;
}
