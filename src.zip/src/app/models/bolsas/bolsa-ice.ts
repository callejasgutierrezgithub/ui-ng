export interface BolsaIceModel {
  bolsaIceId?: number;
  nitCur?: number;
  deudaId?: number;
  tipoPdrId?: number;
  periodo?: number;
  anio?: number;
  montoBs?: number;
  saldoBs?: number;
  formularioId?: number;
  estadoBolsaId?: number;
}

export interface BolsaIceUsosModel {
  nitCur?: number;
  tipoPdrId?: number;
  bolsaIceId?: number;
  periodoOrigen?: number;
  anioOrigen?: number;
  periodoUso?: number;
  anioUso?: number;
  numeroAsiento?: number;
  deudaId?: number;
  montoBs?: number;
  estadoBolsaId?: number;
}

export interface SolicitudBolsaIceUso {
  nitCur?: number;
  tipoPdrId?: number;
  bolsaIceId?: number;
}
