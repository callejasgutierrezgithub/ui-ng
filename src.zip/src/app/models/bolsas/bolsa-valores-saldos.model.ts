import { Respuesta } from "core-lib";

export interface BolsaValoresSaldosModel {
  valoresId?: number;
  nitCur?: number;
  ufvFechaActualizacion?: number;
  montoBs?: number;
  montoUfv?: number;
  estadoValorId?: number;
  tramiteId?: number;
  nroOrdenRedencion?: number;
  valoresTramiteId?: number;
  tipoValorId?: number;
  numeroEmision?: number;
  saldo?: number;
  formularioRedencion?: number;
  impuestos?: number;   
}

export interface RespuestaBolsaValoresSaldos  extends Respuesta {
  objetosList?: Array<BolsaValoresSaldosModel>;
}