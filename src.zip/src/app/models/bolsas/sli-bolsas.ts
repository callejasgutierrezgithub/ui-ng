import { Respuesta } from "core-lib";
import { BolsaCreditosModel } from "./bolsa-creditos";
import { BolsaRcIvaModel } from "./bolsa-rc-iva";
import { BolsaIueModel } from "./bolsa-iue";
import { BolsaPagosModel } from "./bolsa-pagos";
import { BolsaCreditoExternoModel } from "./bolsa-creditos-externo";
import { BolsaFapModel } from "./bolsa-fap";
import { SieteRgModel } from "./siete-rg.model";
import { BolsaPagosExcesosModel } from "./bolsa-pagos-excesos";
import { ValoresSaldosModel } from "../consulta-valores/valores-saldos.model";
import { BolsaIceModel } from "./bolsa-ice";
import { BolsaStiModel } from "./bolsa-sti";

export interface RespuestaSliBolsas extends Respuesta {
    objeto?: sliBolsas
}

export interface sliBolsas {
    creditosInterno?: BolsaCreditosModel[],
    pagos?: BolsaPagosModel[],
    rcIva?: BolsaRcIvaModel[],
    iue?: BolsaIueModel[],
    creditosExterno?: BolsaCreditoExternoModel[],
    facilidadesPago?: BolsaFapModel[],
    sieteRg?: SieteRgModel[],
    pagosExceso?: BolsaPagosExcesosModel[],
    valoresSaldos?: ValoresSaldosModel[],
    ice?: BolsaIceModel[],
    sti?: BolsaStiModel[],
    // aaIue?: ,
    // compensacionesIdh?: ,
    // saldosPagadosIue?: ,
}