import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface BolsaIueModel {
  pagadoIueId?: number;
  nitCur?: number;
  periodo?: number;
  anio?: number;
  tipoPagoIueId?: number;
  montoIueBs?: number;
  saldoIueBs?: number;
  numeroAsiento?: number;
  ddjjId?: number;
  deudaId?: number;
  fechaVencimiento?: LocalDate;
  fechaRegistro?: LocalDate;
  estadoBolsaId?: number;
}

export interface BolsaIueUsosModel {
  pagadoIueId?: number;
  nitCur?: number;
  periodoIt?: number;
  anioIt?: number;
  montoCompensadoBs?: number;
  ddjjId?: number;
  deudaId?: number;
  estadoBolsaId?: number;
  fechaRegistro?: LocalDate;
}

export interface SolicitudPagadosIueUso {
  nitCur?: number;
  pagadoIueId?: number;
  tipoContribuyentePdrId?: number;
}
