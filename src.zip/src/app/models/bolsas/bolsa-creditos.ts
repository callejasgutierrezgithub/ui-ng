import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface BolsaCreditosModel {
  bolsaCreditoId?: number;
  deudaId?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  tipoCreditoId?: number;
  creditoBs?: number;
  saldoCreditoBs?: number;
  tipoCambio?: number;
  monedaId?: number;
  ddjjId?: number;
  estadoBolsaId?: number;
  fechaRegistro?: LocalDate;
  nitCur?: number;
}

export interface RespuestaBolsaCreditos extends Respuesta {
  objetosList: Array<BolsaCreditosModel>;
}
