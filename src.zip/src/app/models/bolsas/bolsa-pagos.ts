
export interface BolsaPagosModel {   
    id?: number;
    formularioId?: number;
    periodo?: number;
    anio?: number;
    impuestoId?: number;
    tipoPagoCuentaId?: number;
    montoBs?: number;
    saldoPagoCuentaBs?: number;
    tipoCambio?: number;
    ddjjId?: number;
    deudaId?: number;
    monedaId?: number;
    numeroAsiento?: number;
    estadoBolsaId?: number;
    usuarioId?: number;
    nitCur?: number;
}

export interface BolsaPagosUsosModel {
    id?: number;
    bolsaPagoId?: number;
    periodoOrigen?: number;
    anioOrigen?: number;
    anioUso?: number;
    numeroAsiento?: number;
    montoBs?: number;
    estadoBolsaId?: number;
    monedaId?: number;
    tipoUsoPagoCuenta?: number;
}

export interface SolicitudBolsaPagosUsosModel {
    nitCur?: number;
    tipoContribuyentePdrId?: number;
    bolsaPagoId?: number;
}