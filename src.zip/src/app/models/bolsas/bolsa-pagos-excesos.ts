import { Respuesta } from 'core-lib';

export interface BolsaPagosExcesosModel {
  id?: number;
  nitCur?: number;
  formularioId?: number;
  periodo?: number;
  anio?: number;
  impuestoId?: number;
  tipoPagoExcesoId?: number;
  montoExcesoBs?: number;
  saldoExcesoBs?: number;
  tipoCambio?: number;
  ddjjId?: number;
  deudaId?: number;
  monedaId?: number;
  numeroAsiento?: number;
  estadoBolsaId?: number;
  liquidacionId?: number;
  transaccionBancaria?: number;
}

export interface BolsaPagosExcesosUsosModel {
  bolsaExcesoUsoId?: number;
  bolsaExcesoId?: number;
  nitCur?: number;
  deudaId?: number;
  numeroAsiento?: number;
  montoExcesoBs?: number;
  mantenimientoValorBs?: number;
  estadoPagoExcesoId?: number;
  estadoBolsaId?: number;
  tipoCambio?: number;
  monedaId?: number;
}

export interface SolicitudPagosExcesosUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaExcesoId?: number;
}

export interface RespuestaBolsaPagosExcesos extends Respuesta {
  objetosList: Array<BolsaPagosExcesosModel>;
}

export interface RespuestaBolsaPagosExcesosUsos extends Respuesta {
  objetosList: Array<BolsaPagosExcesosUsosModel>;
}
