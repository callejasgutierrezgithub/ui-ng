import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface BolsaCreditosUsosModel {
  nitCur?: number;
  bolsaCreditoId?: number;
  mantenimientoValorBs?: number;
  periodoOrigen?: number;
  anioOrigen?: number;
  periodoUso?: number;
  anioUso?: number;
  numeroAsiento?: number;
  deudaId?: number;
  creditoBs?: number;
  estadoBolsaId?: number;
  fechaRegistro?: LocalDate;
  fechaUltimaModificacion?: LocalDate;
  monedaId?: number;
  estadoId?: string;
  ddjjUsoId?: number;
}

export interface SolicitudBolsaCreditosUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaCreditoId?: number;
}

export interface RespuestaBolsaCreditosUsos extends Respuesta {
  objetosList: Array<BolsaCreditosUsosModel>;
}
