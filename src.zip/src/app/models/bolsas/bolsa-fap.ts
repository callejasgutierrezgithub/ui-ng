import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface BolsaFapModel {
  id?: number;
  nitCur?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;
  impuestoId?: number;
  numeroFap?: number;
  montoBs?: number;
  saldoMontoBs?: number;
  tipoCambio?: number;
  deudaId?: number;
  monedaId?: number;
  numeroAsiento?: number;
  estadoBolsaId?: number;
  fechaRegistro?: LocalDate;
  fechaUltimaModificacion?: LocalDate;
  destinoFapId?: number;
}

export interface BolsaFapUsosModel {
  bolsaFapUsoId?: number;
  bolsaFapId?: number;
  periodoUso?: number;
  anioUso?: number;
  impuestoId?: number;
  asientoId?: number;
  ddjjUsoId?: number;
  deudaId?: number;
  montoFapBs?: number;
  estadoBolsaFapUsosId?: number;
  fechaRegistro?: LocalDate;
  fechaUltimaModificacion?: LocalDate;
}

export interface SolicitudBolsaFapUsos {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  bolsaFapId?: number;
}

export interface RespuestaBolsaFap extends Respuesta {
  objetosList: Array<BolsaFapModel>;
}

export interface RespuestaBolsaFapUsos extends Respuesta {
  objetosList: Array<BolsaFapUsosModel>;
}
