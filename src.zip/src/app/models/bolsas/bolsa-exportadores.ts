import { Respuesta } from "core-lib";
import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface BolsaExportadoresModel {
    bolsaExportadorId?: number;
    nitCur?: number;
    periodo?: number;
    anio?: number;
    tipoCreditoExternoId?: number;
    creditoExternoBs?: number;
    mantenimientoValor?: number;
    saldoCreditoExternoBs?: number;
    tipoCambio?: number;
    ddjjId?: number;
    deudaId?: number;
    monedaId?: number;
    estadoBolsaId?: number;
    fechaRegistro?: LocalDate;
    fechaUltimaModificacion?: LocalDate;
}

export interface BolsaExportadoresUsosModel {
    bolsaExportadorUsoId?: number;
    nitCur?: number;
    bolsaExportadorId?: number;
    periodoOrigen?: number;
    anioOrigen?: number;
    periodoComprometido?: number;
    anioComprometido?: number;
    comprometidoBs?: number;
    periodoSolicitado?: number;
    anioSolicitado?: number;
    solicitadoBs?: number;
    fechaSolicitud?: LocalDate;
    periodoDevolucion?: number;
    anioDevolucion?: number;
    devueltoBs?: number;
    fechaDevuelto?: LocalDate;
    mantenimientoDevuelto?: number;
    restituidoBs?: number;
    mantenimientoRestituido?: number;
    tipoFiscalizacionId?: number;
    depuradoExterno?: number;
    restitucionMercadoExternoBs?: number;
    mantenimientoRestitucionBs?: number;
    pagoDefectoBs?: number;
    numeroAsiento?: number;
    estadoDevolucionId?: number;
    fechaRegistro?: LocalDate;
    fechaUltimaModificacion?: LocalDate;
    restitucionMercadoInternoBs?: number;
    mantenimientoRestitucionInternoBs?: number;
}

export interface RespuestaBolsaExportadores extends Respuesta {
    objetosList: Array<BolsaExportadoresModel>;
}

export interface RespuestaBolsaExportadoresUsos extends Respuesta {
    objetosList: Array<BolsaExportadoresUsosModel>;
}