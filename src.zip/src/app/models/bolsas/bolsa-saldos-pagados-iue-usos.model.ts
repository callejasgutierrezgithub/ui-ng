import { Respuesta } from "core-lib";

export interface BolsaSaldosPagadosIueUsosModel {
    usoIueId?: number;
    pagadoIueId?: number;
    nitCur?: number;
    periodo?: number;
    anio?: number;
    tipoPagoIueId?: number;
    montoIueBs?: number;
    saldoIueBs?: number;
    numeroAsiento?: number;
    ddjjId?: number;
    deudaId?: number;
    estadoBolsaId?: number;   
  }

  export interface RespuestaBolsaSaldosPagadosIueUsos  extends Respuesta {
    objetosList?: Array<BolsaSaldosPagadosIueUsosModel>;
  }