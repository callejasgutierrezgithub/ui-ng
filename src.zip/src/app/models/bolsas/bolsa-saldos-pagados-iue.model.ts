import { Respuesta } from "core-lib";

export interface BolsaSaldosPagadosIueModel {
    pagadoIueId?: number;
    nitCur?: number;
    periodo?: number;
    anio?: number;
    tipoPagoIueId?: number;
    montoIueBs?: number;
    saldoIueBs?: number;
    numeroAsiento?: number;
    ddjjId?: number;
    deudaId?: number;
    estadoBolsaId?: number;   
  }

  export interface RespuestaBolsaSaldosPagadosIue  extends Respuesta {
    objetosList?: Array<BolsaSaldosPagadosIueModel>;
  }