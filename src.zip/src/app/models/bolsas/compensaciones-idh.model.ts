import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface CompensacionesIdhModel {
  bolsaCompensacionId?: number;
  nitCur?: number;
  periodo?: number;
  anio?: number;
  tipoCompensacionId?: number;
  compensacionBs?: number;
  saldoCompensacionBs?: number;
  tipoCambio?: number;
  ddjjId?: number;
  deudaId?: number;
  monedaId?: number;
  estadoBolsaId?: number;

  usuarioRegistroId?: number;
  usuarioUltimaModificacionId?: number;
  fechaRegistro?: number;
  fechaUltimaModificacion?: LocalDate;
  tipoContribuyentePdrId?: LocalDate;
  estadoId?: string;
}

export interface RespuestaCompensacionesIdh extends Respuesta {
  objetosList: Array<CompensacionesIdhModel>;
}
