import { Respuesta } from 'core-lib';
import { BolsaCreditosModel } from './bolsa-creditos';
import { BolsaCreditoExternoModel } from './bolsa-creditos-externo';
import { BolsaExportadoresModel } from './bolsa-exportadores';
import { BolsaFapModel } from './bolsa-fap';
import { BolsaIceModel } from './bolsa-ice';

export interface RespuestaSccBolsasModel extends Respuesta {
  creditoExterno: SccBolsaCreditoExternoModel;
  creditoInterno: SccBolsaCreditosInternoModel;
  fap: SccBolsaFapModel;
  ice: SccBolsaIceModel;
}

export interface SccBolsaCreditosInternoModel {
  bolsa?: Array<BolsaCreditosModel>;
  cantidadRegistros?: number;
}

export interface SccBolsaCreditoExternoModel {
  bolsa?: Array<BolsaCreditoExternoModel>;
  cantidadRegistros?: number;
}

export interface SccBolsaExportadoresModel {
  bolsa?: Array<BolsaExportadoresModel>;
  cantidadRegistros?: number;
}

export interface SccBolsaFapModel {
  bolsa?: Array<BolsaFapModel>;
  cantidadRegistros?: number;
}


export interface SccBolsaIceModel {
  bolsa?: Array<BolsaIceModel>;
  cantidadRegistros?: number;
}

// {
//   objetoList: [
//     {
//       id: 1,
//       bolsa: [{}],
//       descripcion: "Fap",
//       cantidad: 0,      
//     }
//   ];
//   transaccion: true;
//   mensajes: [];
// }