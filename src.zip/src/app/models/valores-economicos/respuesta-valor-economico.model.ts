import { Respuesta } from 'core-lib';

export interface RespuestaValorEconomico extends Respuesta {
  valorUfv: number;
  tipoCambio: number;
}
