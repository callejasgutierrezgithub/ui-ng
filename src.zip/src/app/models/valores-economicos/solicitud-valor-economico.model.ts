import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudValorEconomico {
  fecha: LocalDate | null;
  oficinaId: number;
}
