import {LocalDate} from '../../shared/utils/formato-fecha/local-date';

export interface DeudaProcesoDeterminativo {
  procesoId?: number;
  montoDeudaBs?: string;
  montoPresuntoBs?: string;
  impuestoId?: number;
  formularioId?: number;
  versionFormulario?: number;
  asientoId?: number;
  periodo?: number;
  anio?: number;
  monedaId?: number;
  fechaVencimiento?: LocalDate; // formato ISO 'YYYY-MM-DD'
  documentoId?: number;
  numeroOrdenDocumento?: number;
  tipoMontoDeudaId?: number;
  formulario?: string;
  impuesto?: string;
  tipoContribuyentePdrId?: number;
}
