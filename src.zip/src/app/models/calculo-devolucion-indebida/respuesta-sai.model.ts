import {RespuestaValorEntregado} from './respuesta-valor-entregado.model';
import {Respuesta} from 'core-lib';


export interface RespuestaSai extends Respuesta {
  listaRespuestaValorEntregado: RespuestaValorEntregado[];
}
