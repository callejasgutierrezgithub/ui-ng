import {LocalDate} from '../../shared/utils/formato-fecha/local-date';
import {DeudaProcesoDeterminativo} from './deuda-proceso-administrativo.model';

export interface SolicituDeudadOrdenVerificacionAgrupadas {
  nitCur: number;
  tramiteId: number;
  origenId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  fechaNotificacion: LocalDate;
  deudasProcesoDeterminativo: DeudaProcesoDeterminativo[];
  tipoContribuyentePdrId: number;
  fechaVencimientoPago: LocalDate;
  oficinaId?: number;
}
