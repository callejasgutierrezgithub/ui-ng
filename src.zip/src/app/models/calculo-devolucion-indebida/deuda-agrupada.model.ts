import {Respuesta} from 'core-lib';

export interface DeudaAgrupadaModel extends Respuesta {
  numeroOrdenDocumentoId?: number;
  deudaId?: number;
}
