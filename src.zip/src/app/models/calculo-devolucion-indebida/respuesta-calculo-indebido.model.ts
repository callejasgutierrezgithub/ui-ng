import { Respuesta } from "core-lib";
import {LocalDate} from '../../shared/utils/formato-fecha/local-date';

export interface RespuestaCalculoIndebido extends Respuesta {
  razonSocial?: string;
  contribuyenteId?: number;
  dudie?: number;
  anio?: number;
  mes?: number;
  importeTotal?: number;
  numeroOrden?: number;
  numeroTramite?: number;
  importeValor?: number;

  fechaSolicitudCedeim?: LocalDate; // formato ISO (ej. '2025-05-07')
  periodoSolicitadoCedeim?: number;
  anioSolicitadoCedeim?: number;
  fechaEntregaCedeim?: LocalDate;
  ufvFechaEntregaCedeim?: number;
  montoDevueltoCedeimBs?: number;
  montoDevueltoCedeimUfv?: number;

  montoObservadoUfv?: number;
  ufvFechaActualizacion?: number;
  mantenimientoValorMontoObservadoBs?: number;
  mantenimientoValorMontoObservadoUfv?: number;
  interesMontoObservadoBs?: number;
  interesMontoObservadoUfv?: number;
  diasMora?: number;
  interesDetalle?: string;
  sancionMontoObservadoBs?: number;
  sancionMontoObservadoUfv?: number;

  ultimoDiaPeriodoSolicitado?: LocalDate;
  ufvUltimoDiaPeriodoSolicitado?: number;
  ultimoDiaPeriodoAnteriorEntrega?: LocalDate;
  ufvUltimoDiaPeriodoAnteriorEntrega?: number;
  mantenimientoValorRestituidoBs?: number;

  actualizacionMantenimientoValorRestituidoBs?: number;
  actualizacionMantenimientoValorRestituidoUfv?: number;
  actualizacionInteresRestituidoBs?: number;
  actualizacionInteresRestituidoUfv?: number;
}
