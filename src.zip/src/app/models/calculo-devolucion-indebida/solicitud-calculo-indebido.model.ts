export interface SolicitudCalculoIndebido {
  nitCur?: number;
  dudie?: number;
  numeroOrdenFiscalizacion?: number;
  oficinaId?: number;
}
