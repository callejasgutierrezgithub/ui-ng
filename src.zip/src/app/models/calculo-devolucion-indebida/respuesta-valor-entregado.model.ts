export interface RespuestaValorEntregado {
  ifc: number;
  numeroDudi: number;
  anio: number;
  mes: number;
  fechaSol: number;
  importeTotal: number;
  numeroOrden: number;
  numeroTramite: string;
  importeValor: number;
  fechaEntrega: string;
}
