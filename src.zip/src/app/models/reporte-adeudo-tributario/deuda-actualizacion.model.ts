export interface DeudaActualizacionModel {
  monedaId: number;
  tributoOmitidoBs: number;
  interesBs: number;
  interesDetalle: string;
  mantenimientoValorBs: number;
  sancionBs: number;
  agravanteBs: number;
  multaBs: number;
  tributoOmitidoUfv: number;
  interesUfv: number;
  mantenimientoValorUfv: number;
  sancionUfv: number;
  agravanteUfv: number;
  multaUfv: number;
}
export interface ListaDeudaActualizacionTableModel
  extends DeudaActualizacionModel {}
