import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface DeudaLiquidacionModel {
  deudaId: number;
  fechaActualizacion: LocalDate;
  instancia: string;
  procesoId: number;
  documentoAgrupadorId: number;
  numeroOrdenDocumentoAgrupador: number;
  documentoId: number;
  numeroOrdenDocumento: number;
  impuestoId: number;
  impuesto: string;
  formularioId: number;
  anio: number;
  periodo: number;
  deudaTotalBs: number;

  formulario: string;
}
export interface DeudaLiquidacionTableModel extends DeudaLiquidacionModel {}
