import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface DeudaPagoModel {
  fechaRegistro: LocalDate;
  tipoPago: string;
  monedaId: number;
  modenaDescripcion: string;
  montoPago: number;
  deudaTotalUfv: number;
  saldoDeuda: number;
  imputacion: string;
  pagoExceso: number;
  pagoEfectivoDetalle?: string | any;
  pagoEfectivoDetalleJson?: any;
  pagoValoresDetalle?: string | any;
  pagoValoresDetalleJson?: any;
  pagoDetalle?: string | any;
  pagoDetalleJson?: any;
  estadoPagoId?: number;
  estadoPago?: string;
  transaccionBancaria?: string;
}
export interface DeudaPagoTableModel extends DeudaPagoModel {
  detalles?: string;
  pagoDeudaBs?: number;
}
