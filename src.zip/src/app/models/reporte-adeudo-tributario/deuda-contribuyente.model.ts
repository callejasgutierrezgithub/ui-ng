import { Respuesta } from "core-lib";
import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface DeudaContribuyenteModel {
  deudaId?: number;
  instancia?: string;
  proceso?: string;
  tipoDocumento?: string;
  nroOrdenDocumento?: number;
  impuestoId?: number;
  formulario?: number;
  anio?: number;
  periodo?: number;
  fechaVencimiento?: LocalDate;
  fechaRegistro?: LocalDate;
  monedaId?: number;
  deudaTotalBs?: number;
  saldoDeudaBs?: number;
  nitCur?: number;
  saldoDeuda?: number;
}

export interface ListaDeudaContribuyenteModelTableModel
  extends DeudaContribuyenteModel {}

export interface RespuestaDetalleDeuda extends Respuesta {
  data?: Array<DeudaContribuyenteModel>;
  deudaDolares?: number;
  deudaBs?: number;
  totalDeudaBsFecha?: number;
}
