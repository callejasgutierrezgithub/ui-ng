export interface MotivoConsultaModel {
    id?: number;
    descripcion?: string;
}