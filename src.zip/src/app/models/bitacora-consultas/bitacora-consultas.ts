export interface SolicitudRegistroBitacoraModel {
    consultaId?: number;
    nitCurLogin?: number;
    usuarioLogin?: String;
    nitCurConsultado?: number;
    motivo?: number;
    tipoContribuyentePdrId?: number;
    tipoUsuarioId?: number;
}
