export interface TotalDeuda {
  totalSaldoDeudaBs: number;
  saldoDeudaUsd: number;
  totalDeudaSeleccionadas: number;
  tipoCambio: number;
}
