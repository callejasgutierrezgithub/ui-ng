import { RespuestaLista } from "core-lib";
import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface PagosLeyTreceCuarentaModel {
  nitCur: number;
  procesoId: number;
  deudaId: number;
  periodo: number;
  anio: number;
  montoTributoOmitidoBs: number;
  montoMantenimientoValorBs: number;
  montoInteresBs: number;
  montoSancionBs: number;
  montoMultaBs: number;
  fechaPago?: LocalDate | null;
}

export interface ListaPagosLeyTreceCuarentaModelTableModel extends PagosLeyTreceCuarentaModel{

}

export interface RepuestaListaPagosLeyTreceCuarentaModel extends RespuestaLista<PagosLeyTreceCuarentaModel>{

}
export interface RepuestaPagosTreceCuarentaModel{
  registros: PagosLeyTreceCuarentaModel;
}