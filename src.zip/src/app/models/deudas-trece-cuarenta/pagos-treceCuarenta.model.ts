import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface RepositorioLiquidacionLeyTreceCuarentaModel {
  nitCur?: number;
  procesoId?: number;
  deudaId?: number;
  periodo?: number;
  anio?: number;
  montoDeudaBs?: number;
  fechaVencimiento?: LocalDate | null;    
}

export interface ResponseRepositorioPagosLeyTreceCuarentaModel {
  fechaPago?: LocalDate;
  montoTributoOmitidoBs?: number;
  montoMantenimientoValorBs?: number;
  montoInteresBs?: number;
  montoSancionBs?: number;
  montoMultaBs?: number;
  totalPago?: number;
}

export interface RequestRepositorioPagosLeyTreceCuarentaModel {
  deudaId?: number;
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  montoTributoOmitidoBs?: number;
  montoMantenimientoValorBs?: number;
  montoInteresBs?: number;
  montoSancionBs?: number;
  montoMultaBs?: number;
  periodo?: number;
  anio?: number;
  fechaPago?: LocalDate;
}

export interface SolicitudPagosTreceCuarenta {
  nitCur?: number,
  deudaId?: number,
  procesoId?: number,
}
