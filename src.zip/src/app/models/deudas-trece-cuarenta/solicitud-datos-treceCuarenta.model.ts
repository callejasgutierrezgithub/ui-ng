import { LocalDate } from "../confirmar-dialog/local-date";

export interface SolicitudDatosTreceCuarenta {
    nitCur: number;
    deudaId: number;
  }