export interface MayorPorDeuda {
  fechaRegistro?: string;
  deudaId?: number;
  periodo?: number;
  anio?: number;
  formularioId?: number;

  cuentaId?: number;
  cuenta?: string;
  debe?: number;
  haber?: number;

  nitCur?: number;
  asientoId?: number;
  asiento?: string;
  saldoCuentaBs?: number;
  formulario?: number;

  numeroAsiento?: number,
  movimientoId?: number,
  montoCuentaBs?: number,

  //PARAMETERS UPDATE
  descripcionCuenta?: string;
  descripcionExterna?: string;
  codigoCuenta?: string;
  tipoCuentaId?: number;
  consideraExtracto?: boolean;
  restaExtracto?: number;
  campoExtracto?: number;
  ordenExposicion?: number;
  cuentaExterna?: string;
}