import { LocalDate } from "../../shared/utils/formato-fecha/local-date";
import { MayorPorDeuda } from "./mayor-deuda-model";

export interface DeudaExtracto {
  id?: number;
  impuestoId?: number;
  impuesto?: string;
  formularioId?: number;
  formulario?: string;
  documentoId?: number;
  documento?: string;
  periodo?: number;
  anio?: number;
  fechaRegistro?: LocalDate;
  totalHaber?: number;
  totalDebe?: number;
  movimientos?: MayorPorDeuda[];
  deudaPendiente?: Boolean;
}