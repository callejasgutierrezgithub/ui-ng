export interface SolicitudMayorCuenta {
  nitCur?: number;
  deudaId?: number;
  cuentaId?: number;
}

export interface MayorCuentaModel {
  nitCur?: number;
  asientoId?: number;
  asiento?: string;
  cuentaId?: number;
  cuenta?: string;
  debe?: number;
  haber?: number;
  saldoCuentaBs?: number;
}
