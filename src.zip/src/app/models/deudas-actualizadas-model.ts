export interface SolicitudActualizaDeudas {
    nitCur?: number;
    oficinaId?: number;
    origenId?: number;
    deudas?: Array<DeudaCalculoActualizacion>;
  }
  
  export interface DeudaCalculoActualizacion {
    deudaId?: number;
  }