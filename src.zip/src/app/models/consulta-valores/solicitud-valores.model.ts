import { Respuesta } from "core-lib";
import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudValoresSaldo {
  nitCur?: number;
  tipoContribuyentePdrId?: number;
  fechaDesde?: LocalDate | null;
  fechaHasta?: LocalDate | null;
}

export interface RespuestaValoresRedimidos extends Respuesta {
  data?: Array<any>;
}
