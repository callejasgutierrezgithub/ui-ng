import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface ValoresSaldosModel {
  id?: number;
  administracion?: number;
  contribuyenteId?: number;
  ufv?: number;
  montoBs?: number;
  montoUfv?: number;
  estadoValorId?: number;
  combinacionImpuestoId?: number;
  nroTramite?: number;
  nro_orden_redencion?: number;
  valoresTramite?: number;
  tipoValorId?: number;
  fechaRegistro?: LocalDate;
  impuestos?: string;
  descripcion?: string;
  nroEmision?: number;
  descripcionTipoValor?: number;
  saldo?: number;
  nitCur?: number;
  fechaDesde?: String;
  impuestoDesc?: string;
  fechaHasta?: String;
  ufvFechaActualizacion?: number;
  tramiteId?: number;
  nroOrdenRedencion?: number;
  valoresTramiteId?: number;
  numeroEmision?: number;
  formularioRedencion?: number;
  oficinaId?: number;
  tipoContribuyentePdrId?: number;
}

export interface RespuestaValoresSaldoRedimidosPorFecha extends Respuesta {
  data?: Array<ValoresSaldosModel>;
  totalRedimidosBs?: number;
  totalImputadosBs?: number;
  saldoCreditoValoresBs?: number;
}

export interface ValoresSaldosDetalleModel {
  deudaId?: number;
  formularioId?: number;
  impuestoId?: number;
  periodo?: number;
  anio?: number;
  numeroOrdenFormulario?: number;
  fechaRegistro?: LocalDate;
  fechaFormulario?: Date;
  montoBs?: number;
}

export interface RespuestaValoresSaldosDetalle extends Respuesta {
  objetosList?: Array<ValoresSaldosDetalleModel>;
  totalImputadosBs?: number;
}
