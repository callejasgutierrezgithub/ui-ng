export interface AdministracionHijoModel {
  codigoAdministracion?: number;
  descripcion?: string;
}