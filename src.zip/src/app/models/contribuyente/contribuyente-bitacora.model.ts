export interface ContribuyenteBitacoraModel {
  consultaId: number;
  usuarioId?: number;
  usuarioLogin?: string;
  nit: number;
  motivo: string;
}
