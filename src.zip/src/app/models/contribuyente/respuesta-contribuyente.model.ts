import { Respuesta } from 'core-lib';
import { ContribuyenteModel } from './contribuyente.model';

export interface RespuestaContribuyente extends Respuesta {
  objeto: ContribuyenteModel;
}
