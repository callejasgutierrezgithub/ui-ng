export interface ContribuyenteModel {
  administracion?: number;
  contribuyenteId?: number;
  estadoNit?: string;
  estadoDescripcion?: string;
  razonSocial?: string;
  nit?: number;
  tipoContribuyenteId?: number;
  tipoContribuyentePdrId?: number;
}

export interface SolicitudContribuyenteModel {
  nitCur: number;
  origen: number,
  datos: Array<number>;
}