import { Respuesta } from 'core-lib';
import { LocalDate } from '../../shared/utils/formato-fecha/local-date';

export interface ParContravencionesModel {  
  id: number;
  codigoContravencion: string;
  descripcion: string;
  naturalUfv: number;
  juridaUfv: number;
  regimenContravencionId: number;
  naturalObservacion: String;
  juridicaObservacion: String;
  fechaDesde: LocalDate;
  fechaHasta: LocalDate;
  normativa: String;
  tipoContravencionId: String;
  descripcionRegimen: String;
}

export interface RespuestaContravenciones extends Respuesta {
  objetosList: ParContravencionesModel[];
}
