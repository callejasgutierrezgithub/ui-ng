export interface ParametricaGenericaModel {
  id: number;
  descripcion: string;
  codigo?: string;
  orden?: string;
  origenId?: number;
  dependenciaId?: number;
}

export interface ParametroModel {
  parametricas: {
    parametricas?: string;
    clasificadores?: string;
    asientos?: string;
    contravenciones?: string;
    casillaconcepto?: null;
    plancuenta?: null;
    impuestos?: any;
    transaccion?: any;
    formulario?: any;
    oficina?: string;
    codigooperaciones?: any;

    //agregar mas paramétricas en caso de ser necesario
  };
}

export interface ParametricaContravencionesModel {
  id: number;
  descripcion: string;
  codigo?: string;
  codigoContravencion?: string;
  naturalUfv?: number,
  juridaUfv?: number,
  tipoContravencionId?: number;
}