import { Respuesta } from "core-lib";
import { ParametricaGenericaModel } from "./parametrica-generica.model";
import { ParametricasEnum } from "../../enums/parametricas.enum";

export interface RespuestaParametricaGenericaModel extends Respuesta {
  data: RespuestaParametrica<ParametricaGenericaModel>;
}

export type RespuestaParametrica<T> = {
  tipo_cuenta: T[];
  tipo_cuenta_balance: T[];
  tipo_moneda_id: T[];
  tipo_naturaleza_id: T[];

  movimiento_id: T[];
  componente_deuda_id: T[];
  par_casilla_concepto: T[];
  plan_cuenta: T[];

  tipo_concepto_id: T[];
  origen_id: T[];
  tipo_documento_id: T[];
  proceso_id:T[];
  documento_id:T[];

  impuesto_id:T[];
  formulario_id:T[];

  oficinas: T[];
  tipoValores: T[];
};

type TestParams = keyof typeof ParametricasEnum;

export type RespuestaParams =
  | 'tipo_cuenta'
  | 'tipo_cuenta_balance'
  | 'tipo_moneda_id'
  | 'tipo_naturaleza_id';
