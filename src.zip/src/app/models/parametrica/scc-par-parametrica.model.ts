export interface SccParParametricaModel {
  id?: number;
  tipoParametrica?: string;
  descripcion?: string;
  abreviatura?: string;
  tipoValor?: string;
  valor?: number;
  valorOrigen?: number;
  fechaDesdeVigencia?: Date;
  fechaHastaVigencia?: Date;
  vigente?: number;
}
