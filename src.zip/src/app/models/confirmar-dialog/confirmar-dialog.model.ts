export interface ConfirmarDialogModel {
  title?: string;
  header?: string;
  content: string;
  footer?: string;
}
