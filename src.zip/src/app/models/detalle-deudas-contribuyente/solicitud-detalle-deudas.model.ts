export interface SolicitudDetalleDeuda {
  nitCur?: number;
  deudaId?: number;
  impuestoId?: number;
  formularioId?: Array<number>;
  anioDesde?: number;
  periodoDesde?: number;
  anioHasta?: number;
  periodoHasta?: number;
  oficinaId?: number;
  procesoId?: number;
  origenId?: number;
  mes?: number;
  anio?: number;
  formularioDdjjId?: number;
}

export interface SolicitudDetalleDeudaPeriodoFormulario {
  formularioId?: number;
  periodo?: number;
  anio?: number;
  nitCur?: number;
  oficinaId?: number;
}
