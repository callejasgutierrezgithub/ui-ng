import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface DetalleDeudaModel {
  deudaId?: number;
  nitCur?: number;
  formularioId?: number;
  dependencia?: number;
  periodo?: number;
  anio?: number;
  montoDeudaBs?: number;
  montoDeudaUfv?: number;
  montoDeudaUsd?: number;
  interesBs?: number;
  interesUfv?: number;
  mantenimientoValorBs?: number;
  mantenimientoValorUfv?: number;
  sancionBs?: number;
  sancionUfv?: number;
  agravanteBs?: number;
  agravanteUfv?: number;
  multaBs?: number;
  multaUfv?: number;
  deudaTotalBs?: number;
  deudaTotalUfv?: number;
  deudaTotalUsd?: number;
  monedaId?: number;
  impuestoId?: number;
  impuesto?: string;
  ufvFechaVencimiento?: number;
  ufvFechaActualizacion?: number;
  tipoCambio?: number;
  procesoId?: number;
  origenId?: number;
  documentoId?: number;
  numeroOrdenDocumento?: number;
  documentoAgrupadorId?: number;
  numeroOrdenDocumentoAgrupador?: number;
  fechaActualizacion?: LocalDate;
  fechaVencimiento?: LocalDate;
  origen?: string;
  proceso?: string;
  documento?: string;
  tipoDeuda?: string;
  estadoDeuda?: string;
  asiento?: string;
  asientoId?: number;
  diasMora?: number;
  estadoDeudaId?: number;
  estadoId?: string;
  estadoLiquidacionId?: number;
  fechaRegistro?: LocalDate;
  fechaNotificacion?: LocalDate;
  liquidacionId?: number;
  tipoImputacionId?: number;
  montoDeudaOrigenUsd?: number;
  montoDeudaOrigen?: number;
  interesDetalle?: string;
  moneda?: string;
  tipoPdr?: number;
  interes?: string;
  montoPago?: number | null;
  montoDeudaInicialBs?: number;

}

export interface InteresDetalleModel {
  diasMora1?: number;
  diasMora2?: number;
  diasMora3?: number;
  interesTramo1?: number;
  interesTramo2?: number;
  interesTramo3?: number;
}
