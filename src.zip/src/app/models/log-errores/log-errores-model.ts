import { Inject } from "@angular/core";
import { MAT_DIALOG_DATA } from "@angular/material/dialog";
import { Respuesta, RespuestaLista } from "core-lib";

export interface ErrorModel {
  errorId: number;
  nitCur: number;
  nombreProyecto: string;
  nombreServicio: string;
  codigoError: number;
  mensajeError: string;
  solicitud: string;
  apiServicio: string;
  estadoErrorId: number;
  excepcion: Text;
  fechaRegistro: Date;
}

export interface ListaErroresTableModel extends ErrorModel {

}

export interface RepuestaListaErrorModel extends RespuestaLista<ErrorModel>{

}
export interface RepuestaCambiarEstadoError extends Respuesta{
  estadoErrorId?:number;
}




export class MensajeDialogoComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: { mensaje: string }) {}
}