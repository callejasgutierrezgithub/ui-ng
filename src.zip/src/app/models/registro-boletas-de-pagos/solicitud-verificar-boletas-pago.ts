import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudVerificarBoletasPago {
    nitCur?: number;
    numeroOrdenBoletaPago?: number,
    numeroOrdenDocumentoPago?: number,
    gestion?: number,
    periodo?: number;
    boleta?: number;
    documentoQuePaga?: number;
}