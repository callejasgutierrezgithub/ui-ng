import { LocalDate } from "../../shared/utils/formato-fecha/local-date";

export interface SolicitudRegistrarBoletasPagoModel {
    file?: File[];
    formData?: FormData;
    codigoAdministracion?: number;
    secuenciaFormulario?: number;
    oficinaId?: number;

    nitCur?: number,
    tramiteId?: number,
    boletaId?: number,
    origenId?: number,
    periodo?: number,
    anio?: number,
    fechaPago?: LocalDate;
    numeroOrdenBoleta?: number;
    numeroDocumentoPaga?: number;
    deudasBoletaPago?: Array<DeudasBoletaPago>;
    tipoContribuyentePdrId?: number;
}

export interface DeudasBoletaPago {
    deudaId?: number;
    formularioId?: number;
    montoPagoBs?: number;
    montoTributoOmitidoBs?: number;
    montoMantenimientoValorBs?: number;
    montoInteresBs?: number;
    montoSancionBs?: number;
    montoAgravanteBs?: number;
    montoMultaUfv?: number;
    monedaId?: number;
}