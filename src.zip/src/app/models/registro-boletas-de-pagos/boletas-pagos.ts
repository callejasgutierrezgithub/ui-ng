import { LocalDate } from "../../shared/utils/formato-fecha/local-date"

export interface BoletasPagoModel {
    deudaId?: number;
    nitCur?: number;
    liquidacionId?: number;
    boleta?: number;
    boletaId?: number;
    montoPagoBs?: number;
    montoTributoOmitidoBs?: number;
    montoMantenimientoValorBs?: number;
    montoInteresBs?: number;
    montoSancionBs?: number;
    montoAgravanteBs?: number;
    montoMultaUfv?: number;
    periodo?: number;
    anio?: number;
    fechaPago?: LocalDate;
    numeroOrdenBoleta?: number;
    numeroDocumentoPaga?: number;
    transaccionBancaria?: string;
    usuarioRegistro?: string

    pagoDeudaBs?: number;
    pagoMultaBs?: number;
    pagoInteresBs?: number;
    pagoSancionBs?: number;
    montoPagoExceso?: number;
    pagoAgravanteBs?: number;
    montoValorPresente?: number;
    pagoMantenimientoValorBs?: number;
    file?: File[];
}

export interface VerificarBoletasPagoModel {
    identificadorBoleta?: number,
    monto?: number;
    fechaPago?: string
    disponible?: boolean;
}