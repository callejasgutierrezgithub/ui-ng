import { Respuesta } from "core-lib";

export interface ConexionMultBaseModel {
  daseDatos?: number;
  Verificacion?: string;
}

export interface RespuestaConexionMultiBase extends Respuesta {
  objetosList?: Array<ConexionMultBaseModel>;
}

export interface SccVerificaConexionesDto {
  verificacionId?: number;
  fechaVerificacion?: Date;
  usuarioRegistroId?: number;
  fechaRegistro?: Date;
  estadoId?: string;
  dataBase?: number;
}