import { Injectable, Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberFormat',
  standalone: true, 
})
@Injectable({
  providedIn: 'root',  // Esto hace que el pipe sea inyectable a nivel global
})
export class NumberFormatPipe implements PipeTransform {
  transform(value: number | string): string {
    if (typeof value === 'number') {
      return value.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    } else if (typeof value === 'string') {
      const num = parseFloat(value);
      if (!isNaN(num)) {
        return num.toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        });
      }
    }
    return value;
  }
}
