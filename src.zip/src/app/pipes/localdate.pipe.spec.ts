/* tslint:disable:no-unused-variable */

import { LocaldatePipe } from './localdate.pipe';

describe('Pipe: Localdatee', () => {
  it('create an instance', () => {
    let pipe = new LocaldatePipe();
    expect(pipe).toBeTruthy();
  });
});
