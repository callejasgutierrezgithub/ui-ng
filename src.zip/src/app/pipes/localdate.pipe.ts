import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';
import { LocalDate } from '../shared/utils/formato-fecha/local-date';

@Pipe({
  name: 'localdate',
  standalone: true,
})
@Injectable({
  providedIn: 'root',  // Esto hace que el pipe sea inyectable a nivel global
})
export class LocaldatePipe implements PipeTransform {
  transform(date: LocalDate, format: string = 'd/MM/yyyy'): string | null {
    if (date) {
      const datePipe: DatePipe = new DatePipe('en-GB');
      return datePipe.transform(
        new Date(`${date.year}-${date.month}-${date.day}`),
        format,
        'UTC',
      );
    }
    return null;
  }
}
