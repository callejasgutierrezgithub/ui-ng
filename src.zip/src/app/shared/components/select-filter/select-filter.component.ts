import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  Input,
  EventEmitter,
  Output,
  ViewChild,
  OnDestroy,
  ElementRef,
  inject,
} from '@angular/core';
import { FormGroup, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { CoreService, MaterialModule } from 'core-lib';
import { Subscription } from 'rxjs';

@Component({
  selector: 'siat-select-filter',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule],
  templateUrl: './select-filter.component.html',
  styleUrls: ['./select-filter.component.scss'],
})
export class SelectFilterComponent<T> implements OnInit, OnDestroy {
  private searchSubscription!: Subscription;
  @ViewChild('input', { static: true }) input!: ElementRef;
  @Input('arrayItems') arrayItems: Array<T>;
  @Input('displayMember') displayMember: string = '';
  @Input('noResultsMessage') noResultsMessage: string = 'Sin resultados';
  private settings = inject(CoreService);
  options = this.settings.getOptions();

  noResults = false;
  filterSpinner = false;
  filteredItems: Array<T> = [];
  searchForm: FormGroup;

  @Output() filteredReturn = new EventEmitter<T[]>();

  navigationKeys: Array<string> = [
    'Backspace',
    'Tab',
    'ArrowLeft',
    'ArrowRight',
    'ArrowUp',
    'ArrowDown',
    'Home',
    'End',
  ];

  constructor(fb: FormBuilder) {
    this.arrayItems = [];
    this.searchForm = fb.group({
      inputValue: '',
    });
  }

  ngOnInit() {
    this.searchSubscription = this.searchForm.valueChanges.subscribe(
      (value) => {
        this.filterSpinner = true;
        if (value['inputValue']) {
          if (this.displayMember == null) {
            this.filteredItems = this.arrayItems.filter((name: string | any) =>
              name.toLowerCase().includes(value['inputValue'].toLowerCase())
            );
          } else {
            this.filteredItems = this.arrayItems.filter((item: T | any) =>
              item[this.displayMember]
                .toLowerCase()
                .includes(value['inputValue'].toLowerCase())
            );
          }
          this.noResults =
            this.filteredItems == null || this.filteredItems.length === 0;
        } else {
          this.filteredItems = this.arrayItems.slice();
          this.noResults = false;
        }
        this.filteredReturn.emit(this.filteredItems);
        setTimeout(() => {
          this.filterSpinner = false;
        }, 500);
      }
    );

    setTimeout(() => {
      this.input.nativeElement.focus();
    }, 300);
  }

  handleKeydown(event: KeyboardEvent) {
    if (
      this.navigationKeys.indexOf(event.key) > -1 ||
      (event.key && event.key.length === 1) ||
      (event.key >= 'A' && event.key <= 'Z') ||
      (event.key >= '0' && event.key <= '9') ||
      event.key === 'Space'
    ) {
      event.stopPropagation();
    }
  }

  ngOnDestroy() {
    this.filteredItems = [];
    this.filteredReturn.emit(this.arrayItems);
    this.searchSubscription.unsubscribe();
  }

  clearFilter() {
    this.filteredItems = [];
    this.filteredReturn.emit(this.arrayItems);
  }
}
