import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreService, MaterialModule } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { Router } from '@angular/router';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';

@Component({
  selector: 'scc-info-contribuyente',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule],
  templateUrl: './info-contribuyente.component.html',
  styleUrl: './info-contribuyente.component.scss',
})
export class InfoContribuyenteComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente: ContribuyenteModel;
  @Input() esContribuyente: Boolean = false;
  constructor(
    private router: Router,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.contribuyente = {};
  }

  ngOnInit() {
    this._datosContribuyente.dataModel$.subscribe((contribuyente) => {
      this.contribuyente = contribuyente;
    });
  }

  limpiarNit(): void {
    this._datosContribuyente.setDataModel({});
  }
}
