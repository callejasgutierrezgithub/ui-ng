import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MaterialModule } from 'core-lib';

@Component({
  selector: 'scc-button-loading',
  standalone: true,
  imports: [MaterialModule, CommonModule],
  templateUrl: './scc-button-loading.component.html',
  styleUrl: './scc-button-loading.component.scss'
})
export class SccButtonLoadingComponent {
  @Input() loading = false;
  @Input() label = 'Enviar';
  @Input() loadingLabel = 'Enviando...';
  @Input() color: 'primary' | 'accent' | 'warn' | 'success' | undefined;
  @Input() disabled = false;
  @Output() onClick = new EventEmitter<void>();
}
