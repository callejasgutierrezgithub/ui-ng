import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CoreService, MaterialModule, RespuestaLista, UserInfoService } from 'core-lib';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ExpresionRegularEnum } from '../../../enums/expresion-regular.enum';
import { AdministracionHijoModel } from '../../../models/contribuyente/administracion.model';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { RespuestaContribuyente } from '../../../models/contribuyente/respuesta-contribuyente.model';
import { UserInfoModel } from '../../../models/usuario-login/UserInfoModel';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { Mensajes } from '../../utils/mensajes.const';

@Component({
  selector: 'app-datos-contribuyente',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule, NgxSpinnerModule],
  templateUrl: './datos-contribuyente.component.html',
  styleUrl: './datos-contribuyente.component.scss'
})
export class DatosContribuyenteComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  formContribuyente: FormGroup;
  contribuyente!: ContribuyenteModel;
  funcionario!: ContribuyenteModel;
  oficinaId?: number;
  opcion = this.setting.getOptions();
  usuario?: UserInfoModel;
  administracionHijoLista?: AdministracionHijoModel[];
  constructor(
    private setting: CoreService,
    private formBuilder: FormBuilder,
    private _userInfo: UserInfoService,
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyente: ConsultaContribuyenteStoreService,
  ) {
    this.formContribuyente = new FormGroup({});
    this.contribuyente = {};
    this.oficinaId = 0;
  }


  ngOnInit() {
    this.crearFormulario();
    this.obtenerDatosSesion();

  }

  crearFormulario() {
    this.formContribuyente = this.formBuilder.group({
      nit: [
        '',
        [
          Validators.required,
          Validators.minLength(1),
          Validators.min(1),
          Validators.maxLength(15),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      tipoContribuyentePdrId: ['0'],
      razonSocial: [null],
    });
  }

  obtenerDatosSesion(): void {
    this._userInfo.contextInfo$.subscribe(
      (response: UserInfoModel) => {
        this.usuario = response;
      }
    );
  }

  buscarContribuyente(): void {
    var oficinaUsuario = this.usuario?.userInfo?.oficinaId ?? null;
    this.obtenerAdministracionHijos(oficinaUsuario!);
    if (this.formContribuyente.valid) {
      this._datosContribuyente.obtenerContribuyente(this.formContribuyente.value.nit)
        .then((response: RespuestaContribuyente) => {
          if (response.transaccion) {
            const adminContribuyente = response.objeto.administracion ?? null;
            if (oficinaUsuario !== null && adminContribuyente !== null && (oficinaUsuario === 0 || (adminContribuyente === oficinaUsuario) || this.getValidarAdministracionHijo(adminContribuyente!))) {
              this._consultaContribuyente.setConsultaNit(true);
              this._consultaContribuyente.setMensaje('');
            } else {
              this._consultaContribuyente.setConsultaNit(false);
              if (oficinaUsuario === null || adminContribuyente === null) {
                if (oficinaUsuario === null) this._consultaContribuyente.setMensaje(Mensajes.MSG_OFICINA_ID_IS_NULL);
                if (adminContribuyente === null) this._consultaContribuyente.setMensaje(Mensajes.MSG_ADMINISTRACION_IS_NULL);
              } else {
                setTimeout(() => { this._consultaContribuyente.setMensaje(Mensajes.NIT_NO_CORRESPONDE_A_LA_ADMINISTRACION); }, 1000)
              }
            }
          } else {
            this.formContribuyente.controls['razonSocial'].setValue('');
            this._datosContribuyente.setDataModel({});
          }
        });
    }
  }

  obtenerAdministracionHijos(oficinaId: number): void {
    this._datosContribuyente.obtenerAdministracionHijos(oficinaId!)
      .then((response: RespuestaLista<AdministracionHijoModel>) => {
        if (response.transaccion) {
          this.administracionHijoLista = response.objetosList || []
        }
      });
  }

  getValidarAdministracionHijo(oficinaId: number): boolean {
    return Array.isArray(this.administracionHijoLista) &&
      this.administracionHijoLista.length > 0 &&
      this.administracionHijoLista.some(item => item.codigoAdministracion === oficinaId);
  }

  limpiarNit(): void {
    this.formContribuyente.controls['nit'].setValue('');
    this.formContribuyente.controls['razonSocial'].setValue('');
    this._datosContribuyente.setDataModel({});
  }
}