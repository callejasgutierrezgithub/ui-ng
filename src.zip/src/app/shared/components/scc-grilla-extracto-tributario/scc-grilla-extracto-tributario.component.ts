import { animate, state, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA, inject, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ISpinnerConfig, SPINNER_ANIMATIONS, SPINNER_PLACEMENT } from '@hardpool/ngx-spinner';
import { CoreService, MaterialModule, RespuestaLista, SiatToastrService } from 'core-lib';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ExpresionRegularEnum } from '../../../enums/expresion-regular.enum';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DeudaExtracto } from '../../../models/extracto-tributario/deuda-extracto-model';
import { MayorPorDeuda } from '../../../models/extracto-tributario/mayor-deuda-model';
import { FormularioModel, RespuestaFormularioDdjj } from '../../../models/impuesto-asociado/formulario.model';
import { ParametricaGenericaModel } from '../../../models/parametrica/parametrica-generica.model';
import { LocaldatePipe } from '../../../pipes/localdate.pipe';
import { ExtractoTributario } from '../../../services/extracto-tributario-service/extracto-tributario.service';
import { FormularioDdjjService } from '../../../services/formularios-ddjj/formulario-ddjj.service';
import { SccDatePickerYearComponent } from '../scc-datepicker-year/scc-datepicker-year.component';
import { SelectFilterComponent } from '../select-filter/select-filter.component';
import { validarCampoFormulario } from '../../utils/validad-formulario/validar-campos';
import { SccGrillaMovimientosComponent } from './scc-grilla-movimientos/scc-grilla-movimientos.component';


interface FoodNode {
  name: string;
  children?: FoodNode[];
}
@Component({
  selector: 'scc-grilla-extracto-tributario',
  standalone: true,
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [MaterialModule, ReactiveFormsModule, CommonModule, SccDatePickerYearComponent,
    SelectFilterComponent, LocaldatePipe, NgxSpinnerModule, MatButtonModule, SccGrillaMovimientosComponent],
  templateUrl: './scc-grilla-extracto-tributario.component.html',
  styleUrl: './scc-grilla-extracto-tributario.component.scss',
  providers: [],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class SccGrillaExtractoTributarioComponent implements OnInit {
  @Input() contribuyente: ContribuyenteModel = {};
  @ViewChild(SccDatePickerYearComponent) hijo: SccDatePickerYearComponent | undefined;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  private settings = inject(CoreService);
  options = this.settings.getOptions();

  formSaldos: FormGroup;
  displayedColumns: string[] = [
    'chevronRown',
    'deudaId',
    'periodo',
    'anio',
    'formularioId',
    'documento',
    // 'totalDebe',
    // 'totalHaber',
  ];
  dataSource;
  dataSourceAll;
  mayorDeudaListComponente: MayorPorDeuda[] = [];
  tipoPeriodo: ParametricaGenericaModel[];
  anioBooleanP: boolean = false;
  formularios: FormularioModel[];
  formulariosFiltrado: any;
  saldoTributoOmitido: number = 0;
  filaSeleccionada: DeudaExtracto;
  detailDisplayedColumns = ['cuenta', 'debe', 'haber'];
  deuda!: DeudaExtracto | null;
  limpiar: Boolean = false;
  obtenerTotalDebe: number;
  obtenerTotalHaber: number;
  loading: Boolean;
  paginatorAsignado: Boolean = false;
  mensageDeuda: String = ""
  error: Boolean = false;
  constructor(
    private formBuilder: FormBuilder,
    private mayorDeudaService: ExtractoTributario,
    private _formulariosDdjj: FormularioDdjjService,
    private toastr: SiatToastrService,
  ) {
    this.formSaldos = new FormGroup({});
    this.dataSource = new MatTableDataSource<DeudaExtracto>([]);
    this.dataSourceAll = new MatTableDataSource<DeudaExtracto>([]);
    this.tipoPeriodo = [
      { id: 1, descripcion: 'ENERO' },
      { id: 2, descripcion: 'FEBRERO' },
      { id: 3, descripcion: 'MARZO' },
      { id: 4, descripcion: 'ABRIL' },
      { id: 5, descripcion: 'MAYO' },
      { id: 6, descripcion: 'JUNIO' },
      { id: 7, descripcion: 'JULIO' },
      { id: 8, descripcion: 'AGOSTO' },
      { id: 9, descripcion: 'SEPTIEMBRE' },
      { id: 10, descripcion: 'OCTUBRE' },
      { id: 11, descripcion: 'NOVIEMBRE' },
      { id: 12, descripcion: 'DICIEMBRE' },
    ];
    this.formularios = [];
    this.filaSeleccionada = {};
    this.obtenerTotalDebe = 0
    this.obtenerTotalHaber = 0
    this.loading = false;
  }

  config: ISpinnerConfig = {};
  ngOnInit(): void {
    this.crearFormularios();
    this.obtenerFormulariosDdjj();
    this.obtenerDeuda();
    this.config = {
      placement: SPINNER_PLACEMENT.block_ui,
      animation: SPINNER_ANIMATIONS.spin_2,
      size: "3rem",
      color: "#1574b3"
    };
  }

  hasChild = (_: number, node: FoodNode) => !!node.children && node.children.length > 0;

  ngAfterViewChecked() {
    if (!this.paginatorAsignado && this.paginator && this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.paginatorAsignado = true;
    }
  }

  obtenerFormulariosDdjj() {
    this._formulariosDdjj
      .obtenerFormularios()
      .then((respuesta: RespuestaFormularioDdjj) => {
        if (respuesta.transaccion) {
          this.formularios = respuesta.formularios.map(
            (item: FormularioModel) => {
              item.descripcionLarga = `${item.formulario} - ${item.descripcion}`;
              return item;
            }
          );
          this.formulariosFiltrado = this.formularios.slice();
        }
      });
  }

  crearFormularios() {
    this.formSaldos = this.formBuilder.group({
      formularioId: [null, Validators.pattern(ExpresionRegularEnum.Numeros)],
      periodo: [
        null,
        [
          Validators.minLength(1),
          Validators.maxLength(2),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      anio: [null, Validators.pattern(ExpresionRegularEnum.Numeros)],
      deudaPendiente: [false]
    });
  }

  obtenerDeuda() {
    let nitCur = this.contribuyente.nit!;
    let tipoPdrId = 0;
    this.loading = true;
    this.mensageDeuda = ""
    this.error = false;
    this.mayorDeudaService.obtenerDeudas(nitCur, tipoPdrId)
      .then((respuesta: RespuestaLista<DeudaExtracto>) => {
        this.dataSource.data = respuesta.objetosList!;
        this.dataSourceAll.data = this.dataSource.data;
        this.getSaldoTributoOmitido(this.dataSource);
        this.getObtenerTotalDebe();
        this.getObtenerTotalHaber();
        if (this.dataSource.data.length === 0) this.mensageDeuda = `El Nit: ${this.contribuyente.nit}, no tiene Extracto...`;
      })
      .catch(() => {
        this.error = true;
        this.toastr.error('Error al Obtener el Extracto...');
        this.mensageDeuda = "Error al Obtener el Extracto...";
      }).finally(() => {
        setTimeout(() => {
          this.loading = false;
          this.formSaldos.markAllAsTouched();
        }, 200);
      });
  }

  getSaldoTributoOmitido(dataSource: MatTableDataSource<DeudaExtracto>): void {
    var saldoDebe = 0
    var saldoHaber = 0
    dataSource.data?.forEach((item: DeudaExtracto) => {
      saldoDebe = saldoDebe + item.totalDebe!;
      saldoHaber = saldoHaber + item.totalHaber!;
    });
    this.saldoTributoOmitido = saldoDebe - saldoHaber;
  }

  validarCampo(campo: string, label: string, maxlength?: number) {
    return new validarCampoFormulario().validarCampo(
      this.formSaldos,
      campo,
      label,
      maxlength
    );
  }

  seleccionarAnio(event: any): void {
    this.formSaldos.get('anio')?.setValue(event)
    this.buscarDeuda();
  }

  getObtenerTotalDebe() {
    const total = this.dataSource.data
      .map((t) => t.totalDebe)
      .reduce((a, b) => Number(a ? a : 0) + Number(b ? b : 0), 0);
    this.obtenerTotalDebe = parseFloat(total!.toFixed(2));
  }

  getObtenerTotalHaber() {
    const total = this.dataSource.data
      .map((t) => t.totalHaber)
      .reduce((a, b) => Number(a ? a : 0) + Number(b ? b : 0), 0);
    this.obtenerTotalHaber = parseFloat(total!.toFixed(2));
  }

  toggleRow(element: DeudaExtracto) {
    this.deuda = (this.deuda === element) ? null : element;
    this.filaSeleccionada = element;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  limpiarFitros(): void {
    this.dataSource.data = this.dataSourceAll.data;
    this.limpiar = false;
    this.formSaldos.get('deudaPendiente')!.setValue(false);
    this.limpiarFormulario();
    this.limpiarPeriodo();
    this.limpiarAnio();
    this.getSaldoTributoOmitido(this.dataSource);
    this.getObtenerTotalDebe();
    this.getObtenerTotalHaber();
  }

  limpiarFormulario(): void {
    this.formSaldos.get('formularioId')?.reset();
  }
  limpiarPeriodo(): void {
    this.formSaldos.get('periodo')?.reset();
  }
  limpiarAnio(): void {
    this.formSaldos.get('anio')?.reset();
    this.hijo?.limpiarAnio();
  }

  buscarDeuda(): void {
    const solicitud: DeudaExtracto = {
      formularioId: this.formSaldos.value.formularioId,
      periodo: this.formSaldos.value.periodo,
      anio: this.formSaldos.value?.anio,
      deudaPendiente: this.formSaldos.value?.deudaPendiente,
    };

    this.dataSource.data = this.dataSourceAll.data.filter((item) => {
      let matches = true;

      if (solicitud.formularioId && solicitud.formularioId > 0) {
        matches = matches && item.formularioId === solicitud.formularioId;
      }

      if (solicitud.periodo && solicitud.periodo > 0) {
        matches = matches && item.periodo === solicitud.periodo;
      }

      if (solicitud.anio && solicitud.anio > 0) {
        matches = matches && item.anio === solicitud.anio;
      }

      if (solicitud.deudaPendiente) {
        let vMontoDeudaBs = item.totalDebe! - item.totalHaber!;
        if (vMontoDeudaBs <= 0) {
          matches = false;
        }

      }
      return matches;
    });

    this.getSaldoTributoOmitido(this.dataSource);
    this.getObtenerTotalDebe();
    this.getObtenerTotalHaber();
    this.limpiar = true;
  }

  deudasPendientes($event: any): void {
    this.formSaldos.get('deudaPendiente')!.setValue($event.checked);
    this.buscarDeuda();
  }

  clearFilterFormulario(event: MouseEvent): void {
    event.stopPropagation();
    this.limpiarFormulario();
    this.buscarDeuda();
  }
  clearFilterPeriodo(event: MouseEvent): void {
    event.stopPropagation();
    this.limpiarPeriodo();
    this.buscarDeuda();
  }
}
