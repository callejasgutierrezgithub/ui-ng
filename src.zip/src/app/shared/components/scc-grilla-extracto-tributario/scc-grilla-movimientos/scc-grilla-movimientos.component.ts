import { Component, inject, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MayorPorDeuda } from '../../../../models/extracto-tributario/mayor-deuda-model';
import { CoreService, MaterialModule } from 'core-lib';
import { CommonModule } from '@angular/common';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { ExtractoEnum } from '../../../../enums/extracto-tributario.enum';

@Component({
  selector: 'scc-grilla-movimientos',
  standalone: true,
  imports: [MaterialModule, CommonModule, LocaldatePipe],
  templateUrl: './scc-grilla-movimientos.component.html',
  styleUrl: './scc-grilla-movimientos.component.scss'
})
export class SccGrillaMovimientosComponent implements OnInit, OnChanges {
  @Input() movimientos: MayorPorDeuda[] = [];
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  dataSource = new MatTableDataSource<MayorPorDeuda>([]);
  saldoTributoOmitido: number = 0;

  displayedColumns: string[] = [
    'fechaRegistro',
    'numeroAsiento',
    'descripcionExterna', //'detalleTransaccionCuentaCorriente'
    'debe',
    'haber',
  ];

  constructor() {
  }
  ngOnInit(): void {
    this.obtenerSaldoTributoOmitido();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['movimientos']) {
      this.dataSource.data = this.movimientos
        .filter(item => item.consideraExtracto === true && (item.campoExtracto === 361 || item.campoExtracto === 362));

      this.dataSource.data
        .forEach((item) => {
          if (item.campoExtracto === ExtractoEnum.DEBE) { //!DEBE 361
            item.debe = item.montoCuentaBs;
            item.haber = 0;
          } else if (item.campoExtracto === ExtractoEnum.HABER) {//!HABER 362
            item.haber = item.montoCuentaBs;
            item.debe = 0
          }
        });

      /* ************* */
      this.dataSource.data


      /* ************* */

      this.dataSource.data
        .sort((a, b) => (a.ordenExposicion ?? 0) - (b.ordenExposicion ?? 0));

      console.log("this.dataSource.data--> ", this.dataSource.data);
    }
  }

  obtenerTotalDebeTributoOmitido() {
    const total = this.dataSource.data
      .reduce((sum, item) => sum + Number(item.debe || 0), 0);
    return total.toFixed(2);
  }

  obtenerTotalHaber() {
    const total = this.dataSource.data
      .filter(item => item.restaExtracto === ExtractoEnum.RESTAR_EXTRACTO)//!PAR 359
      .reduce((sum, item) => sum + Number(item.haber || 0), 0);
    return total.toFixed(2);
  }

  obtenerSaldoTributoOmitido(): void {
    this.saldoTributoOmitido = Number(this.obtenerTotalDebeTributoOmitido()) - Number(this.obtenerTotalHaber());
  }
}
