import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import {
  MAT_DIALOG_DATA,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { ConfirmarDialogModel } from '../../../models/confirmar-dialog/confirmar-dialog.model';

@Component({
  selector: 'scc-confirm-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogActions,
    MatDialogClose,
    MatDialogTitle,
    MatDialogContent,
    MatButtonModule,
  ],
  templateUrl: './scc-confirm-dialog.component.html',
  styleUrl: './scc-confirm-dialog.component.scss',
})
export class SccConfirmDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<SccConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ConfirmarDialogModel
  ) {}

  ngOnInit(): void {
    if (this.data !== undefined) {
      this.data.title = this.data.title ?? 'CONFIRMACIÓN';
      this.data.header = this.data.header ?? '';
      this.data.content = this.data.content ?? '¿Está seguro/a de confirmar?';
      this.data.footer = this.data.footer ?? '';
    }
  }

  aceptar(): void {
    this.dialogRef.close(true);
  }
}
