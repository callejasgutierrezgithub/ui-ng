import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatNativeDateModule } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { MaterialModule } from 'core-lib';
import * as _moment from 'moment';
import { default as _rollupMoment, Moment } from 'moment';
import { FORMATO_FECHA_ANIO } from '../../utils/formato-fecha-date-picker/date-format';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'scc-datepicker-year',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,      
  ],
  templateUrl: './scc-datepicker-year.component.html',  
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    { provide: MAT_DATE_FORMATS, useValue: FORMATO_FECHA_ANIO },
  ],
})
export class SccDatePickerYearComponent implements OnInit, OnChanges  {
  @Input() anioBoolean: boolean = false;
  @Output() anio: EventEmitter<number> = new EventEmitter<number>(); 
  formYear: FormGroup;
  fechaMinimoDesde: Date;
  fechaMaximoHasta: Date;
  constructor(private formBuilder: FormBuilder) {
    this.formYear = new FormGroup({});
    this.fechaMinimoDesde = new Date('1992/01/01');
    this.fechaMaximoHasta = new Date();
  }

  ngOnInit(): void {
    this.crearFormulario();
    this.inicializarAnio();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['anioBoolean']) {
      if (this.anioBoolean) {
        this.formYear.get('anio')?.disable();
      } else {
        this.formYear.get('anio')?.enable();
      }
    }
  }
  
  inicializarAnio(): void {
    setTimeout(() => {
      this.formYear.get('anio')?.setValue(null);
    }, 300);
  }
  date = new FormControl(moment());  
  
  chosenYearHandler(normalizedYear: Moment, datepicker: MatDatepicker<Moment>) {    
    const ctrlValue = this.date.value!;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
    this.anio.emit(this.date.value?.year())
    datepicker.close();
  }

  crearFormulario() {
    this.formYear = this.formBuilder.group({      
      anio: [],     
    });    
  }

  limpiarAnio(): void {
    this.formYear.get('anio')?.reset();
  }
}
