/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { TableBasicComponent } from './table-basic.component';

describe('TableBasicComponent', () => {
  let component: TableBasicComponent<typeA>;
  let fixture: ComponentFixture<TableBasicComponent<typeA>>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TableBasicComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent<typeModel>(TableBasicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

type typeA = {};
type typeModel = TableBasicComponent<typeA>;
