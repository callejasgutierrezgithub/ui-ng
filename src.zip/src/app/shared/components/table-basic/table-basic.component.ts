import {
  AfterViewInit,
  Component,
  ContentChild,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';

import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Sort } from '@angular/material/sort';
import { Enumerated, TableColumnModel } from './table-column.model';
import { MatCheckboxChange } from '@angular/material/checkbox';

@Component({
  selector: 'siat-table-basic',
  templateUrl: './table-basic.component.html',
  styleUrls: ['./table-basic.component.scss'],
})
export class TableBasicComponent<T> implements OnInit, AfterViewInit {
  displayedColumns: Array<string> = [];
  tableDataSource = new MatTableDataSource<T>([]);
  thereIsData: boolean = false;
  //selectedRows = new Set<any>();

  @ViewChild(MatPaginator, { static: false }) matPaginator!: MatPaginator;

  @ViewChild(MatSort, { static: true }) matSort!: MatSort;

  @Input() isFilterable: boolean = false;
  @Input() isPageable: boolean = false;
  @Input() isSortable: boolean = false;
  @Input() isEnumered: boolean = false;
  @Input() orderEnumered: Enumerated = 'asc';
  @Input() tableLoading: boolean = false;
  @Input() tableColumns: Array<TableColumnModel> = [];
  @Input() haveOptions: boolean = false;
  @Input() haveActions: boolean = false;
  @Input() actionsTemplate!: TemplateRef<T>;
  @Input() isChecked: boolean = false;
  @Input() checkedTemplate!: TemplateRef<T>;

  @ContentChild('headerTemplate') headerTemplate!: TemplateRef<HTMLElement>;
  @ContentChild('columnTemplate') columnTemplate!: TemplateRef<T>;

  @Input() paginationSizes: Array<number> = [5, 10, 25, 50, 100];
  @Input() defaultPageSize: number = this.paginationSizes[0];

  @Output() sortData: EventEmitter<Sort> = new EventEmitter();

  @Input() set tableData(data: Array<T>) {
    this.thereIsData = data.length == 0 ? true : false;
    this.setTableDataSource(data);
  }
  selectedRows: Set<T> = new Set<T>(); // Para almacenar filas seleccionadas
  @Output() selectionChange: EventEmitter<Set<T>> = new EventEmitter<Set<T>>();

  constructor() {}

  ngOnInit(): void {
    const columnNames = this.tableColumns.map(
      (tableColumn: TableColumnModel) => tableColumn.name
    );
    if (this.isChecked) {
      this.displayedColumns = ['seleccion', ...columnNames];
    } else {
      this.displayedColumns = columnNames;
    }
    if (this.isChecked && this.isEnumered && this.haveActions) {
      this.displayedColumns = ['nro', 'seleccion', ...columnNames, 'actions'];
    } else if (this.haveActions) {
      this.displayedColumns = [...columnNames, 'actions'];
    } else {
      this.displayedColumns = columnNames;
    }
    if (this.isChecked && this.haveActions) {
      this.displayedColumns = ['seleccion', ...columnNames, 'actions'];
    }
  }

  ngAfterViewInit(): void {
    this.tableDataSource.paginator = this.matPaginator;
  }

  setTableDataSource(data: Array<T>) {
    this.tableDataSource = new MatTableDataSource<T>(data);
    this.tableDataSource.paginator = this.matPaginator;
    this.tableDataSource.sort = this.matSort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.tableDataSource.filter = filterValue.trim().toLowerCase();
    this.thereIsData =
      this.tableDataSource.filteredData.length == 0 ? true : false;
  }

  clearFilter(): void {
    this.tableDataSource.filter = '';
  }

  sortTable(sortColumn: Sort) {
    sortColumn.active =
      this.tableColumns.find((column) => column.name === sortColumn.active)
        ?.dataKey ?? sortColumn.active;
    this.sortData.emit(sortColumn);
  }
  selectAllRows(event: MatCheckboxChange) {
    if (event.checked) {
      this.tableDataSource.data.forEach((row) => this.selectedRows.add(row));
    } else {
      this.selectedRows.clear();
    }
    this.selectionChange.emit(this.selectedRows);
  }

  selectRow(row: T) {
    if (this.selectedRows.has(row)) {
      this.selectedRows.delete(row);
    } else {
      this.selectedRows.add(row);
    }
    this.selectionChange.emit(this.selectedRows);
  }

  // Verifica si una fila está seleccionada
  isRowSelected(row: any): boolean {
    return this.selectedRows.has(row);
  }

  // Alternar la selección de una fila individual
  toggleSelection(row: any, checked: boolean): void {
    if (checked) {
      this.selectedRows.add(row);
    } else {
      this.selectedRows.delete(row);
    }
  }

  // Seleccionar o deseleccionar todas las filas
  toggleSelectAll(checked: boolean): void {
    if (checked) {
      this.tableDataSource.data.forEach((row) => this.selectedRows.add(row));
    } else {
      this.selectedRows.clear();
    }
  }

  // Verifica si todas las filas están seleccionadas
  isAllSelected(): boolean {
    return this.selectedRows.size === this.tableDataSource.data.length;
  }

  // Verifica si algunas filas están seleccionadas
  isSomeSelected(): boolean {
    return this.selectedRows.size > 0 && !this.isAllSelected();
  }
}
