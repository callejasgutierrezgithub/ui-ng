export interface TableColumnModel {
  name: string;
  dataKey: string;
  position?: Position;
  isSortable?: boolean;
  isTemplate?: boolean;
  isDate?: boolean;
  isLocalDate?: boolean;
  isDecimal?: boolean;
  isInteresDetalle?: boolean;
  //isCheckbox?: boolean; // Nueva propiedad
}

export type Position = 'right' | 'left' | 'center';

export type Enumerated = 'asc' | 'desc';

export interface InteresDetalleJson {
  interesTramo1?: number;
  interesTramo2?: number;
  interesTramo3?: number;
  diasMora1?: number;
  diasMora2?: number;
  diasMora3?: number;
}