# Componentes

## Modo de uso

### Componente tabla básica

El componente de la tabla está basada en [Angular Material](https://material.angular.io/components/categories), para uso común entre diferentes subsistemas que requieran.
|Selector|Descripción|
|---|---|
|`<siat-table-basic>` | Es la forma de utilizar el componente tabla. |
|`<ng-template>` | Permite personalizar una o varias secciones de la tabla. En algún caso se puede agregar controles adicionales. |

### Propiedades

Las propiedades se dividen en dos partes, las que son requeridas y las que no son necesarias para su funcionamiento de la tabla.
|Propiedades|Tipo|Descripción|
|---|---|---|
|`tableColumns` |requerido| Es el objeto que tiene propiedades de la cabecera de la tabla, recuerde que la key de `tableData` debe reflejar en la cabecera. |
|`tableData` |requerido| Es la colección de datos a mostrar en la tabla, los datos deben estar tipados. |
|`isFilterable` |no requerido| Es la opción que permite visualizar el campo para la busqueda. |
|`isEnumered` |no requerido| Es la opción que permite visualizar la columna Nro. |
|`ordenEnumered` |no requerido| Es la opción que permite ordenar la columna Nro ascendente o descentente, pasar la propiedad solo si es en orden descendente y si la propiedad `isEnumered = true`. |
|`isPageable` |requerido| Es la opción que permite visualizar el paginado de la tabla. |
|`tableLoading` |no requerido| Permite visualizar una barra de progreso (cargando). |
|`paginationSizes` |no requerido| Por defecto ya tiene valores (no es necesario pasar esta propiedad si `isPageable = false`), pero se puede personalizar en caso de tener paginación. |
|`defaultPageSize` |no requerido| Por defecto ya tiene el valor (no es necesario pasar esta propiedad si `isPageable = false`), pero se puede personalizar en caso de tener paginación. |
|`haveOptions` |no requerido| Permite agregar un template a lado derecho del campo Buscar, dicho template puede ser personalizado (se debe agregar un template si el valor `haveOptions = true`, se recomienda no romper el diseño). |
|`haveActions` |no requerido| Permite agregar un template en la última columna de la tabla para realizar acciones como Actualizar, Eliminar u otro (agregar el template solo si `haveActions = true`). |
|`actionsTemplate` |no requerido| Permite personalizar un template con acciones para manipular los datos de la fila (diseñar este template solo si `haveActions = true`). |

### Consideraciones

Las 3 ultimas requieren de template, mismos que pueden ser personalizados:

1. `haveOptions` requiere que se agregue un template personalizado.
2. `haveActions` y `actionsTemplate` requiere que se contruya un template personalizado, generalmente con botones de control para Actualizar, Eliminar u otro tipo de control adicional.

Si en la cabecera esta definido alguna de las columnas para su ordenamiento, se debe agregar el siguiente evento, caso contrario no es requerido agregar esa funcionalidad.

1. `sortData` requiere redireccionar a una función definida en en el componente en donde esté usando componenete tabla. Dicha función debe tener la lógica de ordenamiento, vease el ejemplo

---

### Ejemplo

Nota: Al usar el componente tabla, la colección de datos debe estar tipado para ello utilizar **interface**, **type** o **class** como modelo (**model**).

#### Modelo (model)

El siguiente modelo es para la cabecera, **no es necesario agregar (ya viene definido)**, es solo ilustrativo para una mejor comprensión.

```ts
export interface TableColumnModel {
  name: string;
  dataKey: string;
  position?: "right" | "left";
  isSortable?: boolean;
  isDate?: boolean;
  isTemplate?: boolean;
}
```

Descripción de las propiedades del modelo **TableColumnModel**.
| Propiedades | Descripción |
| --- |---|
| `name` | Va el nombre o título de la columna. |
| `dataKey` | Va el valor de los datos, debe coincidir con la coleccion de datos. |
| `position` | Indica el alineado de la columna, no es obligatorio. |
| `isSortable` | Indica si una columna va tener la opción de ordenado, no es obligatorio. |
| `isDate` | Es para aplicar el pipe para formatar la fecha en las columnas que despliegue fechas, para ello solo es necesario indicar en la columna `isDate = true`. |
| `isTemplate` | Indica si una o varias columnas van a ir personalizado, no es obligatorio. |

Este modelo debe ser definido, dependiendo de la estructura de los datos de la colección a mostrar en la tabla.

```ts
interface Person {
  id: number;
  nombre: string;
  apellido: string;
  telefono?: number;
  correo: string;
}
```

Se recomienda no exagerar con el uso de **?**

```diff
- ?
```

en vez de eso utilizar [Utility Types - TypeScript](https://www.typescriptlang.org/docs/handbook/utility-types.html).

---

#### Ejemplo básico (html)

```html
<siat-table-basic [tableColumns]="displayedColumns" [tableData]="personas" [isFilterable]="true" [isPageable]="true" [tableLoading]="tablaCargando">
  <ng-template #columnTemplate let-value="value">
    <span class="column-style"> {{ value }} </span>
  </ng-template>
</siat-table-basic>
```

La clase `column-style` es un indicativo que puede personalizar mediante css, puede tener otro nombre según el propósito de la columna.

#### Ejemplo completo (html)

```html
<siat-table-basic [tableColumns]="displayedColumns" [tableData]="personas" [isFilterable]="true" [isPageable]="true" [isEnumered]="true" [orderEnumered]="'desc'" [tableLoading]="tablaCargando" [paginationSizes]="[10, 25, 50, 100]" [defaultPageSize]="10" (sortData)="ordenarDatos($event)" [haveOptions]="true" [haveActions]="true" [actionsTemplate]="actionTemplate">
  <ng-template #headerTemplate>
    <div class="py-10" align="end" style="width: 100%" fxFlex.lg="50" fxFlex.sm="100" title="">
      <button matSuffix mat-raised-button color="accent" (click)="nuevoRegistro()">
        <mat-icon>add</mat-icon>
        ADICIONAR
      </button>
    </div>
  </ng-template>
  <ng-template #columnTemplate let-value="value">
    <span class="column-style">
      <!-- En esta parte se puede personalizar -->
      {{ value }}
    </span>
  </ng-template>
  <ng-template #actionTemplate let-context="context">
    <span fxLayoutGap="5">
      <button mat-button mat-icon-button (click)="editarItem(context)" matTooltip="Actualizar">
        <mat-icon color="orange" aria-hidden="false" aria-label="Editar">edit</mat-icon>
      </button>
      <button mat-button mat-icon-button (click)="eliminarItem(context)" matTooltip="Eliminar">
        <mat-icon color="red" aria-hidden="false" aria-label="Eliminar">delete</mat-icon>
      </button>
    </span>
  </ng-template>
</siat-table-basic>
```

#### Componente en donde usa la tabla (typescript)

```ts
import { Component, OnInit } from "@angular/core";
import { Sort } from "@angular/material/sort";

@Component({
  selector: "app-panel",
  templateUrl: "./panel.component.html",
  styleUrls: ["./panel.component.scss"],
})
export class ExampleComponent implements OnInit {
  tablaCargando: boolean = false;
  displayedColumns: Array<TableColumnModel> = [
    // No se debe mostrar al usuario final el ID por ningún motivo
    {
      name: "Código",
      dataKey: "codigo",
      position: "left",
      isSortable: true,
      isTemplate: true,
      isDate: false,
    },
    {
      name: "Nombre",
      dataKey: "nombre",
      position: "right",
      isSortable: false,
      isTemplate: false,
      isDate: false,
    },
    {
      name: "Apellidos",
      dataKey: "apellido",
      position: "left",
      isSortable: true,
      isTemplate: false,
      isDate: false,
    },
    {
      name: "Teléfono",
      dataKey: "telefono",
      position: "right",
      isSortable: false,
      isTemplate: false,
      isDate: false,
    },
    {
      name: "Correo",
      dataKey: "correo",
      position: "right",
      isSortable: false,
      isTemplate: false,
      isDate: false,
    },
  ];
  personas: Array<Person> = [];

  constructor() {}

  ngOnInit() {
    this.personas = this.getPersons();
  }
  getPersons(): Array<Person> {
    return [
      {
        codigo: 111,
        nombre: "First person lart none da wride",
        apellido: "Last name",
        telefono: 28283461,
        correo: "test1@mail.com",
      },
      {
        codigo: 222,
        nombre: "Second person lart none da wride",
        apellido: "Last name",
        telefono: 28283462,
        correo: "test2@mail.com",
      },
      {
        codigo: 333,
        nombre: "Third person lart none da wride",
        apellido: "Last name",
        telefono: 28283463,
        correo: "tes3@mail.com",
      },
      {
        codigo: 444,
        nombre: "Fourth person lart none da wride",
        apellido: "Last name",
        telefono: 28283464,
        correo: "test4@mail.com",
      },
      {
        codigo: 555,
        nombre: "Fifth person lart none da wride",
        apellido: "Last name",
        telefono: 28283465,
        correo: "test5@mail.com",
      },
    ];
  }

  ordenarDatos(sortColumn: Sort) {
    const keyName = sortColumn.active as keyof Person;
    if (sortColumn.direction === "asc") {
      this.personas = this.personas.sort((a: Person, b: Person) => String(a[keyName]).localeCompare(String(b[keyName])));
    } else if (sortColumn.direction === "desc") {
      this.personas = this.personas.sort((a: Person, b: Person) => String(b[keyName]).localeCompare(String(a[keyName])));
    }
  }

  nuevoRegistro() {}

  editarItem(datos: Person) {}

  eliminarItem(datos: Person) {}
}
```
