import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CoreService, MaterialModule } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';

@Component({
  selector: 'scc-informacion-contribuyente',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule],
  templateUrl: './informacion-contribuyente.component.html',
  styleUrl: './informacion-contribuyente.component.scss',
})
export class InformacionContribuyenteComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente: ContribuyenteModel;
  @Input() esContribuyente: Boolean = false;
  constructor(
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.contribuyente = {};
  }

  ngOnInit() {
    this._datosContribuyente.dataModel$.subscribe((contribuyente) => {
      this.contribuyente = contribuyente;
      this.contribuyente.tipoContribuyentePdrId = 0;
    });
  }

  limpiarNit(): void {
    this._datosContribuyente.setDataModel({});
  }
}
