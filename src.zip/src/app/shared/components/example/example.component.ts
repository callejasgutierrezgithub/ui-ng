import { Component, OnDestroy, OnInit } from '@angular/core';
import { UserInfoService } from 'core-lib';
import { Subscription } from 'rxjs';
import { UserInfo } from 'str-auth-lib';

@Component({
  selector: 'app-example',
  standalone: true,
  imports: [],
  templateUrl: './example.component.html',
  styleUrl: './example.component.scss',
})
export class ExampleComponent implements OnInit, OnDestroy {
  private userInfoSubscription: Subscription | undefined;

  constructor(private _userInfo: UserInfoService) { }

  ngOnInit(): void {
    this.obtenerDatosSesion();
  }

  ngOnDestroy(): void {
    if (this.userInfoSubscription) {
      this.userInfoSubscription.unsubscribe();
    }
  }

  obtenerDatosSesion(): void {
    this.userInfoSubscription = this._userInfo.contextInfo$.subscribe(
      (res: UserInfo) => {
        console.log("--->>", res);
      }
    );
  }
}