import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgxSpinnerModule, } from '@hardpool/ngx-spinner';// Verifica la ruta

import { GrillaMayorDeudaComponent } from '../../../admin/pages/extracto-tributario/grilla-mayor-deuda/grilla-mayor-deuda.component';




@NgModule({  
  imports: [
    BrowserModule,
    FormsModule,
    // NgxSpinnerModule
  ],
  exports: [
    // GrillaMayorDeudaComponent
  ],
  // declarations: [ GrillaMayorDeudaComponent ]
})
export class HardPoolNgxSpinnerModule { }
