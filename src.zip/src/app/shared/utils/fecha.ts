import { DatePipe } from '@angular/common';
import { LocalDate } from './formato-fecha/local-date';


export class Fecha {
  public static format(fecha: LocalDate | null) {
    const datePipe: DatePipe = new DatePipe('en-GB');
    if (fecha) {
      return datePipe.transform(
        new Date(`${fecha.year}-${fecha.month}-${fecha.day}`),
        'dd/MM/yyyy'
      );
    }
    return null;
  }

  public static toDate(fecha: LocalDate | null): Date | null {
    if (fecha) {
      return new Date(`${fecha.year}-${fecha.month}-${fecha.day}`);
    }
    return null;
  }

  public static toLocalDate(fecha: Date): LocalDate | null {
    if (fecha) {
      return {
        year: fecha.getFullYear(),
        month: fecha.getMonth() + 1,
        day: fecha.getDate(),
      };
    }
    return null;
  }

  public static toString(fecha: Date): string {
    const datePipe: DatePipe = new DatePipe('en-GB');
    return datePipe.transform(fecha, 'yyyy-MM-dd')?.toString() ?? '';
  }

  public static toStringLocalDate(fecha: LocalDate): string {
    const formattedDate = `${fecha.year}-${Fecha.padZero(fecha.month)}-${Fecha.padZero(fecha.day)}`;
    return formattedDate;
  }

  public static padZero(num: number): string {
    return num < 10 ? '0' + num : num.toString();
  }

  public static stringToLocalDate(fecha: string | undefined,  formato: 'DMY' | 'YMD' | 'MDY' = 'YMD'): { day: number; month: number; year: number } | null {
    if(fecha != null && fecha != undefined) {
      let day = 0, month = 0, year = 0;
      const normalizada = fecha.replace(/-/g, '/');
      const partes = normalizada.split('/').map(Number);

      switch (formato) {
        case 'DMY':
          [day, month, year] = partes;
          break;
        case 'MDY':
          [month, day, year] = partes;
          break;
        case 'YMD':
        default:
          [year, month, day] = partes;
          break;
      }
      return { day, month, year };
    }
    return null;
  }
}
