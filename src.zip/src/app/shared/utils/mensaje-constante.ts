export class MensajeConstante {
  static readonly MSG_ERROR = 'Error, problemas en el servicio';
  static readonly MSG_SUCCESS = 'Registro Guardado.';
  static readonly MSG_SUCCESS_FOUND = 'Registro encontrado';
  static readonly MSG_SUCCESS_UPDATE = 'Documentos actualizados exitosamente.';
  static readonly MSG_REGISTRO_BOLETA = 'Se realizo el Pago';

  static readonly MSG_DELETE = 'Registro eliminado';
  static readonly MSG_NOT_DELETE = 'No se pudo eliminar el registro';

  static readonly MSG_NOT_RESULT = 'No existen registros';
  static readonly MSG_NOT_RESULT_NIT = 'No se encontró información asociada al NIT.';
  static readonly MSG_NOT_FOUND = 'No existe resultado coincidente';

  static readonly MSG_ERROR_DATA = 'Debe completar los datos requeridos';
  static readonly MSG_NOT_DELETE_DT =
    'No puede eliminar el registro, requiere agregar uno nuevo con el mismo tipo de movimiento';
  static readonly MSG_NOT_UPDATE_DT =
    'No puede modificar el registro, requiere agregar uno nuevo con el mismo tipo de movimiento';

  static readonly MSG_SUCCESS_REDIS =
    'Se registro con exito la informacion en BD Redis';
  static readonly MSG_ERROR_REDIS =
    'No fue posible registrar la informacion en BD Redis';
  static readonly MSG_ERROR_REGISTROS_MANUALES =
    'No se encontro informacion asociada a los criterios de busqueda';
  static readonly MSG_NUMERO_DEUDA = 'NRO DEUDA GENERADA:';
  static readonly MSG_DEUDAS = 'Se requiere una lista de deudas';
  static readonly MSG_ADD = 'Registro agregado con éxito';
  static readonly ERROR_XLSX = 'El excel no cumple con el formato';
  static readonly ERROR_XLSX_P_D_DA = 'El excel no cumple con el formato de proceso, documento y docmuentoAgrupador';
  static readonly ERROR_XLSX_VALIDACION = 'El excel tiene campos vacios';
  static readonly ERROR_FECHA = 'Fecha no valida';
  static readonly ERROR_NIT_CUR = 'Nit no valido';
  static readonly ERROR_NO_EXISTE_PARAMETRICA = 'Parametrica no valida';
  static readonly ERROR_NO_EXISTE_CAUSISTICA_PARA_PARAMETRICA = 'Parametrica sin causistica';
}
