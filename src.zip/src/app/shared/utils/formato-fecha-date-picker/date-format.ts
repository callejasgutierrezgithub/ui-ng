export const FORMATO_FECHA_DIA_MES_ANIO = {
  display: {
    dateInput: 'dd/MM/yyyy',
    monthYearLabel: 'MMM yyyy',
    dateA11yLabel: 'DD/MM/YYYY',
    monthYearA11yLabel: 'MMMM yyyy',
  },
  parse: {
    dateInput: 'dd/MM/yyyy',
  },
};

export const FORMATO_FECHA_MES_ANIO = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export const FORMATO_FECHA_ANIO = {
  display: {
    dateInput: 'YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
  parse: {
    dateInput: 'YYYY',
  },
};