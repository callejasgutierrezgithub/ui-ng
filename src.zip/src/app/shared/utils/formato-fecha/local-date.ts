export interface LocalDate {
  day: number;
  month: number;
  year: number;
}

export function dateToLocalDate(date: Date): LocalDate {
  return {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: date.getDate()
  };
}