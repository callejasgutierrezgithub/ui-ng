import { Operaciones } from '../../enums/operaciones.enum';

export interface PasarDatosDialog<T> {
  operacion: Operaciones;
  datos: T;
}
