import { FormGroup } from '@angular/forms';

export class validarCampoFormulario {
  validarCampo(
    form: FormGroup,
    campo: string,
    label: string,
    maxlength?: number
  ): string {
    return this.campoEsValido(campo, form, label, maxlength);
  }

  campoEsValido(
    campo: string,
    form: FormGroup,
    label: string,
    maxlength?: number
  ): string {
    const control = form.get(campo);
    if (control?.errors && control.touched) {
      if (control.hasError('required')) {
        return 'El campo ' + label + ' es requerido.';
      }
      if (control.hasError('maxlength')) {
        return (
          'El campo ' +
          label +
          ', no puede tener más de ' +
          maxlength +
          ' digitos.'
        );
      }
      if (control.hasError('min')) {
        return 'El campo ' + label + ', tiene que ser mayor a 0';
      }
      if (control.hasError('pattern')) {
        return 'El campo ' + label + ', debe contener solo números';
      }
    }
    return '';
  }
}
