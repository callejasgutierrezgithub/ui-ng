export class Mensajes {
  static readonly CSS_SUCCESS = 'snackbar-success';
  static readonly CSS_ERROR = 'snackbar-error';
  static readonly CSS_WARNING = 'snackbar-warning';
  static readonly CSS_INFO = 'snackbar-info';

  static readonly MSG_ADD = 'Información consultada';
  static readonly MSG_NOT_ADD = 'Registro no agregado';
  static readonly MSG_UPDATE = 'Registro actualizado con éxito';
  static readonly MSG_NOT_UPDATE = 'Registro no actualizado';
  static readonly MSG_DELETE = 'Registro eliminado con éxito';
  static readonly MSG_NOT_DELETE = 'No se pudo eliminar el registro';

  static readonly MSG_ERROR = 'Error, problemas en el servicio!';
  static readonly MSG_SUCCESS = 'Registro guardado con éxito';

  static readonly MSG_NOT_RESULT = 'No existen registros';
  static readonly MSG_NOT_RESULT_CASILLAS =
    'No existen registros de casillas Asociados al formulario y version';

  static readonly MSG_NOT_FOUND = 'No existen resultados conicidentes';

  static readonly CONFIRM_ADD = '¿Está seguro/a de registrar la información?';
  static readonly CONFIRM_UPDATE =
    '¿Está seguro/a de actualizar la información?';
  static readonly CONFIRM_DELETE = '¿Está seguro/a de eliminar';

  // mensajes de alerta de registros
  static readonly CONFIRM_PAYMENT = 'Confirma el Pago de la Deuda';
  static readonly CONFIRM_DEBT = '¿Está seguro/a de Generar deuda?';
  static readonly CONFIRM_COMPENSACION_FAP = '¿Está seguro/a de pagar valores-fap?';

  static readonly RegistroEncontrado = 'Registro encontrado';
  static readonly RegistroNoEncontrado = 'Registro no encontrado';

  static readonly MSG_ACTUALIZACION_DEUDA = 'Deuda Actualizada';
  static readonly MSG_ACTUALIZACION_NO_FOUNT_DEUDA = 'No se encontraron datos para Actualizar la deuda';
  static readonly NIT_NO_CORRESPONDE_A_LA_ADMINISTRACION = 'El Nit no corresponde a la administracion';
  static readonly MSG_OFICINA_ID_IS_NULL = 'Su oficinaId es Null';
  static readonly MSG_ADMINISTRACION_IS_NULL = 'La Administración del Contribuyente es Null';
  static readonly DATOS_NO_ENCONTRADOS_CON_EL_NIT = 'No se encontró información asociada al NIT';
  static readonly DETALLE_USOS_NO_ENCONTRADOS = 'No se encontró Detalle del Uso.';
}
