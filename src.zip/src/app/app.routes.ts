import { Routes } from '@angular/router';
import { PageErrorComponent, rolGuard } from 'core-lib';
import { ExampleComponent } from './shared/components/example/example.component';
export const routes: Routes = [
  {
    path: 'example',
    component: ExampleComponent,
    canActivate: [rolGuard], data: { roles: [10775] }
  },
  {
    path: 'deudas-ley-1340',
    loadComponent: () =>
      import('./admin/pages/scc-pagos-cuenta-ley-trece-page/scc-pagos-cuenta-ley-trece-cuarenta-cuarenta-page.component')
        .then(m => m.SccPagosCuentaLeyTreceCuarentaPageComponent),
    canActivate: [rolGuard], data: { roles: [10775] }
  },
  {
    path: 'imputacion-boletas-pago',
    loadComponent: () =>
      import('./admin/pages/scc-registro-boletas-de-pago/scc-registro-boletas-de-pago.component')
        .then(m => m.SccRegistroBoletasDePagoComponent),
    canActivate: [rolGuard], data: { roles: [10842] }
  },
  {
    path: 'consulta-valores',
    loadComponent: () =>
      import('./admin/pages/sub-cuenta-valores/sub-cuenta-valores.component')
        .then(m => m.SubCuentaValoresComponent),
    canActivate: [rolGuard], data: { roles: [10463] }
  },
  {
    path: 'reporte-adeudo-tributario',
    loadComponent: () =>
      import('./admin/pages/scc-consulta-deudas-por-contribuyente-internas/scc-consulta-deudas-por-contribuyente-internas.component')
        .then(m => m.SccConsultaDeudasPorContribuyenteInternasComponent),
    canActivate: [rolGuard], data: { roles: [10460] }
  },
  {
    path: 'estado-cuenta-contribuyente',
    loadComponent: () =>
      import('./admin/pages/estado-cuenta-contribuyente/estado-cuenta-contribuyente.component')
        .then(m => m.EstadoCuentaContribuyenteComponent),
    canActivate: [rolGuard], data: { roles: [10840] }
  },
  {
    path: 'registro-deudas-manuales',
    loadComponent: () =>
      import('./admin/pages/scc-registro-deudas-manuales/scc-registro-deudas-manuales.component')
        .then(m => m.SccRegistroDeudasManualesComponent),
    canActivate: [rolGuard], data: { roles: [10841] }
  },
  {
    path: 'registro-transacciones-manuales',
    loadComponent: () =>
      import('./admin/pages/scc-registro-transacciones-manuales/scc-registro-transacciones-manuales.component')
        .then(m => m.SccRegistroTransaccionesManualesComponent),
    canActivate: [rolGuard], data: { roles: [10849] }
    // canActivate: [rolGuard], data: { roles: [10849110849] }
  },
  {
    path: 'extracto-tributario',
    loadComponent: () =>
      import('./admin/pages/extracto-tributario/extracto-tributario.component')
        .then(m => m.ExtractoTributarioComponent),
    canActivate: [rolGuard], data: { roles: [10937] }
  },
  {
    path: 'extracto-contribuyente',
    loadComponent: () =>
      import('./admin/pages/extracto-contribuyente/extracto-contribuyente.component')
        .then(m => m.ExtractoContribuyenteComponent),
    // canActivate: [rolGuard], data: { roles: [10839] }
    canActivate: [rolGuard], data: { roles: [91083910839] }
  },
  {
    path: 'calculo-devolucion-indebida',
    loadComponent: () =>
      import('./admin/pages/scc-calculo-devolucion-indebida/scc-calculo-devolucion-indebida.component')
        .then(m => m.SccCalculoDevolucionIndebidaComponent),
    canActivate: [rolGuard], data: { roles: [10776] }
  },
  {
    path: 'log-errores',
    loadComponent: () =>
      import('./admin/pages/log-errores/log-errores.component')
        .then(m => m.LogErroresComponent),
    canActivate: [rolGuard], data: { roles: [10776] }
  },
  {
    path: 'verificar-conexion',
    loadComponent: () =>
      import('./admin/pages/verificar-conexion/verificar-conexion.component')
        .then(m => m.VerificarConexionComponent),
    canActivate: [rolGuard], data: { roles: [10776] }
  },
  {
    path: 'generar-deudas-masivo',
    loadComponent: () =>
      import('./admin/pages/scc-registro-deudas-masivo/scc-registro-deudas-masivo.component')
        .then(m => m.SccRegistroDeudasMasivoComponent),
    canActivate: [rolGuard], data: { roles: [10961] }
  },
  {
    path: 'error',
    component: PageErrorComponent,
  },
];
