import { sliBolsas } from './../../models/bolsas/sli-bolsas';
import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { RespuestaSliBolsas } from '../../models/bolsas/sli-bolsas';

@Injectable({
  providedIn: 'root'
})
export class SliBolsasService extends ModelTokenService<any> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async sliBolsas(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaSliBolsas = await this.getFetch(
      `${this.backAPI}/vista/bolsas/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }
}
