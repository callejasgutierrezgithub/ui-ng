import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';

import { rseExtUrl } from '../../../utils/ApiURL';
import {
  BolsaPagosExcesosModel,
  RespuestaBolsaPagosExcesos,
  RespuestaBolsaPagosExcesosUsos,
  SolicitudPagosExcesosUsos,
} from '../../models/bolsas/bolsa-pagos-excesos';

@Injectable({
  providedIn: 'root',
})
export class BolsaPagosExcesosService extends ModelTokenService<BolsaPagosExcesosModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/pagosExcesos`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerPagosExcesos(nit: number, tipoContribuyentePdrId: number) {
    const respuesta: RespuestaBolsaPagosExcesos = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdrId}`
    );
    return respuesta;
  }

  async obtenerPagosExcesosUsos(solicitud: SolicitudPagosExcesosUsos) {
    const respuesta: RespuestaBolsaPagosExcesosUsos = await this.postFetch(
      `${this.backAPI}/obtener/usos`,
      solicitud
    );
    return respuesta;
  }
}
