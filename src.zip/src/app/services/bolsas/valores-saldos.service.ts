import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  RespuestaValoresSaldosDetalle,
  ValoresSaldosModel,
} from '../../models/consulta-valores/valores-saldos.model';

@Injectable({
  providedIn: 'root',
})
export class ValoresSaldosService extends ModelTokenService<ValoresSaldosModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/valores/saldos`;
  }

  async obtenerSaldosValoresNit(nitCur: number, tipoPdrId: number) {
    const respuesta: RespuestaLista<ValoresSaldosModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nitCur}/${tipoPdrId}`
    );
    return respuesta;
  }

  async obtenerSaldosValoresDetallesNit(nitCur: number, ValorSaldoId: number) {
    const respuesta: RespuestaValoresSaldosDetalle = await this.getFetch(
      `${this.backAPI}/obtener/usos/${nitCur}/${ValorSaldoId}`
    );
    return respuesta;
  }
}
