import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  BolsaIueModel,
  BolsaIueUsosModel,
  SolicitudPagadosIueUso,
} from '../../models/bolsas/bolsa-iue';

@Injectable({
  providedIn: 'root',
})
export class BolsaIueService extends ModelTokenService<BolsaIueModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/pagosIue`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerPagadosIue(nit: number, tipoContribuyentePdrId: number) {
    const respuesta: RespuestaLista<BolsaIueModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdrId}`
    );
    return respuesta;
  }

  async obtenerPagadosIueUsos(solicitud: SolicitudPagadosIueUso) {
    const respuesta: RespuestaLista<BolsaIueUsosModel> = await this.postFetch(
      `${this.backAPI}/obtener/usos`,
      solicitud
    );
    return respuesta;
  }
}
