import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  BolsaExportadoresModel,
  RespuestaBolsaExportadores,
  RespuestaBolsaExportadoresUsos,
} from '../../models/bolsas/bolsa-exportadores';

@Injectable({
  providedIn: 'root',
})
export class BolsaExportadoresService extends ModelTokenService<BolsaExportadoresModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerBolsaExportadores(nit: number) {
    const respuesta: RespuestaBolsaExportadores = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-exportadores/${nit}`
    );
    return respuesta;
  }

  async obtenerBolsaExportadoresUsos(nit: number, bolsaCreditoId: number) {
    const respuesta: RespuestaBolsaExportadoresUsos = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-exportadores-usos/${nit}/${bolsaCreditoId}`
    );
    return respuesta;
  }
}
