import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { BolsaRcIvaModel, BolsaRcIvaUsosModel, SolicitudBolsaRcIvaUsos } from '../../models/bolsas/bolsa-rc-iva';

@Injectable({
  providedIn: 'root'
})
export class BolsaRcIvaService extends ModelTokenService<BolsaRcIvaModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/rcIva`;
  }

  async obtenerRcIva(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaLista<BolsaRcIvaModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  async obtenerRcIvaUsos(pSolicitud: SolicitudBolsaRcIvaUsos) {
    const respuesta: RespuestaLista<BolsaRcIvaUsosModel> =
      await this.postFetch(`${this.backAPI}/obtener/usos`, pSolicitud);
    return respuesta;
  }
}