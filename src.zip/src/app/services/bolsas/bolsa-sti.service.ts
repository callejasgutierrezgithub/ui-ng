import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  BolsaStiModel,
  BolsaStiUsosModel,
  SolicitudBolsaStiUso,
} from '../../models/bolsas/bolsa-sti';

@Injectable({
  providedIn: 'root',
})
export class BolsaStiService extends ModelTokenService<BolsaStiModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/sti`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerBolsaSti(nit: number, tipoPdrId: number) {
    const respuesta: RespuestaLista<BolsaStiModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoPdrId}`
    );
    return respuesta;
  }

  async obtenerBolsaStiUsos(solicitud: SolicitudBolsaStiUso) {
    const respuesta: RespuestaLista<BolsaStiUsosModel> = await this.getFetch(
      `${this.backAPI}/obtener/usos/${solicitud.nitCur}/${solicitud.bolsaStiId}`
    );
    return respuesta;
  }
}
