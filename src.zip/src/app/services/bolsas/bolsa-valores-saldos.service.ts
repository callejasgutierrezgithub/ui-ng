import { Injectable } from '@angular/core';
import { rseExtUrl } from '../../../utils/ApiURL';
import { ModelTokenService, SesionService } from 'core-lib';
import { RespuestaBolsaValoresSaldos } from '../../models/bolsas/bolsa-valores-saldos.model';
import { RespuestaBolsaValoresSaldosDetalles } from '../../models/bolsas/bolsa-valores-saldos-detalles.model';

@Injectable({
  providedIn: 'root'
})
export class BolsaValoresSaldosService extends ModelTokenService<any> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerValoresSaldos(nit: number) {    
    const respuesta: RespuestaBolsaValoresSaldos = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-valores-saldos/${nit}`      
    );
    return respuesta;
  }

  async obtenerValoresSaldosDetalles (nit: number, bolsaSietergId: number) {
    const respuesta: RespuestaBolsaValoresSaldosDetalles = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-valores-saldos-detalles/${nit}/${bolsaSietergId}`
    );
    return respuesta;
  }
}