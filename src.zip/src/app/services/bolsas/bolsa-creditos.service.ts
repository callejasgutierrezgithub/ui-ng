import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { BolsaCreditosModel } from '../../models/bolsas/bolsa-creditos';
import {
  BolsaCreditosUsosModel,
  SolicitudBolsaCreditosUsos,
} from '../../models/bolsas/bolsa-creditos-usos';
import { rseExtUrl } from '../../../utils/ApiURL';
import { RespuestaSccBolsasModel } from '../../models/bolsas/scc-bolsa';

@Injectable({
  providedIn: 'root',
})
export class BolsaCreditosService extends ModelTokenService<BolsaCreditosModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/creditoMercadoInterno`;
  }

  async obtenerCreditos(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaLista<BolsaCreditosModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  async obtenerCreditosUsos(pSolicitud: SolicitudBolsaCreditosUsos) {
    const respuesta: RespuestaLista<BolsaCreditosUsosModel> = await this.postFetch(`${this.backAPI}/obtener/usos`, pSolicitud);
    await this.delay(200);
    return respuesta;
  }

  /* ********************** */
  async obtenerSccBolsas(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaSccBolsasModel = await this.getFetch(
      `http://localhost:39641/rest/vista/bolsas/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
