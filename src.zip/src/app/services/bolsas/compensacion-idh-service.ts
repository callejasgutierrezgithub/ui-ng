import { Injectable } from '@angular/core';
import { ModelService, SesionService } from 'core-lib';

import {
  CompensacionesIdhModel,
  RespuestaCompensacionesIdh,
} from '../../models/bolsas/compensaciones-idh.model';
import { RespuestaCompensacionesIdhUsos } from '../../models/bolsas/compensaciones-idh-usos.model';
import { rseExtUrl } from '../../../utils/ApiURL';

@Injectable({
  providedIn: 'root',
})
export class BolsaCompensacionesIdhService extends ModelService<CompensacionesIdhModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super();
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerCompensacionesIdh(
    nitCur: number,
    tipoContribuyentePdrId: number
  ) {
    const respuesta: RespuestaCompensacionesIdh = await this.getFetch(
      `${this.backAPI}/idh/obtener/${nitCur}/${tipoContribuyentePdrId}`
    );
    return respuesta;
  }

  async obtenerCompensacionesIdhUsos(solicitud: any) {
    const respuesta: RespuestaCompensacionesIdhUsos = await this.postFetch(
      `${this.backAPI}/idh/obtener/usos`,
      solicitud
    );
    return respuesta;
  }
}
