import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  BolsaIceModel,
  BolsaIceUsosModel,
  SolicitudBolsaIceUso,
} from '../../models/bolsas/bolsa-ice';

@Injectable({
  providedIn: 'root',
})
export class BolsaIceService extends ModelTokenService<BolsaIceModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/ice`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerBolsaIce(nit: number, tipoPdrId: number) {
    const respuesta: RespuestaLista<BolsaIceModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoPdrId}`
    );
    return respuesta;
  }

  async obtenerBolsaIceUsos(solicitud: SolicitudBolsaIceUso) {
    const respuesta: RespuestaLista<BolsaIceUsosModel> = await this.getFetch(
      `${this.backAPI}/obtener/usos/${solicitud.nitCur}/${solicitud.bolsaIceId}`
    );
    return respuesta;
  }
}
