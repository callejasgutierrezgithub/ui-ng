import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import {
  SieteRgModel,
  RespuestaSieteRg,
} from '../../models/bolsas/siete-rg.model';
import {
  RespuestaSieteRgUsos,
  SolicitudSieteRgUsos,
} from '../../models/bolsas/siete-rg-usos.model';

@Injectable({
  providedIn: 'root',
})
export class SieteRgService extends ModelTokenService<SieteRgModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerSieteRg(nit: number, tipoContribuyentePdrId: number) {
    const respuesta: RespuestaSieteRg = await this.getFetch(
      `${this.backAPI}/sieteRg/obtener/${nit}/${tipoContribuyentePdrId}`
    );
    return respuesta;
  }

  async obtenerSieteRgUsos(solicitud: SolicitudSieteRgUsos) {
    const respuesta: RespuestaSieteRgUsos = await this.postFetch(
      `${this.backAPI}/sieteRg/obtener/usos`,
      solicitud
    );
    return respuesta;
  }
}
