import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import {
  BolsaPagosModel,
  BolsaPagosUsosModel,
  SolicitudBolsaPagosUsosModel,
} from '../../models/bolsas/bolsa-pagos';
import { rseExtUrl } from '../../../utils/ApiURL';

@Injectable({
  providedIn: 'root',
})
export class BolsaPagosService extends ModelTokenService<BolsaPagosModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/pagos`;
  }

  async obtenerBolsaPagos(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaLista<BolsaPagosModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  async obtenerBolsaPagosUsos(pSolicitud: SolicitudBolsaPagosUsosModel) {
    const respuesta: RespuestaLista<BolsaPagosUsosModel> = await this.postFetch(
      `${this.backAPI}/obtener/usos`,
      pSolicitud
    );
    await this.delay(200);
    return respuesta;
  }
  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
