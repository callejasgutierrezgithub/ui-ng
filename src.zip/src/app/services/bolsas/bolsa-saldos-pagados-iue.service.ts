import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from "core-lib";
import { rseExtUrl } from "../../../utils/ApiURL";
import { RespuestaBolsaSaldosPagadosIue } from "../../models/bolsas/bolsa-saldos-pagados-iue.model";


@Injectable({
  providedIn: 'root'
})
export class BolsaSaldosPagadosIueService extends ModelTokenService<any> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerBolsaSaldosPagadosIue(nit: number) {    
    const respuesta: RespuestaBolsaSaldosPagadosIue = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-saldos-pagados-iue/${nit}`      
    );
    return respuesta;
  }

  async obtenerBolsaSaldosPagadosIueUsos(nit: number, bolsaCreditoId: number) {
    const respuesta: RespuestaBolsaSaldosPagadosIue = await this.getFetch(
      `${this.backAPI}/scc-mig-obtener-bolsa-saldos-pagados-iue-usos/${nit}/${bolsaCreditoId}`
    );
    return respuesta;
  }
}