import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { BolsaCreditoExternoModel } from '../../models/bolsas/bolsa-creditos-externo';
import { BolsaCreditoExternoUsosModel, SolicitudBolsaCreditosExternoUsos } from '../../models/bolsas/bolsa-creditos-externo-usos';

@Injectable({
  providedIn: 'root'
})
export class BolsaCreditoExternoService extends ModelTokenService<BolsaCreditoExternoModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/creditoExterno`;
  }

  async obtenerCreditosExterno(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaLista<BolsaCreditoExternoModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  async obtenerCreditosExternoUsos(pSolicitud: SolicitudBolsaCreditosExternoUsos) {
    const respuesta: RespuestaLista<BolsaCreditoExternoUsosModel> =
      await this.postFetch(`${this.backAPI}/obtener/usos`, pSolicitud);
    return respuesta;
  }
}
