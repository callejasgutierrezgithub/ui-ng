import { Injectable } from '@angular/core';
import {
  ModelService,
  ModelTokenService,
  RespuestaLista,
  SesionService,
} from 'core-lib';
import {
  BolsaFapModel,
  BolsaFapUsosModel,
  SolicitudBolsaFapUsos,
} from '../../models/bolsas/bolsa-fap';
import { rseExtUrl } from '../../../utils/ApiURL';

@Injectable({
  providedIn: 'root',
})
export class BolsaFapService extends ModelTokenService<BolsaFapModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/facilidadesPago`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerFacilidadesPago(nit: number, tipoContribuyentePdr: number) {
    const respuesta: RespuestaLista<BolsaFapModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nit}/${tipoContribuyentePdr}`
    );
    return respuesta;
  }

  async obtenerFacilidadesPagoUsos(pSolicitud: SolicitudBolsaFapUsos) {
    const respuesta: RespuestaLista<BolsaFapUsosModel> = await this.postFetch(
      `${this.backAPI}/obtener/usos`,
      pSolicitud
    );
    return respuesta;
  }
}
