import { Injectable } from "@angular/core";
import { DialogService, ModelTokenService, Respuesta, RespuestaLista, RespuestaObjeto, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { PagosLeyTreceCuarentaModel } from "../../models/deudas-trece-cuarenta/pagos-ley-treceCuarenta.model";
import { RepositorioLiquidacionLeyTreceCuarentaModel, RequestRepositorioPagosLeyTreceCuarentaModel, ResponseRepositorioPagosLeyTreceCuarentaModel, SolicitudPagosTreceCuarenta } from '../../models/deudas-trece-cuarenta/pagos-treceCuarenta.model';

@Injectable({
  providedIn: 'root',
})
export class DeudasTreceCuarentaService extends ModelTokenService<PagosLeyTreceCuarentaModel> {
  private backAPI: string;

  constructor(
    private sesionService: SesionService,    
    private dialogService: DialogService
  ) {
    super(sesionService);    
    this.backAPI = `${rseExtUrl}/rest`;
  }

  async obtenerDatosDeudaTreceCuarenta(nitCur: number, deudaId: number) {
    const respuesta: RespuestaObjeto<RepositorioLiquidacionLeyTreceCuarentaModel> = await this.getFetch(      
      `${this.backAPI}/sli-obtener-dato-deuda/${nitCur}/${deudaId}`      
    );
    if (respuesta.transaccion) {      
      return respuesta;
    }
    return respuesta;
  }
  
  async obtenerListaDeudasTreceCuarenta(pSolicitud: SolicitudPagosTreceCuarenta) {
    const respuesta: RespuestaLista<ResponseRepositorioPagosLeyTreceCuarentaModel> = await this.postFetch(      
      `${this.backAPI}/sli-obtener-deuda-pagos-ley-trece-cuarenta`, pSolicitud 
    );
    if (respuesta.transaccion) {      
      return respuesta;
    }
    return respuesta;
  }

  async registrarRepositorioPagoTreceCuarenta(pSolicitud: RequestRepositorioPagosLeyTreceCuarentaModel) {
    const respuesta: Respuesta = await this.postFetch(      
      `${this.backAPI}/sli-registrar-deuda-pagos-ley-trece-cuarenta`, pSolicitud
    );    
    return respuesta;
  }
}