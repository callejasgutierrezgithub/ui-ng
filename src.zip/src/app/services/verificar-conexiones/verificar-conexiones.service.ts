import { Injectable } from '@angular/core';
import { ModelService, SesionService, Respuesta, RespuestaLista } from 'core-lib';
import { ConexionMultBaseModel, RespuestaConexionMultiBase, SccVerificaConexionesDto } from '../../models/verificar-conexiones/verificar-conexiones.model';
import { rseExtUrl } from '../../../utils/ApiURL';

@Injectable({
  providedIn: 'root',
})
export class VerificarConexionesService extends ModelService<ConexionMultBaseModel> {
  private rseExt: string;

  constructor(private sesionService: SesionService) {
    super();
    this.rseExt = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerVerificarConexiones(api: string) {
    const respuesta: RespuestaConexionMultiBase = await this.getFetch(
      `${this.rseExt}/multibd/conexion/verificar/${api}`      
    );

    return respuesta;
  }

  async obtenerVerificaConeciones(){
    const respuesta: RespuestaLista<SccVerificaConexionesDto> = await this.getFetch(
      `${this.rseExt}/multibd/conexion/obtener`      
    );

    return respuesta;
  }

  async registrarVerificaConeciones(){
    const respuesta: Respuesta = await this.getFetch(
      `${this.rseExt}/multibd/conexion/registrar`      
    );

    return respuesta;
  }
}
