import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SccRegistroTransaccionesManualesStoreService {
private deudas = signal<Array<number>>([]);
  
  setDeudas(pDeudas: Array<number>): void {
    this.deudas.set(pDeudas);    
  }

  getDeudas() {
    return this.deudas;
  }
}
