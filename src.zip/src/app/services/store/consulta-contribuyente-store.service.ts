import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConsultaContribuyenteStoreService {
  private consultaNit = signal<boolean>(false);
  private mensaje = signal<string>('');

  getConsultaNit() {
    return this.consultaNit;
  }
  setConsultaNit(pConsultaNit: boolean): void {
    this.consultaNit.set(pConsultaNit);
  }

  getMensaje() {
    return this.mensaje;
  }
  setMensaje(pMensaje: string): void {
    this.mensaje.set(pMensaje);
  }
}
