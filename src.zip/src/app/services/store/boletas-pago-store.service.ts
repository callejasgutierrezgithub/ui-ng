import { Injectable, signal } from '@angular/core';
import {
  DetalleDeudaModel
} from '../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudRegistrarBoletasPagoModel } from '../../models/registro-boletas-de-pagos/solicitud-registrar-boletas-pago';
import { BoletasPagoModel } from './../../models/registro-boletas-de-pagos/boletas-pagos';

@Injectable({
  providedIn: 'root',
})
export class BoletasPagoStoreService {
  private boletasPago = signal<BoletasPagoModel>({});
  private detalleDeuda = signal<DetalleDeudaModel>({});
  private deudasPadre = signal<Array<DetalleDeudaModel>>([]);
  private deudasHijo = signal<Array<DetalleDeudaModel>>([]);

  setBoletasPago(pBoletasPago: SolicitudRegistrarBoletasPagoModel): void {
    this.boletasPago.set(pBoletasPago);
  }

  getBoletasPagos() {
    return this.boletasPago;
  }

  setDetalleDeuda(pDetalleDeuda: DetalleDeudaModel): void {
    this.detalleDeuda.set(pDetalleDeuda);
  }

  getDetalleDeuda() {
    return this.detalleDeuda;
  }
  setDeudasPadre(pDeudas: Array<DetalleDeudaModel>): void {
    this.deudasPadre.set(pDeudas);
  }

  getDeudasPadre() {
    return this.deudasPadre;
  }
  setDeudasHijo(pDeudas: Array<DetalleDeudaModel>): void {
    this.deudasHijo.set(pDeudas);
  }

  getDeudasHijo() {
    return this.deudasHijo;
  }
}
