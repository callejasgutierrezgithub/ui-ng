import { Injectable } from "@angular/core";
import { ModelTokenService, SesionService } from "core-lib";
import { RespuestaContribuyente } from "../../models/contribuyente/respuesta-contribuyente.model";
import { Subject } from "rxjs";
import { parApiUrl } from "../../../utils/ApiURL";
import { SolicitudValorEconomico } from "../../models/valores-economicos/solicitud-valor-economico.model";
import { RespuestaValorEconomico } from "../../models/valores-economicos/respuesta-valor-economico.model";
import { FormularioModel, RespuestaFormulario } from "../../models/impuesto-asociado/formulario.model";
import { RespuestaImpuestos } from "../../models/impuesto-asociado/impuesto.model";

@Injectable({
  providedIn: 'root',
})
export class ParametricaValoresEconomicosService extends ModelTokenService<any> {
  private mensajeSubject = new Subject<RespuestaContribuyente>();
  contribuyente$ = this.mensajeSubject.asObservable();

  private sccParApi: string;
  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.sccParApi = `${parApiUrl}/rest`;
  }
  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }
  async obtenerValoresEconomicos(solicitud: SolicitudValorEconomico) {
    const respuesta: RespuestaValorEconomico = await this.postFetch(
      `${this.sccParApi}/valoresEconomicos/obtener/valor`,
      solicitud
    );    
    return respuesta;
  }

  async obtenerImpuestos() {
    const respuesta: RespuestaImpuestos = await this.getFetch(
      `${this.sccParApi}/impuestos/obtener`
    );
    return respuesta;
  }

  async obtenerFormularios(formulario: FormularioModel) {
    const respuesta: RespuestaFormulario = await this.getFetch(
      `${this.sccParApi}/formularios/obtener/${formulario.id}`
    );
    return respuesta;
  }
}
