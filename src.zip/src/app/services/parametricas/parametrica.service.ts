import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { parApiUrl } from '../../../utils/ApiURL';
import { MonedaEnum } from '../../enums/general.enum';
import { RespuestaContravenciones } from '../../models/parametrica/par-contravenciones.model';
import {
  ParametricaGenericaModel,
  ParametroModel,
} from '../../models/parametrica/parametrica-generica.model';
import {
  RespuestaParametrica,
  RespuestaParametricaGenericaModel,
} from '../../models/parametrica/respuesta-parametrica-generica.model';

@Injectable({
  providedIn: 'root',
})
export class ParametricaService extends ModelTokenService<
  RespuestaParametrica<ParametricaGenericaModel>
> {
  private backAPI: string;
  private cuentasPadre: RespuestaParametrica<ParametricaGenericaModel>;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${parApiUrl}/rest`;
    this.cuentasPadre = {} as RespuestaParametrica<ParametricaGenericaModel>;
  }

  async obtenerParametricas(solicitud: ParametroModel) {
    try {
      const respuesta: RespuestaParametricaGenericaModel = await this.postFetch(
        `${this.backAPI}/parametricas/obtener`,
        solicitud
      );

      if (respuesta.transaccion && respuesta.data.tipo_moneda_id) {
        respuesta.data.tipo_moneda_id = respuesta.data.tipo_moneda_id.filter(
          (item: ParametricaGenericaModel) =>
            item.id == MonedaEnum.BOLIVIANOS_ID || item.id == MonedaEnum.DOLARES_ID
        );
      }

      this.setDataModel(respuesta.data);
    } catch (error) { }
  }

  async obtenerContravenciones() {
    const respuesta: RespuestaContravenciones = await this.getFetch(
      `${this.backAPI}/contravenciones/obtener`
    );

    return respuesta;
  }

  async obtenerParametricasOrigen(solicitud: ParametroModel) {
    const respuesta: RespuestaParametricaGenericaModel = await this.postFetch(
      `${this.backAPI}/parametricas/obtener`,
      solicitud
    );
    return respuesta;
  }
}
