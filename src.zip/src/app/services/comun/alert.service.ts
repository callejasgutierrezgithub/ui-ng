import { Injectable } from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { Mensaje } from 'core-lib';
import { EstilosAlerta } from '../../../utils/estilos-alerta';

@Injectable({
  providedIn: 'root',
})
export class AlertService {
  readonly showDuration: number = 5000;
  readonly horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  readonly verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(private snackBar: MatSnackBar) {}

  success(message: string) {
    return this.snackBar.open(message, undefined, {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: this.showDuration,
      panelClass: [EstilosAlerta.CSS_SUCCESS],
    });
  }

  error(message: Mensaje[] | string) {
    if (message instanceof Array) {
      return message.forEach((msg: Mensaje, index) => {
        setTimeout(() => {
          this.snackBar.open(msg.descripcion, undefined, {
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            duration: this.showDuration,
            panelClass: [EstilosAlerta.CSS_ERROR],
          });
        }, index * this.showDuration);
      });
    } else {
      return this.snackBar.open(message, undefined, {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: this.showDuration,
        panelClass: [EstilosAlerta.CSS_ERROR],
      });
    }
  }

  warning(message: Mensaje[] | string) {
    if (message instanceof Array) {
      return message.forEach((msg: Mensaje, index) => {
        setTimeout(() => {
          this.snackBar.open(msg.descripcion, undefined, {
            duration: this.showDuration,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
            panelClass: [EstilosAlerta.CSS_WARNING],
          });
        }, index * this.showDuration);
      });
    } else {
      return this.snackBar.open(message, undefined, {
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
        duration: this.showDuration,
        panelClass: [EstilosAlerta.CSS_WARNING],
      });
    }
  }

  info(message: string) {
    return this.snackBar.open(message, undefined, {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: this.showDuration,
      panelClass: [EstilosAlerta.CSS_INFO],
    });
  }
}
