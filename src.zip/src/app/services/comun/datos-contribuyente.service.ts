import { Injectable } from "@angular/core";
import { LoadingService, ModelService, RespuestaLista, RespuestaObjeto, SesionService, SiatToastrService } from "core-lib";
import { NgxSpinnerService } from "ngx-spinner";
import { Subject } from "rxjs";
import { rseExtUrl } from "../../../utils/ApiURL";
import { ContribuyenteModel, SolicitudContribuyenteModel } from "../../models/contribuyente/contribuyente.model";
import { RespuestaContribuyente } from "../../models/contribuyente/respuesta-contribuyente.model";
import { AdministracionHijoModel } from "../../models/contribuyente/administracion.model";

@Injectable({
  providedIn: 'root',
})
export class DatosContribuyenteService extends ModelService<any> {
  private backRseAPI: string;
  private mensajeSubject = new Subject<RespuestaObjeto<ContribuyenteModel>>();
  contribuyente$ = this.mensajeSubject.asObservable();

  constructor(
    public loadingService: LoadingService,
    private sesionService: SesionService,
    private toastr: SiatToastrService,
    private spinnerService: NgxSpinnerService) {
    super();
    this.backRseAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  obtenerDependencia() {
    return this.sesionService.getDataModel().userInfo.contribuyente
      ?.dependenciaId;
  }

  obtenerUsuarioInfo() {
    return this.sesionService.getDataModel().userInfo;
  }

  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  //--------------------------------
  // // **Para pruebas local Contribuyente Quemado**
  // async obtenerContribuyente(nit: number) {
  //   const datosPorDefecto: RespuestaContribuyente = {
  //     transaccion: true,
  //     objeto: {
  //       administracion: 76,
  //       contribuyenteId: 123,
  //       estadoNit: "1",
  //       estadoDescripcion: "ACTIVO HABILITADO",
  //       razonSocial: "luz.callisaya",
  //       // nit: 6147382016,
  //       nit: 183024024,
  //       // nit: 121241029,
  //       // nit: 183024024,
  //       tipoContribuyenteId: 723,
  //       tipoContribuyentePdrId: 0
  //     },
  //     mensajes: []
  //   };

  //   this.spinnerService.show();
  //   const respuesta: RespuestaContribuyente = await datosPorDefecto
  //   if (respuesta.transaccion) {
  //     this.setDataModel({ ...respuesta.objeto as ContribuyenteModel });
  //     if (respuesta.objeto.administracion == null) this.toastr.warning('No se encontro datos de oficinaId del contribuyente con el Nit: ' + respuesta.objeto.nit);
  //   } else {
  //     this.toastr.info('No se encontraron datos del contribuyente');
  //   }
  //   await this.delay(900);
  //   this.spinnerService.hide();
  //   return respuesta;
  // }


  async obtenerContribuyente(nit: number) {
    const vSolicitud: SolicitudContribuyenteModel = {
      nitCur: Number(nit),
      origen: 1,
      datos: [1]
    }
    this.spinnerService.show();
    const respuesta: RespuestaContribuyente = await this.postFetch(
      `${this.backRseAPI}/contribuyente/obtener`, vSolicitud
    );
    if (respuesta.transaccion) {
      this.setDataModel({ ...respuesta.objeto as ContribuyenteModel });
      if (respuesta.objeto.administracion == null) this.toastr.warning('No se encontro datos de oficinaId del contribuyente con el Nit: ' + respuesta.objeto.nit);
    } else {
      this.toastr.info('No se encontraron datos del contribuyente');
    }

    await this.delay(400);
    this.spinnerService.hide();
    return respuesta;
  }

  async obtenerAdministracionHijos(oficinaId: number) {
    this.spinnerService.show();
    const respuesta: RespuestaLista<AdministracionHijoModel> = await this.getFetch(
      `${this.backRseAPI}/administracionHijos/obtener/${oficinaId}`
    );
    return respuesta;
  }

  datosContribuyente(contribuyente: RespuestaObjeto<ContribuyenteModel>) {
    this.mensajeSubject.next(contribuyente);
  }
}
