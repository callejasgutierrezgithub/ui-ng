import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { ddjjExtUrl, parApiUrl } from '../../../utils/ApiURL';
import { RespuestaFormulario, RespuestaFormularioDdjj } from '../../models/impuesto-asociado/formulario.model';

@Injectable({
  providedIn: 'root'
})
export class FormularioDdjjService extends ModelTokenService<any> {
  private backAPI: string;
  private backParAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${ddjjExtUrl}/rest`;
    this.backParAPI = `${parApiUrl}/rest`;
  }

  async obtenerFormularios() {
    const respuesta: RespuestaFormularioDdjj = await this.getFetch(
      `${this.backAPI}/obtenerFormulariosRp`
    );
    return respuesta;
  }

  async parDocumentoQuePaga() {
    const respuesta: RespuestaFormulario = await this.getFetch(
      `${this.backParAPI}/parametricas/obtener/tipoParametrica`
    );
    return respuesta;
  }
}
