import { Injectable } from '@angular/core';
import {
  DialogService,
  ModelTokenService,
  Respuesta,
  SesionService,
} from 'core-lib';
import { OpcionApi } from '../../utils/ApiURL';

@Injectable({
  providedIn: 'root',
})
export class ExampleService extends ModelTokenService<any> {
  constructor(
    private sesionService: SesionService,
    private dialogService: DialogService
  ) {
    super(sesionService);
  }

  /**
   * Muestra los errores de las peticiones HTTP y mostrarlo en un DialogService
   * El metodo debe estar envuelto en un bloque try-catch para manejar cualquier error de la solicitud HTTP 
   */
  async obtenerExample(): Promise<any> {
    try {
      const respuesta = await this.getFetch(OpcionApi + '/pruebas-example');
      if (respuesta.transaccion) {
        this.setDataList(respuesta.objetosList);
      }
      return respuesta;
    } catch (error) {
      this.dialogService.setRespuesta(error as Respuesta);
      throw error;
    }
  }
}
