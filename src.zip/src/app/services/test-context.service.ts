import { Injectable } from '@angular/core';
import { AppContextService, DatosAuthServerService, SesionService } from 'core-lib';

@Injectable({
  providedIn: 'root',
})
export class TestContextService extends AppContextService {
  /**
   * DatosAuthServerService   --> se utiliza para ejecutar la aplicación en modo PRODUCCION
   * DatosAuthLocalService    --> se utiliza para ejecutar la aplicación en modo LOCAL
   *
   * Cargar clasificadores y otros transversales
   */
  constructor(
    private datosAuthService: DatosAuthServerService,
    private sesionService: SesionService
  ) {
    super();
    sesionService.setDatosAuthService(datosAuthService);
  }

  obtenerDatos(): Promise<any> {
    return this.datosAuthService.obtenerDatos();
  }
}
