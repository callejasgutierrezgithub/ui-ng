import { Injectable } from "@angular/core";
import { ModelTokenService, Respuesta, RespuestaLista, SesionService } from "core-lib";
import { rseExtUrl } from "../../utils/ApiURL";
import { SolicitudRegistroBitacoraModel } from "../models/bitacora-consultas/bitacora-consultas";

@Injectable({
  providedIn: 'root',
})
export class BitacoraConsultasService extends ModelTokenService<any> {
  private sliRseApi: string;
  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.sliRseApi = `${rseExtUrl}/rest`;
  }

    async registrarBitacoraConsultas(pSolicitud: SolicitudRegistroBitacoraModel) {
        const respuesta: Respuesta = await this.postFetch(
          `${this.sliRseApi}/bitacora/registrar`, pSolicitud
        );
        return respuesta;
    }
}