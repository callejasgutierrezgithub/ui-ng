import { Injectable } from '@angular/core';
import { DatosAuthService, SesionService } from 'core-lib';


@Injectable({
  providedIn: 'root',
})
export class DatosAuthLocalService extends DatosAuthService {

  constructor(private sesionService: SesionService) {
    super();
  }

  async obtenerDatos(): Promise<any> {
    const datosFake = {
      sessionId: 'sdf',
      accessToken: 'eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJIdTBVVkFSMWk2ZjVpSHJmQmJ1eEY1V2c2T0Q5aU5UTU82ZUtDY0hMMDhvIn0.eyJleHAiOjE3MzEzNzQ1ODQsImlhdCI6MTczMTM2MDE4NCwianRpIjoiNjNjMjgzMDgtZDUzYS00ZTlmLThiNDItNDllNzRkNTEyODFjIiwiaXNzIjoiaHR0cHM6Ly9kZXNhbG9naW4uaW1wdWVzdG9zLmdvYi5iby9yZWFsbXMvbG9naW4iLCJhdWQiOiJhY2NvdW50Iiwic3ViIjoiYWZhM2ZkOTUtODM0Ny00NmQyLWEwMTQtMDNiMjQyNjFkMzVjIiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiYXBwLWZyb250ZW5kIiwic2Vzc2lvbl9zdGF0ZSI6IjM3MzUwYWJlLTJmNTQtNDRmYi1hYTkxLWJiMjc4NTYyZTQ5YyIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiaHR0cHM6Ly9kZXNhc2lhdC5pbXB1ZXN0b3MuZ29iLmJvIiwiaHR0cDovL2xvY2FsaG9zdDo0MjAxIiwiaHR0cHM6Ly9sYWJvazhzLmltcHVlc3Rvcy5nb2IuYm8iLCJodHRwOi8vMTAuMS4zNi40OjgwODAvKiIsImh0dHA6Ly9sb2NhbGhvc3Q6MzgwNzEiLCJodHRwOi8vbG9jYWxob3N0OjQyMDAiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iLCJkZWZhdWx0LXJvbGVzLXNpYXQiXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6InByb2ZpbGUgc2lhdF9zY29wZSBlbWFpbCIsInNpZCI6IjM3MzUwYWJlLTJmNTQtNDRmYi1hYTkxLWJiMjc4NTYyZTQ5YyIsInV1aWRyIjoiODQyMWQ5NjYtYzkzMS00YmY3LThjNmEtZWZkOWE0MjBlOGYzIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiTFVJUyBGRVJOQU5ETyBMQU5EQUVUQSIsInByZWZlcnJlZF91c2VybmFtZSI6Imx1aXMubGFuZGFldGEtMTA0MjYiLCJnaXZlbl9uYW1lIjoiTFVJUyBGRVJOQU5ETyIsImxvZ2luIjoibHVpcy5sYW5kYWV0YSIsInVzdWFyaW9JZCI6MTA0MjYsImZhbWlseV9uYW1lIjoiTEFOREFFVEEiLCJlbWFpbCI6Imx1aXNsYW5kYWV0YUBsaXZlLmNvbSJ9.m08Y6UEdX1DSJ-ph73oTTtrXY3pTV_X4KRmBnjrS-C5qgt2KvYMVFz1duZOU6u1hYC_pIB5-TiCq9nSf6RORF08tEnxbFXDQUlXpHdbsCIfMd1Nd0PtgA_E-Q4tPcfl_JIwfKiwWwk-QsPBIdWdcezWrLQH5JLfXxQYLoLpw3Hfc0Kdo9ElwgWhG5TPWNUkRwoi5R3Wk-U7WhTZl27sp0vFQDVyBFxznIuRhHkArrJYaugzG1UMRaZudH7d430c2TXQbPHviFPBTyM_pTqcF2yeillX2gTu7d0empeI8F5gvwJ2JVFOjYOWK_VBG2ePi_q5Ac3EjXuFtWO46DdUUlg',
      refreshToken: 'sdfdds',
      roles: [
        10458,
        10459,
        10460,
        10461,
        10462,
        10463,
        10464,
        10775,
        10776,
        10937,
        10841,
        10849,
        10842,
        10839,
        10840,
        10941,
      ],
      userInfo: {
        sub: '762b0f08-cb36-4740-9d3c-6bf1cf80fe3a',
        primerApellido: 'Perez',
        estadoUsuarioId: 565,
        segundoApellido: 'Perez',
        tipoUsuarioId: 861,
        login: 'juan.perez@impuestos.gob.bo',
        nombreCompleto: 'Juan Perez Perez',
        razonSocial: 'Los Juanes',
        usuarioId: 5000445,
        nombres: 'Juan',
        uuidr: 'f1e2d147-6b9a-4227-9ffb-b9e55afea839',
        nitCur: '4081482013',
        personaId: 4499561,
        dependenciaId: 100000023,
        entidadId: 3,
        dependencia: 'GERENCIA DISTRITAL COCHABAMBA',
        entidad: 'BANCO UNION',
      },
    };
    this.sesionService.setDataModel(datosFake as any);
    return datosFake;
  }

  actualizarToken(): void { }

  cerrarSesion(): void {
  }
}
