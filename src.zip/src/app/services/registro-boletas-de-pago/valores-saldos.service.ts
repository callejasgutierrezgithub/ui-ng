import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { ValoresSaldosModel } from '../../models/consulta-valores/valores-saldos.model';

@Injectable({
  providedIn: 'root',
})
export class ValoresSaldosService extends ModelTokenService<any> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/valoresSaldos`;
  }

  async obtenerValoresSaldos(nitCur: number, tipoPdrId: number) {
    const respuesta: RespuestaLista<ValoresSaldosModel> = await this.getFetch(
      `${this.backAPI}/obtener/${nitCur}/${tipoPdrId}`
    );
    return respuesta;
  }

  async obtenerValoresSaldosDetalle(nitCur: number, valorSaldoId: number) {
    const respuesta: RespuestaLista<ValoresSaldosModel> = await this.getFetch(
      `${this.backAPI}/obtener/usos/${nitCur}/${valorSaldoId}`
    );
    return respuesta;
  }
}
