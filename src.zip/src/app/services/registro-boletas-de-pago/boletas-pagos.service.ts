import { Injectable } from '@angular/core';
import { DialogService, ModelTokenService, Respuesta, RespuestaLista, RespuestaObjeto, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { BoletasPagoModel, VerificarBoletasPagoModel } from '../../models/registro-boletas-de-pagos/boletas-pagos';
import { SolicitudVerificarBoletasPago } from '../../models/registro-boletas-de-pagos/solicitud-verificar-boletas-pago';

@Injectable({
  providedIn: 'root'
})
export class BoletasPagosService extends ModelTokenService<BoletasPagoModel> {
  private backAPI: string;

  constructor(
    private _sesionService: SesionService,
    private _dialogService: DialogService,
  ) {
    super(_sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }


  async obtenerBoletasPago(pNitCur: number) {
    const respuesta: RespuestaLista<BoletasPagoModel> = await this.getFetch(
      `${this.backAPI}/boletasPagos/obtener/` + pNitCur
    );
    if (respuesta.transaccion) {
      return respuesta;
    }
    return respuesta;
  }

  async verificarBoletasPago(pSolicitud: SolicitudVerificarBoletasPago) {
    const respuesta: RespuestaObjeto<VerificarBoletasPagoModel> = await this.postFetch(
      `${this.backAPI}/boletasPagos/verificar`, pSolicitud
    );
    if (respuesta.transaccion) {
      return respuesta;
    }
    return respuesta;
  }

  async registrarBoletasPago(pSolicitud: FormData) {
    let token = await this.getAccesToken();
    const respuesta = await fetch(`${this.backAPI}/boletasPagos/registrar`, {
      method: 'POST',
      headers: {
        'Authorization': 'Token ' + token,
      },
      body: pSolicitud
    });

    let response: Respuesta = await respuesta.json();
    return response;
  }
}