import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { DeudaExtracto } from '../../models/extracto-tributario/deuda-extracto-model';
import { MayorPorDeuda } from '../../models/extracto-tributario/mayor-deuda-model';

@Injectable({
  providedIn: 'root',
})
export class ExtractoTributario extends ModelTokenService<MayorPorDeuda> {
  private backAPI: string = '';

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  async obtenerDeudas(vNitCur: number, vTipoPdrId: number) {
    const respuesta: RespuestaLista<DeudaExtracto> = await this.getFetch(
      `${this.backAPI}/extracto/obtener/${vNitCur}/${vTipoPdrId}`
    );
    return respuesta;
  }

  async obtenerMayorDeudaPorNitDeuda(vSolicitud: any) {
    const respuesta: RespuestaLista<MayorPorDeuda> = await this.postFetch(
      `${this.backAPI}/mayoresPorDeudaMovimientos/obtener`,
      vSolicitud
    );
    return respuesta;
  }
}
