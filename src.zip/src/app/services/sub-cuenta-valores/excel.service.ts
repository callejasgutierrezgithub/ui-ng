import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';

@Injectable({
  providedIn: 'root',
})
export class ExcelService {
  async generarExcel(registros: any, nombreArchivo: string) {
    await import('xlsx').then(async (xlsx) => {
      const worksheet = xlsx.utils.json_to_sheet(registros);
      const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
      const excelBuffer: any = await xlsx.write(workbook, {
        bookType: 'xlsx',
        type: 'array',
      });
      const archivo: Blob = new Blob([excelBuffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8',
      });
      return FileSaver.saveAs(
        archivo,
        `${nombreArchivo}_${new Date()
          .toISOString()
          .slice(0, 19)
          .replace(/[-:T]/g, '')}.xlsx`
      );
    });
  }
}
