import { Injectable } from '@angular/core';
import { ModelTokenService, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { SolicitudValoresSaldo } from '../../models/consulta-valores/solicitud-valores.model';
import {
  RespuestaValoresSaldosDetalle,
  RespuestaValoresSaldoRedimidosPorFecha,
  ValoresSaldosModel,
} from '../../models/consulta-valores/valores-saldos.model';

@Injectable({
  providedIn: 'root',
})
export class ConsultaValoresService extends ModelTokenService<ValoresSaldosModel> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest/valoresSaldos`;
  }

  async obtenerValoresSaldos(pSolicitud: SolicitudValoresSaldo) {
    const respuesta: RespuestaValoresSaldoRedimidosPorFecha =
      await this.postFetch(
        `${this.backAPI}/obtener/RedimidosPorFecha`,
        pSolicitud
      );
    return respuesta;
  }

  async obtenerUsoValores(valoresSaldo: ValoresSaldosModel) {
    const respuesta: RespuestaValoresSaldosDetalle = await this.getFetch(
      `${this.backAPI}/obtener/usos/${valoresSaldo.contribuyenteId}/${valoresSaldo.id}`
    );
    return respuesta;
  }

  async obtenerValoresRedimidos(solicitud: SolicitudValoresSaldo) {
    const respuesta: RespuestaValoresSaldoRedimidosPorFecha =
      await this.postFetch(
        `${this.backAPI}/scc-obtener-valores-redimidos`,
        solicitud
      );
    return respuesta;
  }
}
