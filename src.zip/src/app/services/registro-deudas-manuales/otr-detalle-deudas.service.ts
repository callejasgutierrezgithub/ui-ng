import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, RespuestaObjeto, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { RespuestaDetalleDeudas } from '../../models/detalle-deudas-contribuyente/respuesta-detalle-deudas';
import { SolicitudActualizarDocumentos } from '../../models/documentos-agrupadores/solicitud-actualizar-documentos.model';
import { DeudaPagoModel } from '../../models/reporte-adeudo-tributario/deuda-pago.model';
import { SolicitudValidarFechas, SolicitudValidarNitCur } from '../../models/documentos-agrupadores/solicitud-validar-fechas-model';
import { DeudaGenericaDetalle } from '../../models/documentos-agrupadores/deuda-generica-detalle.model';

@Injectable({
  providedIn: 'root',
})
export class OtrDetalleDeudasService extends ModelTokenService<any> {
  private sliRseExt: string;
  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.sliRseExt = `${rseExtUrl}/rest`;
  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }
  async obtenerDetallePagos(pSolicitud: any) {
    const respuesta: RespuestaLista<DeudaPagoModel> = await this.postFetch(
      `${this.sliRseExt}/sli-obtener-detalle-pagos`,
      pSolicitud
    );
    return respuesta;
  }

  // async obtenerDetalleDeudasPorNitCUr(nitCur: number) {
  //   const respuesta: RespuestaDetalleDeudas = await this.getFetch(
  //     `${this.sliRseExt}/sli-obtener-detalle-deudas-por-nitCur/${nitCur}`
  //   );
  //   return respuesta;
  // }

  async obtenerDetalleDeudasPorNitCUr(pSolicitud: any) {
    const respuesta: RespuestaLista<DeudaGenericaDetalle> = await this.postFetch(
      `${this.sliRseExt}/deudas/actualizadas/liquidacion/obtener`, pSolicitud
    );
    return respuesta;
  }

  async actualizarDocumentos(solicitud: SolicitudActualizarDocumentos) {
    const respuesta: RespuestaDetalleDeudas = await this.postFetch(
      `${this.sliRseExt}/sli-actualizar-documentos`,
      solicitud
    );
    return respuesta;
  }

  async validarFechas(solicitud: SolicitudValidarFechas) {
    const respuesta: RespuestaObjeto<boolean> = await this.postFetch(
      `${this.sliRseExt}/diaHabil/validar`,
      solicitud
    );
    return respuesta;
  }

  async validarNitCurs(solicitud: SolicitudValidarNitCur) {
    const respuesta: RespuestaObjeto<boolean> = await this.postFetch(
      `${this.sliRseExt}/nitCurs/validar`,
      solicitud
    );
    return respuesta;
  }
}
