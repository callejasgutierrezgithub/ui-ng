import { Injectable } from '@angular/core';
import {
  ModelTokenService,
  Respuesta,
  RespuestaLista,
  SesionService
} from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { RepuestaListaDeudasManualesModel } from '../../models/documentos-agrupadores/deudas-manuales-model';
import {
  DocumentoAgrupadorModel
} from '../../models/documentos-agrupadores/documento-agrupador-model';
import { RespuestaDeudaGenerica } from '../../models/documentos-agrupadores/respuesta-deuda-generica.model';
import { SolicitudDocumentoAgrupadores } from '../../models/documentos-agrupadores/solicitud-agrupadores.model';
import { SolicitudDeudaBs } from '../../models/documentos-agrupadores/solicitud-deudas-bs.model';
import { SolicitudDeudasManualesModel } from '../../models/documentos-agrupadores/solicitud-deudas-manuales.model';
import { SolicitudDeudaUfv } from '../../models/documentos-agrupadores/solicitud-deudas-ufv.model';
import { SolicitudDeudaMontoCongelarRd, SolicitudRegistrosManuales } from '../../models/documentos-agrupadores/solicitud-registros-manuales';

@Injectable({
  providedIn: 'root',
})
export class DocumentosAgrupadoresService extends ModelTokenService<DocumentoAgrupadorModel> {
  private rseExt: string;
  constructor(
    private sesionService: SesionService
  ) {
    super(sesionService);
    this.rseExt = `${rseExtUrl}/rest`;
  }

  async registroDatosAgrupadores(solicitud: SolicitudDocumentoAgrupadores) {
    const respuesta: DocumentoAgrupadorModel = await this.postFetch(
      `${this.rseExt}/sli-registrar-registros-manuales`,
      solicitud
    );
    return respuesta;
  }
  async obtenerRegistroManuales(solicitud: SolicitudRegistrosManuales) {
    const respuesta: RespuestaLista<DocumentoAgrupadorModel> =
      await this.postFetch(
        `${this.rseExt}/sli-obtener-documentos-agrupados-manual`,
        solicitud
      );
    return respuesta;
  }

  async obtenerDeudasManuales(solicitud: SolicitudDeudasManualesModel) {
    const respuesta: RepuestaListaDeudasManualesModel = await this.postFetch(
      `${this.rseExt}/sli-obtener-documentos-manual-liquidaciones`,
      solicitud
    );
    return respuesta;
  }

  async registrarDeudaGenericaBsUsd(solicitud: SolicitudDeudaBs) {
    const respuesta: RespuestaDeudaGenerica = await this.postFetch(
      `${this.rseExt}/deudas/genericaBsUsd/registrar`,
      solicitud
    );
    return respuesta;
  }
  async registrarDeudaGenericaUfv(solicitud: SolicitudDeudaUfv) {
    const respuesta: RespuestaDeudaGenerica = await this.postFetch(
      `${this.rseExt}/deudas/genericaUfv/registrar`,
      solicitud
    );
    return respuesta;
  }
  async deudaMontoCongelarRd(solicitud: SolicitudDeudaMontoCongelarRd) {
    const respuesta: Respuesta = await this.postFetch(
      `${this.rseExt}/deudas/montos/congelar/vistaCargoRd`,
      solicitud
    );
    return respuesta;
  }
}
