import { Injectable } from "@angular/core";
import { ModelService, RespuestaLista, SesionService } from "core-lib";
import { Observable, Subject } from "rxjs";
import { rseExtUrl } from "../../../utils/ApiURL";
import { ErrorModel, ListaErroresTableModel } from "../../models/log-errores/log-errores-model";

@Injectable({
  providedIn: 'root'
})
export class LogErroresService extends ModelService<ErrorModel> {
  private rseExt: string;

  private erroresSubject = new Subject<ListaErroresTableModel | undefined>();
  private erroresObservable$ = this.erroresSubject.asObservable();

  constructor(private sesionService: SesionService) {
    super();
    this.rseExt = `${rseExtUrl}/rest`;

  }

  override getAccesToken() {
    return this.sesionService.getAccesToken();
  }

  getErroresSubject(): Subject<ListaErroresTableModel | undefined> {
    return this.erroresSubject;
  }

  getErroresObservable(): Observable<ListaErroresTableModel | undefined> {
    return this.erroresObservable$;
  }

  async obtenerLitaErrores() {
    var pSolicitud = {
      fechaInicio: new Date(),
      fechaFin: new Date(),
    }
    const respuesta: RespuestaLista<ErrorModel> =
      await this.postFetch(`${this.rseExt}/log/obtener`, pSolicitud);
    return respuesta;
  }
}