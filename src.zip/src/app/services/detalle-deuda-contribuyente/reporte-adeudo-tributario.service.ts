import { Injectable } from '@angular/core';
import { ModelTokenService, RespuestaLista, SesionService } from 'core-lib';
import { rseExtUrl } from '../../../utils/ApiURL';
import { DetalleDeudaModel } from '../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudDetalleDeuda, SolicitudDetalleDeudaPeriodoFormulario } from '../../models/detalle-deudas-contribuyente/solicitud-detalle-deudas.model';
import { SolicitudActualizaDeudas } from '../../models/deudas-actualizadas-model';

@Injectable({
  providedIn: 'root',
})
export class ReporteAdeudoTributarioService extends ModelTokenService<any> {

  private backAPI: string;
  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  async obtenerDetalleDeuda(solicitud: SolicitudDetalleDeuda) {
    const respuesta: RespuestaLista<DetalleDeudaModel> =
      await this.postFetch(
        `${this.backAPI}/deudas/actualizadas`,
        solicitud
      );
    return respuesta;
  }
  async obtenerDetalleLiquidacion(solicitud: any) {
    const respuesta: RespuestaLista<DetalleDeudaModel> =
      await this.postFetch(
        `${this.backAPI}/sli-obtener-detalle-liquidaciones`,
        solicitud
      );
    return respuesta;
  }

  async obtenerActualizadasDeudas(solicitud: SolicitudActualizaDeudas) {
    const respuesta: RespuestaLista<DetalleDeudaModel> =
      await this.postFetch(
        `${this.backAPI}/deudas/actualizarAid`,
        solicitud
      );
    return respuesta;
  }

  async obtenerDeudasHitoricas(nitCur: number, deudaId: number) {
    const respuesta: RespuestaLista<DetalleDeudaModel> =
      await this.getFetch(
        `${this.backAPI}/liquidaciones/obtenerHistorico/${nitCur}/${deudaId}`);
    return respuesta;
  }

  async obtenerDeudasHitoricasPeriodoFormulario(pSolicitud: SolicitudDetalleDeudaPeriodoFormulario) {
    const respuesta: RespuestaLista<DetalleDeudaModel> =
      await this.postFetch(
        `${this.backAPI}/deudas/aid/actualizar`, pSolicitud);
    return respuesta;
  }

}


