import { Injectable } from "@angular/core";
import { ModelTokenService, SesionService } from "core-lib";
import { rseExtUrl } from "../../../utils/ApiURL";
import { RespuestaCalculoIndebido } from "../../models/calculo-devolucion-indebida/respuesta-calculo-indebido.model";
import { SolicitudCalculoIndebido } from "../../models/calculo-devolucion-indebida/solicitud-calculo-indebido.model";

@Injectable({
  providedIn: 'root',
})
export class CalculoDevolucionIndebidaService extends ModelTokenService<RespuestaCalculoIndebido> {
  private backAPI: string;

  constructor(private sesionService: SesionService) {
    super(sesionService);
    this.backAPI = `${rseExtUrl}/rest`;
  }

  async calcularDebolucionIndebida(solicitud: SolicitudCalculoIndebido) {
    const respuesta: RespuestaCalculoIndebido = await this.postFetch(
      `${this.backAPI}/sli-calcular-monto-indebido`,
      solicitud
    );
    return respuesta;
  }
}
