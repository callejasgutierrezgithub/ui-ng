import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaCreditoExternoModel } from '../../../../models/bolsas/bolsa-creditos-externo';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { BolsaCreditoExternoService } from '../../../../services/bolsas/bolsa-credito-externo.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaCreditoExternoUsosComponent } from './scc-bolsa-credito-externo-usos/scc-bolsa-credito-externo-usos.component';

@Component({
  selector: 'scc-bolsa-credito-externo',
  standalone: true,
  imports: [MaterialModule, CommonModule, SccBolsaCreditoExternoUsosComponent, LocaldatePipe],
  templateUrl: './scc-bolsa-credito-externo.component.html',
  styleUrl: './scc-bolsa-credito-externo.component.scss'
})
export class SccBolsaCreditoExternoComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() dataSourceArray: BolsaCreditoExternoModel[] = [];
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: BolsaCreditoExternoModel;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private bolsaCreditoExternoService: BolsaCreditoExternoService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'creditoExternoBs',
      'saldoCreditoExternoBs',
      'detalle',
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaCreditoExternoModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaCreditoExternoModel) {
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
