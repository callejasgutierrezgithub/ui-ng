import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, SimpleChanges } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaCreditoExternoModel } from '../../../../../models/bolsas/bolsa-creditos-externo';
import { BolsaCreditoExternoUsosModel, SolicitudBolsaCreditosExternoUsos } from '../../../../../models/bolsas/bolsa-creditos-externo-usos';
import { BolsaCreditoExternoService } from '../../../../../services/bolsas/bolsa-credito-externo.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-credito-externo-usos',
  standalone: true,
  imports: [MaterialModule, CommonModule, LocaldatePipe],
  templateUrl: './scc-bolsa-credito-externo-usos.component.html',
  styleUrl: './scc-bolsa-credito-externo-usos.component.scss'
})
export class SccBolsaCreditoExternoUsosComponent {
  @Input() bolsa: BolsaCreditoExternoModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<BolsaCreditoExternoUsosModel>([]);
  mensaje: string;
  loading: Boolean;
  constructor(
    private bolsaCreditoExternoService: BolsaCreditoExternoService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoDestino',
      'anioDestino',
      'montoCreditoBs',
    ];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaCreditosExternoUsos(data: BolsaCreditoExternoModel) {
    this.loading = true;
    const pSolicitud: SolicitudBolsaCreditosExternoUsos = {
      nitCur: data.nitCur,
      creditoExternoId: data.id,
      tipoContribuyentePdrId: 0,
    };
    this.bolsaCreditoExternoService
      .obtenerCreditosExternoUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaCreditoExternoUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.id) {
      this.obtenerBolsaCreditosExternoUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
