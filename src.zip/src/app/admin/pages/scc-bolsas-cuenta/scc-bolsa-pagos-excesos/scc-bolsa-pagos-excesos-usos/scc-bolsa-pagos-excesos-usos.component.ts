import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaPagosExcesosModel,
  BolsaPagosExcesosUsosModel,
  SolicitudPagosExcesosUsos,
} from '../../../../../models/bolsas/bolsa-pagos-excesos';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaPagosExcesosService } from '../../../../../services/bolsas/bolsa-pagos-excesos.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { BolsaRcIvaModel } from '../../../../../models/bolsas/bolsa-rc-iva';
import { DatosContribuyenteService } from '../../../../../services/comun/datos-contribuyente.service';
import { ContribuyenteModel } from '../../../../../models/contribuyente/contribuyente.model';

@Component({
  selector: 'scc-bolsa-pagos-excesos-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-pagos-excesos-usos.component.html',
  styleUrl: './scc-bolsa-pagos-excesos-usos.component.scss',
})
export class SccBolsaPagosExcesosUsosComponent {
  @Input() bolsa: BolsaPagosExcesosModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<BolsaPagosExcesosUsosModel>([]);
  filaSeleccionada: BolsaPagosExcesosModel;
  contribuyente!: ContribuyenteModel;
  @Input() dataSourceArray: BolsaPagosExcesosModel[] = [];
  mensaje: string;
  loading: Boolean;
  constructor(
    private pagosExcesosService: BolsaPagosExcesosService,
    private _datosContribuyente: DatosContribuyenteService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'montoExcesoBs',
      'mantenimientoValorBs',
    ];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.filaSeleccionada = {};
    this.loading = true;
  }

  ngOnInit(): void {
    this.getContribuyten();
  }


  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }


  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  obtenerPagosExcesosUsos(data: BolsaPagosExcesosModel) {
    this.loading = true;
    const pSolicitud: SolicitudPagosExcesosUsos = {
      nitCur: data.nitCur!,
      bolsaExcesoId: data.id,
      tipoContribuyentePdrId: 0,
    };
    this.pagosExcesosService
      .obtenerPagosExcesosUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaPagosExcesosUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }



  // ngOnChanges(changes: SimpleChanges): void {
  //   if (changes['bolsa'] && this.bolsa?.id) {
  //     this.obtenerPagosExcesosUsos(this.bolsa);
  //   }
  // }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
