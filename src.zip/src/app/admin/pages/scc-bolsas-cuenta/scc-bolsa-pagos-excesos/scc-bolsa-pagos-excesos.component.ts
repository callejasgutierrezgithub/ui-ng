import { CommonModule } from '@angular/common';
import { AfterViewChecked, Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { MatTableDataSource } from '@angular/material/table';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { BolsaPagosExcesosModel } from '../../../../models/bolsas/bolsa-pagos-excesos';
import { SccBolsaPagosExcesosUsosComponent } from './scc-bolsa-pagos-excesos-usos/scc-bolsa-pagos-excesos-usos.component';
import { BolsaPagosExcesosService } from '../../../../services/bolsas/bolsa-pagos-excesos.service';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-pagos-excesos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaPagosExcesosUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-pagos-excesos.component.html',
  styleUrl: './scc-bolsa-pagos-excesos.component.scss',
})
export class SccBolsaPagosExcesosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: BolsaPagosExcesosModel;
  @Input() dataSourceArray: BolsaPagosExcesosModel[] = [];

  mensaje: string;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  contribuyente!: ContribuyenteModel;
  constructor(
    private pagosExcesosService: BolsaPagosExcesosService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoExcesoBs',
      'saldoExcesoBs',
      'detalle',
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaPagosExcesosModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerPagosExcesosUsos(fila: BolsaPagosExcesosModel) {
    console.log("usos -> ", fila);

    fila.nitCur = this.contribuyente.nit;
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
