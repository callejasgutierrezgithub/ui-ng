import { CommonModule } from '@angular/common';
import { AfterViewChecked, Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaSieteRgUsosComponent } from './scc-bolsa-sieterg-usos/scc-bolsa-sieterg-usos.component';
import { SieteRgModel } from '../../../../models/bolsas/siete-rg.model';
import { SieteRgService } from '../../../../services/bolsas/siete-rg.service';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-sieterg',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaSieteRgUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-sieterg.component.html',
  styleUrl: './scc-bolsa-sieterg.component.scss',
})
export class SccBolsaSieteRgComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() dataSourceArray: SieteRgModel[] = [];
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: SieteRgModel;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private sieteRgService: SieteRgService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.tableLoading = false;
    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoBs',
      'saldoMontoBs',
      'detalle'
    ];
    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<SieteRgModel>([]);
    this.mensaje = '';
  }
  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }

  seleccionaFila(fila: SieteRgModel) {
    this.filaSeleccionada = fila;
  }
}
