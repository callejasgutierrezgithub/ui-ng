import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  SieteRgUsosModel,
  SolicitudSieteRgUsos,
} from '../../../../../models/bolsas/siete-rg-usos.model';
import { SieteRgModel } from '../../../../../models/bolsas/siete-rg.model';
import { SieteRgService } from '../../../../../services/bolsas/siete-rg.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-sieterg-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-sieterg-usos.component.html',
  styleUrl: './scc-bolsa-sieterg-usos.component.scss',
})
export class SccBolsaSieteRgUsosComponent implements OnInit {
  @Input() bolsa: SieteRgModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  loading: boolean;
  mensaje: string;
  dataSource = new MatTableDataSource<SieteRgUsosModel>([]);

  constructor(private sietergService: SieteRgService, private cd: ChangeDetectorRef) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoUso',
      'anioUso',
      'montoBs'];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  ngOnInit(): void { }

  obtenerSieteRgUsos(data: SieteRgModel) {
    this.loading = true;
    const pSolicitud: SolicitudSieteRgUsos = {
      nitCur: data.nitCur,
      tipoContribuyentePdrId: 0,
      bolsaSietergId: data.id!,
    };
    this.sietergService
      .obtenerSieteRgUsos(pSolicitud)
      .then((respuesta: RespuestaLista<SieteRgUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.id) {
      this.obtenerSieteRgUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
