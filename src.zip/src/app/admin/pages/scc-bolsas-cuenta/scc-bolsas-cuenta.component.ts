import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { SccBolsaCreditosComponent } from './scc-bolsa-creditos/scc-bolsa-creditos.component';
import { SccBolsaFapComponent } from './scc-bolsa-fap/scc-bolsa-fap.component';
import { SccBolsaIueComponent } from './scc-bolsa-iue/scc-bolsa-iue.component';
import { SccBolsaPagosComponent } from './scc-bolsa-pagos/scc-bolsa-pagos.component';
import { SccBolsaValoresSaldosComponent } from './scc-bolsa-valores-saldos/scc-bolsa-valores-saldos.component';

@Component({
  selector: 'scc-bolsas-cuenta',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule, MatNativeDateModule, FormsModule,
    SccBolsaCreditosComponent, SccBolsaFapComponent, SccBolsaIueComponent, SccBolsaPagosComponent, SccBolsaValoresSaldosComponent],
  templateUrl: './scc-bolsas-cuenta.component.html',
  styleUrl: './scc-bolsas-cuenta.component.scss'
})
export class SccBolsasCuentaComponent implements OnInit {
  contribuyente: ContribuyenteModel;
  dataSource;
  verValoresSaldos: boolean = false;
  constructor(
    private _datosContribuyente: DatosContribuyenteService,
  ) {
    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);
    this.contribuyente = {};
  }

  ngOnInit() {
    this.getContribuyten();
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
      if (contribuyente && contribuyente.nit) {
        this.contribuyente = contribuyente;
      }
    });
  }

  consultaBolsaCreditos() {
    this.verValoresSaldos = !this.verValoresSaldos;
  }

}
