import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaPagosModel,
  BolsaPagosUsosModel,
  SolicitudBolsaPagosUsosModel,
} from '../../../../../models/bolsas/bolsa-pagos';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaPagosService } from '../../../../../services/bolsas/bolsa-pagos.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-pagos-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-pagos-usos.component.html',
  styleUrl: './scc-bolsa-pagos-usos.component.scss',
})
export class SccBolsaPagosUsosComponent {
  @Input() bolsa: BolsaPagosModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<BolsaPagosUsosModel>([]);
  loading: Boolean;
  mensaje: string;

  constructor(
    private bolsaPagosService: BolsaPagosService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'montoBs',
    ];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaPagosUsos(data: BolsaPagosModel) {
    this.loading = true;
    const pSolicitud: SolicitudBolsaPagosUsosModel = {
      nitCur: data.nitCur!,
      bolsaPagoId: data.id,
      tipoContribuyentePdrId: 0,
    };
    this.bolsaPagosService
      .obtenerBolsaPagosUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaPagosUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.id) {
      this.obtenerBolsaPagosUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
