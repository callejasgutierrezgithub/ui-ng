import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule } from 'core-lib';
import { BolsaPagosModel } from '../../../../models/bolsas/bolsa-pagos';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { BolsaPagosService } from '../../../../services/bolsas/bolsa-pagos.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { SccBolsaPagosUsosComponent } from './scc-bolsa-pagos-usos/scc-bolsa-pagos-usos.component';

@Component({
  selector: 'scc-bolsa-pagos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaPagosUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-pagos.component.html',
  styleUrl: './scc-bolsa-pagos.component.scss',
})
export class SccBolsaPagosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  @Input() dataSourceArray: BolsaPagosModel[] = [];
  filaSeleccionada: BolsaPagosModel;
  mensaje: string;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  contribuyente!: ContribuyenteModel;
  constructor(
    private bolsaPagosService: BolsaPagosService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoBs',
      'saldoPagoCuentaBs',
      'detalle',
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaPagosModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaPagosModel) {
    fila.nitCur = this.contribuyente.nit;
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
