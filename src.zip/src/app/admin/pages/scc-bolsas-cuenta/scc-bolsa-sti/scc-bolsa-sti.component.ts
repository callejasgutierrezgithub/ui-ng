import { AfterViewChecked, Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';

import { BolsaStiModel } from '../../../../models/bolsas/bolsa-sti';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { BolsaStiService } from '../../../../services/bolsas/bolsa-sti.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaStiUsosComponent } from './scc-bolsa-sti-usos/scc-bolsa-sti-usos.component';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-sti',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaStiUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-sti.component.html',
  styleUrl: './scc-bolsa-sti.component.scss',
})
export class SccBolsaStiComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() contribuyente!: any;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  @Input() dataSourceArray: BolsaStiModel[] = [];
  filaSeleccionada: BolsaStiModel;
  mensaje: string;
  @ViewChild('hijo') stiUsosComponent!: SccBolsaStiUsosComponent;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private iueService: BolsaStiService,
    private contribuyenteService: DatosContribuyenteService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoBs',
      'saldoBs',
      'detalle'
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaStiModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.obtenerContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  obtenerContribuyten(): void {
    this.contribuyenteService.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
          this.obtenerBolsaSti(this.contribuyente.nit!);
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  obtenerBolsaSti(nit: number) {
    this.tableLoading = true;
    let tipoPdrId = 0;
    this.iueService
      .obtenerBolsaSti(nit, tipoPdrId)
      .then((respuesta: RespuestaLista<BolsaStiModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
          this.mensaje =
            this.dataSource.data.length === 0 ? Mensajes.MSG_NOT_RESULT : '';
        }
      })
      .finally(() => {
        this.tableLoading = false;
      });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaStiModel) {
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
