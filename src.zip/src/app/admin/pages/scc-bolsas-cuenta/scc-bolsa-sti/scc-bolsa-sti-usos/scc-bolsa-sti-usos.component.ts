import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaStiModel,
  BolsaStiUsosModel,
  SolicitudBolsaStiUso,
} from '../../../../../models/bolsas/bolsa-sti';
import { BolsaStiService } from '../../../../../services/bolsas/bolsa-sti.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-sti-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-sti-usos.component.html',
  styleUrl: './scc-bolsa-sti-usos.component.scss',
})
export class SccBolsaStiUsosComponent {
  @Input() bolsa: BolsaStiModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource;
  loading: Boolean;
  mensaje: string;

  constructor(
    private stiService: BolsaStiService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'montoBs',
    ];
    this.dataSource = new MatTableDataSource<SolicitudBolsaStiUso>([]);
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaStiUsos(data: BolsaStiModel) {
    this.loading = true;
    let solicitud: SolicitudBolsaStiUso = {
      nitCur: data.nitCur,
      tipoPdrId: 0,
      bolsaStiId: data.bolsaStiId,
    };
    this.stiService
      .obtenerBolsaStiUsos(solicitud)
      .then((respuesta: RespuestaLista<BolsaStiUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.bolsaStiId) {
      this.obtenerBolsaStiUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
