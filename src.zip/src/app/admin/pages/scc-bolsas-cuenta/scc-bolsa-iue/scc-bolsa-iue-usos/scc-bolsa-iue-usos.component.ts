import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaIueModel,
  BolsaIueUsosModel,
  SolicitudPagadosIueUso,
} from '../../../../../models/bolsas/bolsa-iue';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaIueService } from '../../../../../services/bolsas/bolsa-iue.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-iue-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-iue-usos.component.html',
  styleUrl: './scc-bolsa-iue-usos.component.scss',
})
export class SccBolsaIueUsosComponent {
  @Input() bolsa: BolsaIueModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<any>([]);
  mensaje: string;
  loading: Boolean;
  constructor(
    private BolsaIueService: BolsaIueService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoIt', 'anioIt', 'montoCompensadoBs'];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = true;
  }

  obtenerPagadosIueUsos(data: BolsaIueModel) {
    this.loading = true;
    const pSolicitud: SolicitudPagadosIueUso = {
      nitCur: data.nitCur,
      pagadoIueId: data.pagadoIueId,
      tipoContribuyentePdrId: 0,
    };
    this.BolsaIueService.obtenerPagadosIueUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaIueUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.deudaId) {
      this.obtenerPagadosIueUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
