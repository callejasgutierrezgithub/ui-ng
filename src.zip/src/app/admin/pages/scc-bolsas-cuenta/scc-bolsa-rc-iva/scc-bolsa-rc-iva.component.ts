import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule } from 'core-lib';
import { BolsaRcIvaModel } from '../../../../models/bolsas/bolsa-rc-iva';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { BolsaRcIvaService } from '../../../../services/bolsas/bolsa-rc-iva.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { SccBolsaRcIvaUsosComponent } from './scc-bolsa-rc-iva-usos/scc-bolsa-rc-iva-usos.component';

@Component({
  selector: 'scc-bolsa-rc-iva',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaRcIvaUsosComponent,
    LocaldatePipe
  ],
  templateUrl: './scc-bolsa-rc-iva.component.html',
  styleUrl: './scc-bolsa-rc-iva.component.scss'
})
export class SccBolsaRcIvaComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() dataSourceArray: BolsaRcIvaModel[] = [];
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: BolsaRcIvaModel;
  ordenAscendente = true;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private BolsaRcIvaService: BolsaRcIvaService,
    private _datosContribuyente: DatosContribuyenteService,
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'creditoRcivaBs',
      'saldoCreditoRcivaBs',
      'detalle',
    ];
    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaRcIvaModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaRcIvaModel) {
    fila.nitCur = this.contribuyente.nit;
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}