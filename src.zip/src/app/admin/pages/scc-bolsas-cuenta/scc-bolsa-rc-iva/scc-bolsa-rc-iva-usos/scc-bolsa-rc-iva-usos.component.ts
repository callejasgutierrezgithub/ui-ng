import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaRcIvaModel, BolsaRcIvaUsosModel, SolicitudBolsaRcIvaUsos } from '../../../../../models/bolsas/bolsa-rc-iva';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaRcIvaService } from '../../../../../services/bolsas/bolsa-rc-iva.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-rc-iva-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  templateUrl: './scc-bolsa-rc-iva-usos.component.html',
  styleUrl: './scc-bolsa-rc-iva-usos.component.scss'
})
export class SccBolsaRcIvaUsosComponent {
  @Input() bolsa: BolsaRcIvaModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource;
  loading: Boolean;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(
    private BolsaRcIvaService: BolsaRcIvaService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'creditoRcivaBs',
      'mantenimientoValorBs',
    ];
    this.dataSource = new MatTableDataSource<BolsaRcIvaUsosModel>([]);
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaCreditosUsos(data: BolsaRcIvaModel) {
    this.loading = true;
    const pSolicitud: SolicitudBolsaRcIvaUsos = {
      nitCur: data.nitCur,
      bolsaRcivaId: data.bolsaRcIvaId,
      tipoContribuyentePdrId: 0,
    };
    this.BolsaRcIvaService
      .obtenerRcIvaUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaRcIvaUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.bolsaRcIvaId) {
      this.obtenerBolsaCreditosUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
