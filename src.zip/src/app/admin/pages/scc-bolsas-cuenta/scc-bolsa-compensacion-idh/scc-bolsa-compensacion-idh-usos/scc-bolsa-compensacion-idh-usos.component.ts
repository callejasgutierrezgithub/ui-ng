import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  CompensacionesIdhUsosModel,
  SolicitudCompensacionIhdUsos,
} from '../../../../../models/bolsas/compensaciones-idh-usos.model';
import { CompensacionesIdhModel } from '../../../../../models/bolsas/compensaciones-idh.model';
import { ContribuyenteModel } from '../../../../../models/contribuyente/contribuyente.model';
import { BolsaCompensacionesIdhService } from '../../../../../services/bolsas/compensacion-idh-service';
import { DatosContribuyenteService } from '../../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-compensacion-idh-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-compensacion-idh-usos.component.html',
  styleUrl: './scc-bolsa-compensacion-idh-usos.component.scss',
})
export class SccBolsaCompensacionIdhUsosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<CompensacionesIdhUsosModel>([]);
  loading: boolean;
  mensaje: string;

  constructor(
    private compensacionesIdhService: BolsaCompensacionesIdhService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.columnas = [
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'compensacionBs',
      'mantenimientoValorBs',
    ];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.dataSource.data = [];
        }
      }
    );
  }

  obtenerCompensacionesIdhUsos(data: CompensacionesIdhModel) {
    this.loading = true;
    const pSolicitud: SolicitudCompensacionIhdUsos = {
      nitCur: data.nitCur,
      bolsaCompensacionId: data.bolsaCompensacionId,
      tipoContribuyentePdrId: 0,
    };
    this.compensacionesIdhService
      .obtenerCompensacionesIdhUsos(pSolicitud)
      .then((respuesta: RespuestaLista<CompensacionesIdhUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
      });
  }
}
