import { CommonModule } from '@angular/common';
import { Component, inject, LOCALE_ID, OnInit, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaCompensacionIdhUsosComponent } from './scc-bolsa-compensacion-idh-usos/scc-bolsa-compensacion-idh-usos.component';
import { CompensacionesIdhModel } from '../../../../models/bolsas/compensaciones-idh.model';
import { BolsaCompensacionesIdhService } from '../../../../services/bolsas/compensacion-idh-service';

@Component({
  selector: 'scc-bolsa-compensacion-idh',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaCompensacionIdhUsosComponent,
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-compensacion-idh.component.html',
  styleUrl: './scc-bolsa-compensacion-idh.component.scss',
})
export class SccBolsaCompensacionIdhComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: CompensacionesIdhModel;
  mensaje: string;
  @ViewChild('hijo') hijoComponent!: SccBolsaCompensacionIdhUsosComponent;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private CompensacionesIdhService: BolsaCompensacionesIdhService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'periodo',
      'anio',
      'compensacionBs',
      'saldoCompensacionBs',
      'detalle',
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<CompensacionesIdhModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
          this.obtenerCompensacionesIdh(this.contribuyente.nit!);
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  obtenerCompensacionesIdh(nit: number) {
    this.tableLoading = true;
    const tipoContribuyentePdr = 0;
    this.CompensacionesIdhService.obtenerCompensacionesIdh(
      nit,
      tipoContribuyentePdr
    )
      .then((respuesta: RespuestaLista<CompensacionesIdhModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
          this.mensaje =
            this.dataSource.data.length === 0 ? Mensajes.MSG_NOT_RESULT : '';
        }
        this.tableLoading = false;
      })
      .catch(() => {
        this.tableLoading = false;
      });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerCompensacionesIdhUsos(fila: any) {
    this.filaSeleccionada = fila;
    this.hijoComponent.obtenerCompensacionesIdhUsos(fila);
  }
}
