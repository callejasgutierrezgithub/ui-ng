import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule } from 'core-lib';
import { ValoresSaldosModel } from '../../../../../models/consulta-valores/valores-saldos.model';
import { ValoresSaldosService } from '../../../../../services/registro-boletas-de-pago/valores-saldos.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-valores-saldos-detalles',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-valores-saldos-detalles.component.html',
  styleUrl: './scc-bolsa-valores-saldos-detalles.component.scss',
})
export class SccBolsaValoresSaldosDetallesComponent {
  @Input() bolsa: ValoresSaldosModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<any>([]);
  loading: boolean;
  mensaje: string;

  constructor(
    private valoresSaldosDetalleService: ValoresSaldosService,
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'montoBs',
      'saldoBs'];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerValoresSaldosDetalle(valorSaldo: ValoresSaldosModel) {
    this.loading = true;
    this.valoresSaldosDetalleService
      .obtenerValoresSaldosDetalle(valorSaldo.nitCur!, valorSaldo.id!)
      .then((resultado) => {
        if (resultado.transaccion) {
          this.dataSource.data = resultado.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.id) {
      this.obtenerValoresSaldosDetalle(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
