import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, OnInit, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule } from 'core-lib';
import { ValoresSaldosModel } from '../../../../models/consulta-valores/valores-saldos.model';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { ValoresSaldosService } from '../../../../services/registro-boletas-de-pago/valores-saldos.service';
import { SccBolsaValoresSaldosDetallesComponent } from './scc-bolsa-valores-saldos-detalles/scc-bolsa-valores-saldos-detalles.component';

@Component({
  selector: 'scc-bolsa-valores-saldos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaValoresSaldosDetallesComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-valores-saldos.component.html',
  styleUrl: './scc-bolsa-valores-saldos.component.scss',
})
export class SccBolsaValoresSaldosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource = new MatTableDataSource<ValoresSaldosModel>([]);
  @Input() dataSourceArray: ValoresSaldosModel[] = [];
  filaSeleccionada: ValoresSaldosModel;
  valoresSaldoSeleccionado: ValoresSaldosModel = {};

  @ViewChild('valorSaldoDetalle')
  valorSaldoDetalleComponent!: SccBolsaValoresSaldosDetallesComponent;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  map = new Map<number, string>();

  constructor(
    private valoresSaldosService: ValoresSaldosService,
    private _datosContribuyente: DatosContribuyenteService,
    private cd: ChangeDetectorRef
  ) {
    this.tableLoading = false;
    this.columnas = [
      'nro',
      'fechaRegistro',
      'impuestos',
      'impuestoDesc',
      'montoBs',
      'montoUfv',
      'saldo',
      'detalle',
    ];

    this.map.set(3, 'A LAS RETENCIONES EMPR. INDUSTRIALES EXPORTADORAS');
    this.map.set(4, 'A LAS TRANSACCIONES FINANCIERAS');
    this.map.set(8, 'CONCEPTOS VARIOS');
    this.map.set(9, 'TRANSMISION GRATUITA DE BIENES');
    this.map.set(14, 'SOBRE LAS UTILIDADES DE LAS EMPRESAS');
    this.map.set(15, 'DE LA REGALIA MINERA');
    this.map.set(16, 'ALICUOTA ADICIONAL AL IUE');
    this.map.set(17, 'IMPUESTO AL JUEGO');
    this.map.set(18, 'COMPLEMENTARIO DE LA MINERIA');
    this.map.set(19, 'IMPUESTO A LA PARTICIPACION EN JUEGOS');
    this.map.set(20, 'A LOS CONSUMOS ESPECIFICOS');
    this.map.set(22, 'IMPUESTO A LAS GRANDES FORTUNAS');
    this.map.set(25, 'A LOS HIDROCARBUROS Y SUS DERIVADOS');
    this.map.set(26, 'IMPUESTO DIRECTO A LOS HIDROCARBUROS');
    this.map.set(30, 'AL VALOR AGREGADO');
    this.map.set(40, 'REGIMEN COMPLEMENTARIO AL IVA');
    this.map.set(50, 'A LAS TRANSACCIONES');
    this.map.set(62, 'SISTEMA TRIBUTARIO INTEGRADO');
    this.map.set(64, 'REGIMEN AGROPECUARIO UNIFICADO');
    this.map.set(65, 'SISTEMA INTEGRADO ESPECIAL DE TRANSICIÓN PARA EMPR');
    this.map.set(90, 'A LOS VIAJES AL EXTERIOR');
    this.map.set(91, 'A LA VENTA DE MONEDA EXTRANJERA');

    this.filaSeleccionada = {};
  }

  ngOnInit(): void {
    this.getContribuyten();
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
          this.obtenerBolsaSaldoDetalle(this.contribuyente.nit!);
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  obtenerBolsaSaldoDetalle(nit: number) {
    this.tableLoading = true;
    this.valoresSaldosService
      .obtenerValoresSaldos(nit, 0)
      .then((respuesta) => {
        if (respuesta.transaccion) {
          let copyData = respuesta.objetosList!;
          copyData.forEach(
            (x) =>
              (x.impuestoDesc = this.obtenerDescripcionImpuesto(x.impuestos!))
          );
          this.dataSource.data = copyData;
        }
      })
      .finally(() => {
        this.tableLoading = false;
        this.cd.detectChanges();
      });
  }

  obtenerDescripcionImpuesto(parametro: string): string {
    let str = JSON.parse(parametro);
    let descripcionImpuestos = '';
    str.forEach((item: any) => {
      if (descripcionImpuestos != '') {
        descripcionImpuestos = descripcionImpuestos + ', ' + this.map.get(item);
      } else {
        descripcionImpuestos = descripcionImpuestos + this.map.get(item);
      }
    });
    return descripcionImpuestos;
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: ValoresSaldosModel) {
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
