import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaIceModel } from '../../../../models/bolsas/bolsa-ice';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { BolsaIceService } from '../../../../services/bolsas/bolsa-ice.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaIceUsosComponent } from './scc-bolsa-ice-usos/scc-bolsa-ice-usos.component';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-ice',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaIceUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-ice.component.html',
  styleUrl: './scc-bolsa-ice.component.scss',
})
export class SccBolsaIceComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() contribuyente!: any;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  @Input() dataSourceArray: BolsaIceModel[] = [];
  filaSeleccionada: BolsaIceModel;
  mensaje: string;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private iueService: BolsaIceService,
    private contribuyenteService: DatosContribuyenteService,
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoBs',
      'saldoBs',
      'detalle'
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaIceModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
    this.obtenerContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  obtenerContribuyten(): void {
    this.contribuyenteService.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaIceModel) {
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
