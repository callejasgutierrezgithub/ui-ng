import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaIceModel,
  BolsaIceUsosModel,
  SolicitudBolsaIceUso,
} from '../../../../../models/bolsas/bolsa-ice';
import { BolsaIceService } from '../../../../../services/bolsas/bolsa-ice.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';

@Component({
  selector: 'scc-bolsa-ice-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-ice-usos.component.html',
  styleUrl: './scc-bolsa-ice-usos.component.scss',
})
export class SccBolsaIceUsosComponent {
  @Input() bolsa: BolsaIceModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource = new MatTableDataSource<any>([]);
  loading: Boolean;
  mensaje: string;

  constructor(
    private iceService: BolsaIceService,
    private cdr: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'montoBs',
    ];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = true;
  }

  obtenerBolsaIceUsos(data: BolsaIceModel) {
    this.loading = true;
    let solicitud: SolicitudBolsaIceUso = {
      nitCur: data.nitCur,
      tipoPdrId: 0,
      bolsaIceId: data.bolsaIceId,
    };
    this.iceService
      .obtenerBolsaIceUsos(solicitud)
      .then((respuesta: RespuestaLista<BolsaIceUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cdr.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.bolsaIceId) {
      this.obtenerBolsaIceUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
