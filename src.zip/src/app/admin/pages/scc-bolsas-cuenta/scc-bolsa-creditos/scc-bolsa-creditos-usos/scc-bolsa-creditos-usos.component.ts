import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaCreditosModel } from '../../../../../models/bolsas/bolsa-creditos';
import {
  BolsaCreditosUsosModel,
  SolicitudBolsaCreditosUsos,
} from '../../../../../models/bolsas/bolsa-creditos-usos';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaCreditosService } from '../../../../../services/bolsas/bolsa-creditos.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-creditos-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-creditos-usos.component.html',
  styleUrl: './scc-bolsa-creditos-usos.component.scss',
})
export class SccBolsaCreditosUsosComponent {
  @Input() bolsa: BolsaCreditosModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  dataSource;
  loading: Boolean;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(
    private bolsaCreditosService: BolsaCreditosService,
    private cd: ChangeDetectorRef
  ) {
    this.columnas = [
      'deudaId',
      'fechaRegistro',
      'periodoOrigen',
      'anioOrigen',
      'periodoUso',
      'anioUso',
      'creditoBs',
      'mantenimientoValorBs',
    ];
    this.dataSource = new MatTableDataSource<BolsaCreditosUsosModel>([]);
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaCreditosUsos(data: BolsaCreditosModel) {
    this.loading = true;
    const pSolicitud: SolicitudBolsaCreditosUsos = {
      nitCur: data.nitCur,
      bolsaCreditoId: data.bolsaCreditoId,
      tipoContribuyentePdrId: 0,
    };
    this.bolsaCreditosService
      .obtenerCreditosUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaCreditosUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.bolsaCreditoId) {
      this.obtenerBolsaCreditosUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
