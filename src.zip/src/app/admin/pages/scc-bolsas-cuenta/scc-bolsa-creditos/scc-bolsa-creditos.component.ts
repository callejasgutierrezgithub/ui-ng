import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule } from 'core-lib';
import { BolsaCreditosModel } from '../../../../models/bolsas/bolsa-creditos';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { SccBolsaCreditosUsosComponent } from './scc-bolsa-creditos-usos/scc-bolsa-creditos-usos.component';

@Component({
  selector: 'scc-bolsa-creditos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaCreditosUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-creditos.component.html',
  styleUrl: './scc-bolsa-creditos.component.scss',
})
export class SccBolsaCreditosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  @Input() dataSourceArray: BolsaCreditosModel[] = [];
  dataSource;
  filaSeleccionada: BolsaCreditosModel;
  filaPendiente: BolsaCreditosModel | null = null;
  ordenAscendente = true;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  mostrarDetalle = false;
  constructor(
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'credito_bs',
      'saldo_credito_bs',
      'detalle',
    ];
    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaCreditosModel>([]);
    this.mensaje = '';
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }

  seleccionaFila(fila: BolsaCreditosModel) {
    if (this.filaSeleccionada?.bolsaCreditoId !== fila.bolsaCreditoId) {
      this.filaSeleccionada = fila;
      this.mostrarDetalle = true;
    }
  }
}
