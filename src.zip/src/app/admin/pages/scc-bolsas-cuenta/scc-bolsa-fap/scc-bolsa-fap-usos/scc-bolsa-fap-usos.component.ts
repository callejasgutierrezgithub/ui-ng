import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, inject, Input, LOCALE_ID, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import {
  BolsaFapModel,
  BolsaFapUsosModel,
  SolicitudBolsaFapUsos,
} from '../../../../../models/bolsas/bolsa-fap';
import { LocaldatePipe } from '../../../../../pipes/localdate.pipe';
import { BolsaFapService } from '../../../../../services/bolsas/bolsa-fap.service';
import { Mensajes } from '../../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-bolsa-fap-usos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-fap-usos.component.html',
  styleUrl: './scc-bolsa-fap-usos.component.scss',
})
export class SccBolsaFapUsosComponent {
  @Input() bolsa: BolsaFapModel | null = null;
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  columnas: Array<string>;
  @Input() data!: BolsaFapUsosModel;
  dataSource = new MatTableDataSource<BolsaFapUsosModel>([]);
  mensaje: string;
  loading: Boolean;
  constructor(private BolsaFapService: BolsaFapService, private cd: ChangeDetectorRef) {
    this.columnas = ['deudaId',
      'fechaRegistro', 'periodoUso', 'anioUso', 'montoFapBs'];
    this.mensaje = Mensajes.DETALLE_USOS_NO_ENCONTRADOS;
    this.loading = false;
  }

  obtenerBolsaFapUsos(data: BolsaFapModel) {
    this.loading = true;
    const pSolicitud: SolicitudBolsaFapUsos = {
      nitCur: data.nitCur,
      bolsaFapId: data.id!,
      tipoContribuyentePdrId: 0,
    };
    this.BolsaFapService.obtenerFacilidadesPagoUsos(pSolicitud)
      .then((respuesta: RespuestaLista<BolsaFapUsosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
      })
      .finally(() => {
        this.loading = false;
        this.cd.detectChanges();
      });
  }
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['bolsa'] && this.bolsa?.id) {
      this.obtenerBolsaFapUsos(this.bolsa);
    }
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
