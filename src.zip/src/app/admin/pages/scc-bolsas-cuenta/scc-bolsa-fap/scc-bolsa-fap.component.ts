import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { BolsaFapModel } from '../../../../models/bolsas/bolsa-fap';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { BolsaFapService } from '../../../../services/bolsas/bolsa-fap.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';
import { SccBolsaFapUsosComponent } from './scc-bolsa-fap-usos/scc-bolsa-fap-usos.component';

@Component({
  selector: 'scc-bolsa-fap',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SccBolsaFapUsosComponent,
    LocaldatePipe
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-bolsa-fap.component.html',
  styleUrl: './scc-bolsa-fap.component.scss',
})
export class SccBolsaFapComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() dataSourceArray: BolsaFapModel[] = [];
  contribuyente!: ContribuyenteModel;
  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  filaSeleccionada: BolsaFapModel;
  mensaje: string;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private bolsaFap: BolsaFapService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.tableLoading = false;

    this.columnas = [
      'nro',
      'deudaId',
      'fechaRegistro',
      'periodo',
      'anio',
      'formularioId',
      'montoBs',
      'saldoMontoBs',
      'detalle'
    ];

    this.filaSeleccionada = {};
    this.dataSource = new MatTableDataSource<BolsaFapModel>([]);
    this.mensaje = '';
  }
  ngOnInit(): void {
    this.getContribuyten();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dataSourceArray']) {
      this.dataSource.data = [...this.dataSourceArray];
    }
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
          this.dataSource.data = [];
          this.filaSeleccionada = {};
        }
      }
    );
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  seleccionaFila(fila: BolsaFapModel) {
    this.filaSeleccionada = fila;
  }

  obtenerAbsoluto(valor: number | null | undefined): number {
    return Math.abs(valor ?? 0);
  }
}
