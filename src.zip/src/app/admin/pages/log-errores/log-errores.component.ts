import { CommonModule } from '@angular/common';
import { Component, inject, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { DialogoComponent } from './grilla-log/dialogo/dialogo.component';
import { ErrorModel } from '../../../models/log-errores/log-errores-model';
import { LogErroresService } from '../../../services/log-errores/log-errores.service';
import { GrillaLogComponent } from './grilla-log/grilla-log.component';
import { MatNativeDateModule } from '@angular/material/core';

@Component({
  selector: 'app-log-errores',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    CommonModule,
    ReactiveFormsModule,
    MatPaginatorModule,
    MatNativeDateModule,
    MaterialModule,
    TitlePageComponent,
    FormsModule,
    DialogoComponent,
    GrillaLogComponent],
  templateUrl: './log-errores.component.html',
  styleUrl: './log-errores.component.scss'
})
export class LogErroresComponent {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  listaErrores: ErrorModel[] = [];
  searchText: string = '';

  displayedColumns = [
    "nitCur",
    "nombreProyecto",
    "nombreServicio",
    "codigoError",
    "mensajeError",
    "solicitud",
    "apiServicio",
    "estadoErrorId",
    "excepcion",
  ];
  dataSource = new MatTableDataSource<ErrorModel>();

  constructor(
    private logErroresService: LogErroresService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.obtenerLitaErrores();
    }, 300);
  }

  obtenerLitaErrores() {
    this.logErroresService
      .obtenerLitaErrores().then((respuesta: any) => {
        if (respuesta.transaccion) {
          this.dataSource = new MatTableDataSource<ErrorModel>(respuesta.objetosList);
          this.ngAfterViewInit();
        }
      })
      .catch(() => {
        // this.tableLoading = false;
      });
  }
  actionSolictud(element: ErrorModel): void {
    const dialogRef = this.dialog.open(DialogoComponent, {
      width: '550px',
      height: '72vh',
      data: { message: element.solicitud, title: "solicitud" }
    });
  }

  actionExcepcion(element: ErrorModel): void {
    const dialogRef = this.dialog.open(DialogoComponent, {
      width: '70%',
      height: '50vh',
      data: { message: element.excepcion, title: "Excepcion" }
    });
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator =
    Object.create(null);

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  actionView(element: ErrorModel): void {
  }

  actionEdit(element: ErrorModel): void {
  }

  actionDelete(element: ErrorModel): void {
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }
}
