import { CommonModule } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MaterialModule } from 'core-lib';
import { ErrorModel } from '../../../../models/log-errores/log-errores-model';
import { LogErroresService } from '../../../../services/log-errores/log-errores.service';
import { DialogoComponent } from './dialogo/dialogo.component';

@Component({
  selector: 'app-grilla-log',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    CommonModule,
    MatPaginatorModule,
    MaterialModule,
    FormsModule,
    DialogoComponent
  ],
  templateUrl: './grilla-log.component.html',
  styleUrl: './grilla-log.component.scss'
})
export class GrillaLogComponent {

  listaErrores: ErrorModel[] = [];

  searchText: string = '';

  displayedColumns = [
    "nitCur",
    "nombreProyecto",
    "nombreServicio",
    "codigoError",
    "mensajeError",
    "solicitud",
    "apiServicio",
    "estadoErrorId",
    "excepcion",
    "fechaRegistro",
    // "action",
  ];
  dataSource = new MatTableDataSource<ErrorModel>();

  constructor(
    private logErroresService: LogErroresService,
    private dialog: MatDialog
  ) { }

  ngOnInit(): void {
    setTimeout(() => {
      this.obtenerLitaErrores();

    }, 300);
  }

  obtenerLitaErrores() {
    this.logErroresService
      .obtenerLitaErrores().then((respuesta: any) => {
        if (respuesta.transaccion) {
          this.dataSource = new MatTableDataSource<ErrorModel>(respuesta.objetosList);
          this.ngAfterViewInit();
        }
      })
      .catch(() => {
      });
  }
  actionSolictud(element: ErrorModel): void {
    const dialogRef = this.dialog.open(DialogoComponent, {
      width: '550px',
      height: '72vh',
      data: { message: element.solicitud, title: "solicitud" }
    });
  }

  actionExcepcion(element: ErrorModel): void {
    const dialogRef = this.dialog.open(DialogoComponent, {
      width: '70%',
      minHeight: '30vh',
      maxHeight: '75vh',
      data: { message: element.excepcion, title: "Excepcion" }
    });
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator =
    Object.create(null);

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  actionView(element: ErrorModel): void {
  }

  actionEdit(element: ErrorModel): void {
  }

  actionDelete(element: ErrorModel): void {
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

}
