import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrillaLogComponent } from './grilla-log.component';

describe('GrillaLogComponent', () => {
  let component: GrillaLogComponent;
  let fixture: ComponentFixture<GrillaLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GrillaLogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GrillaLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
