import { CommonModule } from '@angular/common';
import { Component, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MaterialModule } from 'core-lib';

@Component({
  selector: 'app-dialogo',
  standalone: true,
  imports: [CommonModule, MaterialModule],
  templateUrl: './dialogo.component.html',
  styleUrl: './dialogo.component.scss'
})
export class DialogoComponent {
  objetoJson: any;
  formato: Boolean = false;

  constructor(
    public dialogRef: MatDialogRef<DialogoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { message: string, title: string }
  ) { }
  ngOnInit(): void {
    setTimeout(() => {
      this.covetirJson(this.data.title);

    }, 300);
  }

  covetirJson(title: string) {
    if (title === "solicitud") {
      this.formato = true;
      this.objetoJson = JSON.parse(this.data.message);
    } else {
      this.objetoJson = this.data.message;
    }
  }

  onConfirm(): void {
    this.dialogRef.close(true);
  }

  onCancel(): void {
    this.dialogRef.close(false);
  }

}
