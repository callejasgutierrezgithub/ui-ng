import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { RouterModule } from '@angular/router';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { Subscription } from 'rxjs';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { SccGrillaBoletaDeudasComponent } from './scc-grilla-boleta-deudas/scc-grilla-boleta-deudas.component';
import { SccGrillaBoletasPagoAsociadasAlIdentificadorDeudaComponent } from './scc-grilla-boletas-pago-asociadas-al-identificador-deuda/scc-grilla-boletas-pago-asociadas-al-identificador-deuda.component';
import { SccGrillaRegistroPagoDeudasComponent } from './scc-grilla-registro-pago-deudas/scc-grilla-registro-pago-deudas.component';

@Component({
  selector: 'app-scc-registro-boletas-de-pago',
  standalone: true,
  imports: [
    MaterialModule, ReactiveFormsModule, CommonModule, RouterModule, MatNativeDateModule, FormsModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    SccGrillaBoletaDeudasComponent,
    InformacionContribuyenteComponent,
    SccGrillaRegistroPagoDeudasComponent,
    SccGrillaBoletasPagoAsociadasAlIdentificadorDeudaComponent],
  templateUrl: './scc-registro-boletas-de-pago.component.html',
  styleUrl: './scc-registro-boletas-de-pago.component.scss'
})
export class SccRegistroBoletasDePagoComponent implements OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  mensajeNit: string = '';
  consultaNit: Boolean = false;
  contribuyente: ContribuyenteModel = {};
  private contribuyenteSubscription?: Subscription;

  constructor(
    private readonly _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) { this.obtenerConsultaNit(); }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this.contribuyenteSubscription = this._datosContribuyente.dataModel$
        .subscribe((contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyente = contribuyente;
            this.contribuyente.tipoContribuyentePdrId = 0;
          } else {
            this.contribuyente = {}
          }
        });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }

  ngOnDestroy(): void {
    if (this.contribuyenteSubscription) {
      this.contribuyenteSubscription.unsubscribe();
      this._datosContribuyente.setDataModel({});
    }
  }
}