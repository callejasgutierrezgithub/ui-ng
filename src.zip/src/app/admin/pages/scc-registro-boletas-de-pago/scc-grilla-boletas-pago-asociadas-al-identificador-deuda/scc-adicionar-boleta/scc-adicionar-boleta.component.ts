import PDFObject from 'pdfobject';

import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
} from '@angular/material/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { Router, RouterModule } from '@angular/router';
import {
  MaterialModule,
  RespuestaObjeto,
  SiatToastrService,
  UploadComponent
} from 'core-lib';
import * as _moment from 'moment';
import { default as _rollupMoment } from 'moment';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { ExpresionRegularEnum } from '../../../../../enums/expresion-regular.enum';
import { MensajesGenericoEnum } from '../../../../../enums/general.enum';
import { ConfirmarDialogModel } from '../../../../../models/confirmar-dialog/confirmar-dialog.model';
import { ContribuyenteModel } from '../../../../../models/contribuyente/contribuyente.model';
import {
  FormularioModel,
  RespuestaFormularioDdjj,
} from '../../../../../models/impuesto-asociado/formulario.model';
import { ParametricaGenericaModel } from '../../../../../models/parametrica/parametrica-generica.model';
import {
  BoletasPagoModel,
  VerificarBoletasPagoModel,
} from '../../../../../models/registro-boletas-de-pagos/boletas-pagos';
import { SolicitudVerificarBoletasPago } from '../../../../../models/registro-boletas-de-pagos/solicitud-verificar-boletas-pago';
import { DatosContribuyenteService } from '../../../../../services/comun/datos-contribuyente.service';
import { FormularioDdjjService } from '../../../../../services/formularios-ddjj/formulario-ddjj.service';
import { BoletasPagosService } from '../../../../../services/registro-boletas-de-pago/boletas-pagos.service';
import { BoletasPagoStoreService } from '../../../../../services/store/boletas-pago-store.service';
import { SccConfirmDialogComponent } from '../../../../../shared/components/scc-confirm-dialog/scc-confirm-dialog.component';
import { SccDatePickerYearComponent } from '../../../../../shared/components/scc-datepicker-year/scc-datepicker-year.component';
import { SelectFilterComponent } from '../../../../../shared/components/select-filter/select-filter.component';
import { CustomDateAdapter } from '../../../../../shared/utils/formato-fecha-date-picker/custom-date-adapter';
import { FORMATO_FECHA_DIA_MES_ANIO } from '../../../../../shared/utils/formato-fecha-date-picker/date-format';
import { Fecha } from './../../../../../shared/utils/fecha';
import { BOLETAS_ENUM } from '../../../../../enums/boletas.enum';
import { SccButtonLoadingComponent } from '../../../../../shared/components/scc-button-loading/scc-button-loading.component';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'app-scc-adicionar-boleta',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    NgxSpinnerModule,
    SelectFilterComponent,
    SccDatePickerYearComponent,
    UploadComponent,
    RouterModule,
    SccButtonLoadingComponent
  ],
  templateUrl: './scc-adicionar-boleta.component.html',
  styleUrl: './scc-adicionar-boleta.component.scss',
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: FORMATO_FECHA_DIA_MES_ANIO },
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    { provide: DateAdapter, useClass: CustomDateAdapter },
  ],
})
export class SccAdicionarBoletaComponent implements OnInit {
  formAdicinarBoleta: FormGroup;
  contribuyente: ContribuyenteModel;
  columnas: Array<string>;
  dataSource;
  mensajeVerificacion: string = '';
  tipoBoleta: ParametricaGenericaModel[];
  tipoPeriodo: ParametricaGenericaModel[];
  verificacionBoletasPagoBoolean: boolean = false;
  verificarBoleta: VerificarBoletasPagoModel = {};
  formularios: FormularioModel[];
  formulariosFiltrado: any;
  boletaFiltrado: any;
  anio: number = 0;
  anioBooleanP: boolean = false;
  isLoading = false;
  verificarNumeroBoletaBoolean: Boolean = true;
  base64: string = '';
  files: File[] = [];

  constructor(
    private dialog: MatDialog,
    public dialogGrilla: MatDialogRef<SccAdicionarBoletaComponent>,
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private spinnerService: NgxSpinnerService,
    private _boletasPagos: BoletasPagosService,
    private _datosContribuyente: DatosContribuyenteService,
    private _formulariosDdjj: FormularioDdjjService,
    private _boletasPagoStore: BoletasPagoStoreService,
    private router: Router,
    @Inject(MAT_DATE_FORMATS) private dateFormats: any
  ) {
    this.formAdicinarBoleta = new FormGroup({});
    this.contribuyente = {};
    this.columnas = [
      'montoPagoBs',
      'pagoDeudaBs', //Tributo omitido
      'pagoInteresBs',
      'pagoMantenimientoValorBs',
      'pagoSancionBs',
      'pagoAgravanteBs',
      'pagoMultaBs',
    ];

    this.dataSource = new MatTableDataSource<any>([]);
    this.tipoBoleta = BOLETAS_ENUM;

    this.tipoBoleta.map(
      (item: FormularioModel) => {
        item.descripcionLarga = `${item.id} - ${item.descripcion}`;
        return item;
      }
    );
    this.boletaFiltrado = this.tipoBoleta.slice();

    this.formularios = [];
    this.tipoPeriodo = [
      { id: 1, descripcion: 'ENERO' },
      { id: 2, descripcion: 'FEBRERO' },
      { id: 3, descripcion: 'MARZO' },
      { id: 4, descripcion: 'ABRIL' },
      { id: 5, descripcion: 'MAYO' },
      { id: 6, descripcion: 'JUNIO' },
      { id: 7, descripcion: 'JULIO' },
      { id: 8, descripcion: 'AGOSTO' },
      { id: 9, descripcion: 'SEPTIEMBRE' },
      { id: 10, descripcion: 'OCTUBRE' },
      { id: 11, descripcion: 'NOVIEMBRE' },
      { id: 12, descripcion: 'DICIEMBRE' },
    ];
  }

  ngOnInit(): void {
    this.crearFormulario();
    this.obtenerContribuyente();
  }

  crearFormulario() {
    this.formAdicinarBoleta = this.formBuilder.group({
      numeroOrden: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(20),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      numeroOrdenDocumento: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(20),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      periodo: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(2),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      anio: [null, [Validators.required]],
      fechaPago: [null, [Validators.required]],
      boletaId: [null, [Validators.required]],
      formularioId: [null, [Validators.required]],
    });
  }

  obtenerContribuyente(): void {
    this._datosContribuyente.dataModel$.subscribe((contribuyente) => {
      this.contribuyente = contribuyente;
      this.contribuyente.tipoContribuyentePdrId = 0;

      if (!this.contribuyente.nit) {
        this.router.navigateByUrl('/imputacion-boletas-pago');
      }
    });
  }

  obtenerFormulariosDdjj() {
    this._formulariosDdjj
      .obtenerFormularios()
      .then((respuesta: RespuestaFormularioDdjj) => {
        if (respuesta.transaccion) {
          this.formularios = respuesta.formularios.map(
            (item: FormularioModel) => {
              item.descripcionLarga = `${item.formulario} - ${item.descripcion}`;
              return item;
            }
          );
          this.formulariosFiltrado = this.formularios.slice();
        } else {
          this.toastr.info('Error en el servicio');
        }
      });
  }

  validarCampo(campo: string, label: string, maxlength?: number): string {
    return this.campoEsValido(campo, this.formAdicinarBoleta, label, maxlength);
  }

  campoEsValido(
    campo: string,
    form: FormGroup,
    label: string,
    maxlength?: number
  ): string {
    const control = form.get(campo);
    if (control?.errors && control.touched) {
      if (control.hasError('required')) {
        return 'El campo ' + label + ' es requerido.';
      }
      if (control.hasError('maxlength')) {
        return (
          'El campo ' +
          label +
          ', no puede tener más de ' +
          maxlength +
          ' digitos.'
        );
      }
      if (control.hasError('min')) {
        return 'El campo ' + label + ', tiene que ser mayor a 0';
      }
      if (control.hasError('pattern')) {
        return 'El campo ' + label + ', debe contener solo números';
      }
    }
    return '';
  }

  verificarBoletasPago(): void {
    this.spinnerService.show();
    let vSolicitud: SolicitudVerificarBoletasPago = {
      nitCur: this.contribuyente.nit,
      numeroOrdenBoletaPago: parseInt(this.formAdicinarBoleta.value.numeroOrden),
      numeroOrdenDocumentoPago: parseInt(this.formAdicinarBoleta.value.numeroOrdenDocumento),
      gestion: parseInt(this.formAdicinarBoleta.value.anio),
      periodo: parseInt(this.formAdicinarBoleta.value.periodo),
      boleta: parseInt(this.formAdicinarBoleta.value.boletaId),
      documentoQuePaga: parseInt(this.formAdicinarBoleta.value.formularioId),
    };
    this._boletasPagos
      .verificarBoletasPago(vSolicitud)
      .then((respuesta: RespuestaObjeto<VerificarBoletasPagoModel>) => {
        if (respuesta.transaccion) {
          if (Object.keys(respuesta.objeto!).length > 0) {
            this.verificacionBoletasPagoBoolean = respuesta.objeto?.disponible!;
            this.verificarBoleta = respuesta.objeto!;
            if (respuesta.objeto?.disponible!) {
              this.desHabilitarFormulario();
              this.toastr.success('Boleta Disponible');
              if (respuesta.objeto?.monto! <= 0) this.toastr.info('No tiene Monto Dispobible');
            } else {
              this.toastr.info(respuesta.mensajes[0].descripcion);
            }
          } else {
            this.toastr.info('Boleta No Dispobible');
          }
        } else {
          this.toastr.info('Error en el servicio');
        }
      })
      .finally(() => {
        setTimeout(() => {
          this.spinnerService.hide();
        }, 500);
      });
  }

  adicionar(): void {
    let vSolicitud: BoletasPagoModel = {
      nitCur: this.contribuyente.nit,
      boleta: parseInt(this.formAdicinarBoleta.value.boletaId),
      boletaId: this.verificarBoleta.identificadorBoleta,
      montoPagoBs: this.verificarBoleta.monto,
      periodo: parseInt(this.formAdicinarBoleta.value.periodo),
      anio: this.formAdicinarBoleta.value.anio,
      fechaPago: Fecha.toLocalDate(this.formAdicinarBoleta.get('fechaPago')?.value)!,
      numeroOrdenBoleta: parseInt(this.formAdicinarBoleta.value.numeroOrden),
      numeroDocumentoPaga: parseInt(this.formAdicinarBoleta.value.numeroOrdenDocumento),
      file: this.files,
    };

    const propiedadesMensajeConfirmacion: ConfirmarDialogModel = {
      title: MensajesGenericoEnum.VERIFICACION_BOLETA_PAGO,
      content: MensajesGenericoEnum.VERIFICACION_BOLETA_PAGO_DESCRIPCION,
    };
    const dialogRef = this.dialog.open(SccConfirmDialogComponent, {
      disableClose: true,
      width: '500px',
      data: propiedadesMensajeConfirmacion,
    });

    dialogRef.afterClosed().subscribe((respuesta: boolean) => {
      if (respuesta) {
        this.spinnerService.show();
        this._boletasPagoStore.setBoletasPago(vSolicitud);
        this.toastr.success('Se verifico la Boleta de Pago');
        setTimeout(() => {
          this.spinnerService.hide();
        }, 1000);
        this.dialogGrilla.close();
      }
    });
  }

  desHabilitarFormulario(): void {
    Object.keys(this.formAdicinarBoleta.controls).forEach((key) => {
      this.formAdicinarBoleta.get(key)?.disable();
    });
    this.anioBooleanP = true;
  }
  habilitarFormulario(): void {
    Object.keys(this.formAdicinarBoleta.controls).forEach((key) => {
      this.formAdicinarBoleta.get(key)?.enable();
    });
    this.anioBooleanP = false;
    this.verificacionBoletasPagoBoolean = false;
    this.verificarNumeroBoletaBoolean = true;
    this.verificarBoleta = {};
    this.files = []
  }

  seleccionarAnio(event: any): void {
    this.formAdicinarBoleta.get('anio')?.setValue(event);
  }

  onFilesSelected(files: File[]): void {
    this.files = files;
    this.convertToBase64(files[0])

    setTimeout(() => {
      const blob = this.base64ToBlob(this.base64, 'application/pdf');
      const url = URL.createObjectURL(blob);

      PDFObject.embed(url, '#pdf-container', {
        height: '100%',
        pdfOpenParams: {
          view: 'FitH',
          pagemode: 'none',
        },
      });
    }, 1000)

  }

  convertToBase64(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      this.base64 = reader.result as string;
      this.base64 = this.base64.split("base64,")[1];
    };
    reader.readAsDataURL(file)
  }

  base64ToBlob(base64: string, contentType: string) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length)
      .fill(0)
      .map((_, i) => byteCharacters.charCodeAt(i));
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: contentType });
  }
}
