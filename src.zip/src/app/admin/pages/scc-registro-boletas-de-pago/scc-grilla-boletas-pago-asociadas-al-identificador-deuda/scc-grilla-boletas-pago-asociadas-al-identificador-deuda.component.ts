import { CommonModule } from '@angular/common';
import { Component, effect, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MaterialModule } from 'core-lib';
import { ExpresionRegularEnum } from '../../../../enums/expresion-regular.enum';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { BoletasPagoModel } from '../../../../models/registro-boletas-de-pagos/boletas-pagos';
import { BoletasPagoStoreService } from '../../../../services/store/boletas-pago-store.service';
import { SccAdicionarBoletaComponent } from './scc-adicionar-boleta/scc-adicionar-boleta.component';
@Component({
  selector: 'scc-grilla-boletas-pago-asociadas-al-identificador-deuda',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
  ],
  templateUrl:
    './scc-grilla-boletas-pago-asociadas-al-identificador-deuda.component.html',
  styleUrl:
    './scc-grilla-boletas-pago-asociadas-al-identificador-deuda.component.scss',
})
export class SccGrillaBoletasPagoAsociadasAlIdentificadorDeudaComponent
  implements OnInit {
  @Input() contribuyente: ContribuyenteModel = {};

  formBoletasPago: FormGroup;
  detalleDeuda: DetalleDeudaModel;
  boletaPago: BoletasPagoModel;
  constructor(
    private dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private _boletasPagoStore: BoletasPagoStoreService,
  ) {
    this.formBoletasPago = new FormGroup({});
    this.detalleDeuda = {}
    this.boletaPago = {}
    this.obtenerBoletaPago();
    this.obtenerDeudaId();
  }

  ngOnInit(): void {
    this.crearFormularioBoletasPago();
  }

  crearFormularioBoletasPago() {
    this.formBoletasPago = this._formBuilder.group({
      deudaId: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(15),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
    });
  }

  obtenerBoletaPago(): void {
    effect(() => {
      this.boletaPago = this._boletasPagoStore.getBoletasPagos()();
    });
  }

  obtenerDeudaId(): void {
    effect(() => {
      this.detalleDeuda = this._boletasPagoStore.getDetalleDeuda()();
    });
  }
  adicionarBoleta(): void {
    this.dialog.open(SccAdicionarBoletaComponent, {
      panelClass: 'border-dialog',
      width: '1500px',
      enterAnimationDuration: '300ms',
      exitAnimationDuration: '300ms',
      autoFocus: false,
      disableClose: true,
    });
  }

  limpiarBoleta(): void {
    this._boletasPagoStore.setBoletasPago({});
    this._boletasPagoStore.setDeudasHijo([]);
  }
}
