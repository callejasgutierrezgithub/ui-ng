import { CommonModule } from '@angular/common';
import { Component, effect, inject, Input, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista } from 'core-lib';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { BoletasPagoModel } from '../../../../models/registro-boletas-de-pagos/boletas-pagos';
import { BoletasPagosService } from '../../../../services/registro-boletas-de-pago/boletas-pagos.service';
import { MatPaginator } from '@angular/material/paginator';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { BoletasPagoStoreService } from '../../../../services/store/boletas-pago-store.service';

@Component({
  selector: 'scc-grilla-boleta-deudas',
  standalone: true,
  imports: [MaterialModule, CommonModule, LocaldatePipe],
  templateUrl: './scc-grilla-boleta-deudas.component.html',
  styleUrl: './scc-grilla-boleta-deudas.component.scss'
})
export class SccGrillaBoletaDeudasComponent {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  dataSource;
  columnas: Array<string>;
  tablaCargando: boolean;
  loading: Boolean;
  @Input() contribuyente: ContribuyenteModel = {};
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(
    private _boletasPago: BoletasPagosService,
    private readonly _boletasPagoStore: BoletasPagoStoreService,
  ) {
    this.tablaCargando = false;
    this.columnas = [
      'nro',
      'boletaId',
      'deudaId',
      'fechaRegistro',
      'fechaPago',
      'periodo',
      'anio',
      'numeroOrdenBoleta',
      'numeroDocumentoPaga',
      'liquidacionId',
      'montoPagoBs',
      'montoTributoOmitidoBs',
      'montoSancionBs',
      'montoAgravanteBs',
      'montoMultaUfv',
      'montoInteresBs',
      'montoMantenimientoValorBs',
    ];
    this.dataSource = new MatTableDataSource<BoletasPagoModel>([]);
    this.obtenerDeudasHijo();
    this.loading = false;
  }
  ngOnInit(): void {
    this.consultar();
  }

  obtenerDeudasHijo(): void {
    effect(() => {
      if (this._boletasPagoStore.getDeudasHijo()().length == 0) {
        this.consultar();
      }
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  consultar(): void {
    this.tablaCargando = true;
    this._boletasPago
      .obtenerBoletasPago(this.contribuyente.nit!)
      .then((respuesta: RespuestaLista<BoletasPagoModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList!;
        }
        this.tablaCargando = false;
      });
  }
}
