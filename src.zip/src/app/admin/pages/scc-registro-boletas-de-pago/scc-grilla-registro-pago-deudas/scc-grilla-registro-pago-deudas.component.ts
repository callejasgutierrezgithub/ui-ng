import { CommonModule } from '@angular/common';
import { Component, effect, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatProgressBar } from '@angular/material/progress-bar';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule, Respuesta, RespuestaLista, SiatToastrService } from 'core-lib';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { ExpresionRegularEnum } from '../../../../enums/expresion-regular.enum';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudDetalleDeuda } from '../../../../models/detalle-deudas-contribuyente/solicitud-detalle-deudas.model';
import { BoletasPagoModel } from '../../../../models/registro-boletas-de-pagos/boletas-pagos';
import { DeudasBoletaPago } from '../../../../models/registro-boletas-de-pagos/solicitud-registrar-boletas-pago';
import { ReporteAdeudoTributarioService } from '../../../../services/detalle-deuda-contribuyente/reporte-adeudo-tributario.service';
import { BoletasPagosService as BoletasPagoService } from '../../../../services/registro-boletas-de-pago/boletas-pagos.service';
import { BoletasPagoStoreService } from '../../../../services/store/boletas-pago-store.service';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { SccGrillaDeudasComponent } from '../scc-grilla-deudas/scc-grilla-deudas.component';

@Component({
  selector: 'scc-grilla-registro-pago-deudas',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    MatProgressBar,
    NgxSpinnerModule
  ],
  templateUrl: './scc-grilla-registro-pago-deudas.component.html',
  styleUrl: './scc-grilla-registro-pago-deudas.component.scss',
})
export class SccGrillaRegistroPagoDeudasComponent implements OnInit {
  @Input() contribuyente: ContribuyenteModel = {};
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  tableLoading: boolean;
  columnas: Array<string>;
  dataSource;
  fromBusquedaDeudas: FormGroup;
  listaDeudaPadre: RespuestaLista<DetalleDeudaModel> | any;
  boletasPago: BoletasPagoModel = {};
  deudasHijo: Array<DetalleDeudaModel> = [{}];
  totalMontoPago: number = 0;
  montosPrevios = new Map<number, number>();

  constructor(
    private readonly _fb: FormBuilder,
    private readonly _boletasPago: BoletasPagoService,
    private readonly _boletasPagoStore: BoletasPagoStoreService,
    private readonly reporteAdeudoService: ReporteAdeudoTributarioService,
    private readonly toastr: SiatToastrService,
    private readonly dialog: MatDialog,
    private readonly spinnerService: NgxSpinnerService,
  ) {
    this.tableLoading = false;
    this.fromBusquedaDeudas = this._fb.group({
      deudaId: new FormControl('', [Validators.pattern(ExpresionRegularEnum.Numeros)])
    });

    this.columnas = [
      'nro',
      'deudaId',
      'proceso',
      'formularioId',
      'periodo',
      'anio',
      'numeroOrdenDocumento',
      'documentoAgrupador',
      'numeroOrdenDocumentoAgrupador',
      'montoDeudaInicialBs',
      'interesBs',
      'mantenimientoValorBs',
      'sancionBs',
      'agravanteBs',
      'multaUfv',
      'montoPago',
      'detalle'
    ];

    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);
    this.obtenerBoletaPago();
    this.obtenerDeudasHijo();
  }

  ngOnInit(): void {
    this.obtenerListaDeudas();
  }

  obtenerBoletaPago(): void {
    effect(() => {
      this.boletasPago = this._boletasPagoStore.getBoletasPagos()();
    });
  }

  obtenerDeudasHijo(): void {
    effect(() => {
      this.deudasHijo = this._boletasPagoStore.getDeudasHijo()();
    });
  }

  clearFilter(): void {
    this.fromBusquedaDeudas.get('deudaId')?.setValue('')
    this.dataSource.filter = '';
  }

  actualizarTotal(element: any): void {
    const id = element.deudaId;
    const rawValue = (element.montoPago || '0').toString().trim();

    let valorNormalizado = '0';

    if (rawValue.includes(',') && rawValue.includes('.')) {
      valorNormalizado = rawValue.replace(/\./g, '').replace(',', '.');
    } else if (rawValue.includes(',')) {
      valorNormalizado = rawValue.replace(',', '.');
    } else {
      valorNormalizado = rawValue;
    }

    let nuevoMonto = parseFloat(valorNormalizado);

    if (isNaN(nuevoMonto) || !/^\d+(\.\d{1,2})?$/.test(valorNormalizado)) {
      return;
    }

    nuevoMonto = Math.round(nuevoMonto * 100) / 100;
    const montoAnterior = this.montosPrevios.get(id) || 0;
    const diferencia = parseFloat((nuevoMonto - montoAnterior).toFixed(2));

    this.totalMontoPago = parseFloat((this.totalMontoPago + diferencia).toFixed(2));
    this.montosPrevios.set(id, nuevoMonto);
  }

  validarEntrada(event: KeyboardEvent) {
    const input = event.target as HTMLInputElement;
    const valorActual = input.value;
    const tecla = event.key;

    if (
      event.ctrlKey || event.metaKey ||
      ['Backspace', 'ArrowLeft', 'ArrowRight', 'Tab', 'Delete'].includes(tecla)
    ) {
      return;
    }

    if (/^[0-9]$/.test(tecla)) {
      const separador = valorActual.includes('.') ? '.' : valorActual.includes(',') ? ',' : null;
      if (separador) {
        const [entero, decimal] = valorActual.split(separador);
        const cursorPos = input.selectionStart ?? valorActual.length;
        const separadorIndex = valorActual.indexOf(separador);

        if (cursorPos > separadorIndex && decimal?.length >= 2) {
          event.preventDefault();
        }
      }
      return;
    }

    if (tecla === '.' || tecla === ',') {
      if (valorActual.includes('.') || valorActual.includes(',')) {
        event.preventDefault();
      }
      return;
    }
    event.preventDefault();
  }

  openDialogBuscarDeudas(): void {
    const deudaId = this.fromBusquedaDeudas.get('deudaId')?.value;
    let listaDeudas = [...this.listaDeudaPadre.objetosList];

    if (deudaId > 0 && deudaId !== null) {
      listaDeudas = listaDeudas.filter((item: any) => item.deudaId == deudaId);
    }

    const dialogo1 = this.dialog.open(SccGrillaDeudasComponent, {
      panelClass: 'border-dialog',
      width: '1500px',
      enterAnimationDuration: '300ms',
      exitAnimationDuration: '300ms',
      autoFocus: false,
      disableClose: true,
      data: listaDeudas,
    });

    dialogo1.afterClosed().subscribe((deudasSeleccionadas) => {
      if (deudasSeleccionadas) {
        this.dataSource.paginator = this.paginator;
        this.dataSource.data = this.deudasHijo;
      }
    }
    );
  }

  obtenerListaDeudas() {
    this.tableLoading = true;

    const solicitud: SolicitudDetalleDeuda = {
      nitCur: Number(this.contribuyente.nit),
      oficinaId: this.contribuyente.administracion,
      origenId: 292,
    };
    this.reporteAdeudoService
      .obtenerDetalleDeuda(solicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.listaDeudaPadre = respuesta ?? [];
          } else {
            this.listaDeudaPadre = [];
          }
        }
        this.tableLoading = false;
      });
  }

  eliminar(fila: any): void {
    this.eliminarMontoPagoFila(fila);
    this.dataSource.data = this.dataSource.data.filter(item => item.deudaId !== fila.deudaId)
    this.deudasHijo.forEach(item => { if (item.deudaId == fila.deudaId) item.montoPago = null; });
    this.deudasHijo = this.deudasHijo.filter(item => item.deudaId !== fila.deudaId);
    this._boletasPagoStore.setDeudasHijo(this.deudasHijo);
  }

  eliminarMontoPagoFila(fila: any): void {
    const rawValue = (fila.montoPago || '0').toString().trim();
    let valorNormalizado = '0';

    if (rawValue.includes(',') && rawValue.includes('.')) {
      valorNormalizado = rawValue.replace(/\./g, '').replace(',', '.');
    } else if (rawValue.includes(',')) {
      valorNormalizado = rawValue.replace(',', '.');
    } else {
      valorNormalizado = rawValue;
    }

    const monto = Number(valorNormalizado) || 0;

    this.totalMontoPago -= monto;
    this.montosPrevios.delete(fila.deudaId); // importante si lo estás usando
  }

  formData = new FormData();
  relacionarBoletas() {
    this.spinnerService.show();
    let vDeudasBoletaPago: Array<DeudasBoletaPago> = [];
    this.dataSource.data.forEach((item) => {
      vDeudasBoletaPago.push({
        deudaId: item.deudaId,
        formularioId: item.formularioId,
        montoPagoBs: parseFloat(item.montoPago?.toString() ?? '0'),
        montoTributoOmitidoBs: item.mantenimientoValorBs,
        montoMantenimientoValorBs: item.mantenimientoValorBs,
        montoInteresBs: item.interesBs,
        montoSancionBs: item.sancionBs,
        montoAgravanteBs: item.agravanteBs,
        montoMultaUfv: item.multaUfv,
        monedaId: item.monedaId
      })
    })

    if (this.boletasPago.file && this.boletasPago.file.length > 0) {
      this.boletasPago.file.forEach((file) => {
        this.formData.append('file', file, file.name);
      });
    } else {
      this.toastr.info('No hay documento Boleta, para enviar.');
    }
    this.formData.append('oficinaId', this.contribuyente.administracion!.toString());
    this.formData.append('nitCur', this.contribuyente.nit!.toString());
    this.formData.append('tipoContribuyentePdrId', '0');
    this.formData.append('tramiteId', '4321');
    this.formData.append('boletaId', this.boletasPago.boletaId!.toString());
    this.formData.append('origenId', '328');
    this.formData.append('periodo', this.boletasPago.periodo!.toString());
    this.formData.append('anio', this.boletasPago.anio!.toString());
    this.formData.append('fechaPago', JSON.stringify(this.boletasPago.fechaPago));
    this.formData.append('numeroOrdenBoleta', this.boletasPago.numeroOrdenBoleta!.toString());
    this.formData.append('numeroDocumentoPaga', this.boletasPago.numeroDocumentoPaga!.toString());
    this.formData.append('deudasBoletaPago', JSON.stringify((vDeudasBoletaPago)));
    this._boletasPago.registrarBoletasPago(this.formData)
      .then((response: Respuesta) => {
        if (response.transaccion) {
          this.toastr.success(MensajeConstante.MSG_REGISTRO_BOLETA);
          this._boletasPagoStore.setDeudasHijo([]);
          this._boletasPagoStore.setBoletasPago({});
        } else {
          this.toastr.info(response.mensajes[0].descripcion);
        }
        setTimeout(() => {
          this.spinnerService.hide();
          this.limpiarMontosPagoBs();
          this.totalMontoPago = 0;
          this.montosPrevios.clear();
        }, 1000);
      })
  }

  limpiarMontosPagoBs() {
    this.dataSource.data.forEach(element => {
      element.montoPago = '' as any;
    });
  }
}