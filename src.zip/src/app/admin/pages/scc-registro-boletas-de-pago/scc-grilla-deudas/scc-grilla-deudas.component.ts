import { SelectionModel } from '@angular/cdk/collections';
import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, effect, Inject, OnInit, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MaterialModule } from 'core-lib';
import { BolsaStiUsosModel } from '../../../../models/bolsas/bolsa-sti';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { BoletasPagoStoreService } from '../../../../services/store/boletas-pago-store.service';

@Component({
  selector: 'app-scc-grilla-deudas',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    CommonModule,
    MatPaginatorModule,
    MaterialModule,
    FormsModule],
  templateUrl: './scc-grilla-deudas.component.html',
  styleUrl: './scc-grilla-deudas.component.scss'
})
export class SccGrillaDeudasComponent implements AfterViewInit {
  dataSourceDeuda = new MatTableDataSource<BolsaStiUsosModel>();
  deudasHijo: Array<DetalleDeudaModel> = [];
  tableLoading: boolean;
  constructor(
    public dialogRef: MatDialogRef<SccGrillaDeudasComponent>,
    public _boletasPagoStore: BoletasPagoStoreService,
    @Inject(MAT_DIALOG_DATA) public data: Array<DetalleDeudaModel>
  ) {
    this.tableLoading = false;
    this.obtenerDeudasHijo();
  }

  obtenerDeudasHijo(): void {
    effect(() => {
      this.tableLoading = true;
      this.deudasHijo = this._boletasPagoStore.getDeudasHijo()();
      let deudas = this.data.filter((item) => !this.deudasHijo.some((data) => data.deudaId === item.deudaId));
      this.dataSourceDeuda = new MatTableDataSource<DetalleDeudaModel>(deudas);
      this.dataSourceDeuda.paginator = this.paginator;
      this.tableLoading = false;
    });
  }

  displayedColumnsDeudas = [
    'select',
    'nro',
    'deudaId',
    'proceso',
    'formularioId',
    'periodo',
    'anio',
    'numeroOrdenDocumento',
    'documentoAgrupador',
    'numeroOrdenDocumentoAgrupador',
    'montoDeudaInicialBs',
    'interesBs',
    'mantenimientoValorBs',
    'sancionBs',
    'agravanteBs',
    'multaUfv'
  ];

  ngAfterViewInit(): void {
    this.dataSourceDeuda.paginator = this.paginator;
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator = Object.create(null);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceDeuda.filter = filterValue.trim().toLowerCase();
  }
  clearFilter(): void {
    this.dataSourceDeuda.filter = '';
  }

  selection = new SelectionModel<DetalleDeudaModel>(true, []);

  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSourceDeuda.data.length;
    return numSelected === numRows;
  }

  masterToggle(): void {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSourceDeuda.data.forEach((row) => this.selection.select(row));
  }

  checkboxLabel(row?: DetalleDeudaModel): string {
    if (!row) {
      return (this.isAllSelected() ? 'select' : 'deselect') + ' all';
    }
    return (this.selection.isSelected(row) ? 'deselect' : 'select') + ' row ' + (row.deudaId! + 1);
  }

  viewSelect(): void {
    let deudas = [...this.selection.selected, ...this.deudasHijo]
    this._boletasPagoStore.setDeudasHijo(deudas);
    this.dialogRef.close(this.selection.selected);
  }
}
