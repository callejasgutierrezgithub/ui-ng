import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConexionApiGddComponent } from './conexion-api-gdd.component';

describe('ConexionApiGddComponent', () => {
  let component: ConexionApiGddComponent;
  let fixture: ComponentFixture<ConexionApiGddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConexionApiGddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConexionApiGddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
