import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConexionApiOtrComponent } from './conexion-api-otr.component';

describe('ConexionApiOtrComponent', () => {
  let component: ConexionApiOtrComponent;
  let fixture: ComponentFixture<ConexionApiOtrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConexionApiOtrComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConexionApiOtrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
