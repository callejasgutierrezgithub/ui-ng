import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MaterialModule, ButtonReturnComponent, TitlePageComponent } from 'core-lib';
import { InformacionContribuyenteComponent } from '../../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { RespuestaConexionMultiBase } from '../../../../models/verificar-conexiones/verificar-conexiones.model';
import { VerificarConexionesService } from '../../../../services/verificar-conexiones/verificar-conexiones.service';


@Component({
  selector: 'app-conexion-api-pdd',
  standalone: true,
  imports: [
          FormsModule,
          MaterialModule,
          RouterModule,
          ReactiveFormsModule,
          CommonModule, 
          ButtonReturnComponent, TitlePageComponent,
          InformacionContribuyenteComponent],
  templateUrl: './conexion-api-pdd.component.html',
  styleUrl: './conexion-api-pdd.component.scss'
})
export class ConexionApiPddComponent {
  verificacion: any;
  btnCheck: boolean;
  
  connectionStatusMessage: string | undefined;
  connectionStatus: string | undefined;
  multiBase: any;

  constructor(private verificarConexionesService: VerificarConexionesService) {
    this.btnCheck = false;
  }

  ngOnInit() {    
      this.verificarConexionesPdd();
  }

  verificarConexionesPdd() {
    this.btnCheck = true;
    this.multiBase = [{}];
    this.verificarConexionesService
      .obtenerVerificarConexiones("pdd")
      .then((respuesta: RespuestaConexionMultiBase) => {
        this.btnCheck = false;
        if (respuesta.transaccion) {          
          this.connectionStatusMessage = 'Servicio en linea: ' + new Date().getDate() + "/" + new Date().getMonth() + "/" + new Date().getFullYear();
          this.connectionStatus = 'online';
          this.multiBase = respuesta;
        } else {
          this.connectionStatusMessage = 'Servicio fuera de linea';
          this.connectionStatus = 'offline';
        }
      })
      .catch((err) => {
        this.btnCheck = false;
        this.connectionStatusMessage = err.message;
        this.connectionStatus = 'offline';
      });
  } 
}
