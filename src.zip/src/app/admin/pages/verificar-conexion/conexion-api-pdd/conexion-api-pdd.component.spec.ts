import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConexionApiPddComponent } from './conexion-api-pdd.component';

describe('ConexionApiPddComponent', () => {
  let component: ConexionApiPddComponent;
  let fixture: ComponentFixture<ConexionApiPddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConexionApiPddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConexionApiPddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
