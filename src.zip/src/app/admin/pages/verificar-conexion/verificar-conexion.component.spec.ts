import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerificarConexionComponent } from './verificar-conexion.component';

describe('VerificarConexionComponent', () => {
  let component: VerificarConexionComponent;
  let fixture: ComponentFixture<VerificarConexionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VerificarConexionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VerificarConexionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
