import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConexionApiParComponent } from './conexion-api-par.component';

describe('ConexionApiParComponent', () => {
  let component: ConexionApiParComponent;
  let fixture: ComponentFixture<ConexionApiParComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConexionApiParComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConexionApiParComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
