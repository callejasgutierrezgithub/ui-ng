import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MaterialModule, ButtonReturnComponent, TitlePageComponent } from 'core-lib';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { GrillaLogComponent } from '../log-errores/grilla-log/grilla-log.component';
import { ConexionApiCccComponent } from './conexion-api-ccc/conexion-api-ccc.component';
import { ConexionApiGddComponent } from './conexion-api-gdd/conexion-api-gdd.component';
import { ConexionApiOtrComponent } from './conexion-api-otr/conexion-api-otr.component';
import { ConexionApiParComponent } from './conexion-api-par/conexion-api-par.component';
import { ConexionApiPddComponent } from './conexion-api-pdd/conexion-api-pdd.component';
import { MatDialog } from '@angular/material/dialog';
import { VerificarConexionesService } from '../../../services/verificar-conexiones/verificar-conexiones.service';
import { RespuestaConexionMultiBase } from '../../../models/verificar-conexiones/verificar-conexiones.model';
import { SccVerificaConexionesComponent } from './scc-verifica-conexiones/scc-verifica-conexiones.component';

@Component({
  selector: 'app-verificar-conexion',
  standalone: true,
  imports: [
    MaterialModule, 
    ReactiveFormsModule, 
    CommonModule, 
    RouterModule, 
    ButtonReturnComponent, 
    TitlePageComponent, 
    InformacionContribuyenteComponent, 
    GrillaLogComponent,
    ConexionApiCccComponent,
    ConexionApiGddComponent,
    ConexionApiOtrComponent,
    ConexionApiParComponent,
    ConexionApiPddComponent,
    SccVerificaConexionesComponent,
    ],
  templateUrl: './verificar-conexion.component.html',
  styleUrl: './verificar-conexion.component.scss'
})
export class VerificarConexionComponent {
  btnCheck: boolean;
  connectionStatusMessage: string | undefined;
  connectionStatus: string | undefined;
  multiBase: any;
  mitiBaseCcc: any;
  listaData:string[];
  dateString:string = "";
    constructor(
      private dialog: MatDialog,
      private verificarConexionesService: VerificarConexionesService
    ) {
      this.btnCheck = false;
      this.listaData = [];
    }
  
  cccApi: boolean = false;
  gddApi: boolean = false;
  pddApi: boolean = false;
  otrApi: boolean = false;
  parApi: boolean = false;

  _cccApi(){
    this.cccApi=true;
    this.gddApi=false;
    this.pddApi=false;
    this.otrApi=false;
    this.parApi=false;
  }
   _gddApi(){
    this.cccApi=false;
    this.gddApi=true;
    this.pddApi=false;
    this.otrApi=false;
    this.parApi=false;
  }
  _pddApi(){
    this.cccApi=false;
    this.gddApi=false;
    this.pddApi=true;
    this.otrApi=false;
    this.parApi=false;
  }
   _otrApi(){
    this.cccApi=false;
    this.gddApi=false;
    this.pddApi=false;
    this.otrApi=true;
    this.parApi=false;
  }
  _parApi(){
    this.cccApi=false;
    this.gddApi=false;
    this.pddApi=false;
    this.otrApi=false;
    this.parApi=true;
 }   
}
