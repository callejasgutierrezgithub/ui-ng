import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConexionApiCccComponent } from './conexion-api-ccc.component';

describe('ConexionApiCccComponent', () => {
  let component: ConexionApiCccComponent;
  let fixture: ComponentFixture<ConexionApiCccComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConexionApiCccComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConexionApiCccComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
