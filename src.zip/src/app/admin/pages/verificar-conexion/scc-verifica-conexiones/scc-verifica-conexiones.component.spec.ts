import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SccVerificaConexionesComponent } from './scc-verifica-conexiones.component';

describe('SccVerificaConexionesComponent', () => {
  let component: SccVerificaConexionesComponent;
  let fixture: ComponentFixture<SccVerificaConexionesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SccVerificaConexionesComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SccVerificaConexionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
