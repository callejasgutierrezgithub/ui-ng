import { CommonModule } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MaterialModule, Respuesta, RespuestaLista, SiatToastrService } from 'core-lib';
import { SccVerificaConexionesDto } from '../../../../models/verificar-conexiones/verificar-conexiones.model';
import { VerificarConexionComponent } from '../verificar-conexion.component';
import { VerificarConexionesService } from '../../../../services/verificar-conexiones/verificar-conexiones.service';
import { Mensajes } from '../../../../shared/utils/mensajes.const';

@Component({
  selector: 'app-scc-verifica-conexiones',
  standalone: true,
  imports: [
    MatCardModule,
    MatTableModule,
    CommonModule,
    MatPaginatorModule,
    MaterialModule,
    FormsModule],
  templateUrl: './scc-verifica-conexiones.component.html',
  styleUrl: './scc-verifica-conexiones.component.scss'
})
export class SccVerificaConexionesComponent {

  searchText: string = '';
  mensaje: string;
  tableLoading: boolean;
  connectionStatusMessage: string | undefined;
  connectionStatus: string | undefined;
  lista: SccVerificaConexionesDto[] = [];

  displayedColumns = [
    "verificacionId",
    "fechaVerificacion",
    "usuarioRegistroId",
    "fechaRegistro",
    "dataBase",
    // "action",
  ];

  dataSource = new MatTableDataSource<SccVerificaConexionesDto>();

  constructor(
    private verificarConecion: VerificarConexionesService,
    private toastr: SiatToastrService,
  ) {
    this.mensaje = '';
    this.tableLoading = false;
  }

  ngOnInit() {
    this.obtenerVerificaConeciones();
  }

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator =
    Object.create(null);

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  actionView(element: SccVerificaConexionesDto): void {
  }

  actionEdit(element: SccVerificaConexionesDto): void {
  }

  actionDelete(element: SccVerificaConexionesDto): void {
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerVerificaConeciones() {
    this.tableLoading = true;
    this.verificarConecion
      .obtenerVerificaConeciones()
      .then((respuesta: RespuestaLista<SccVerificaConexionesDto>) => {
        if (respuesta.transaccion) {
          this.lista.push(respuesta.objetosList![0])
          this.dataSource.data = this.lista;
          this.mensaje =
            this.dataSource.data.length === 0 ? Mensajes.MSG_NOT_RESULT : '';
          this.tableLoading = false;
        } else {
          this.tableLoading = false;
        }
      })
      .catch((err) => {
        this.tableLoading = false;
      })
      ;
  }

  registrarVerificaConeciones() {
    this.tableLoading = true;
    this.verificarConecion
      .registrarVerificaConeciones()
      .then((respuesta: Respuesta) => {
        if (respuesta.transaccion) {
          this.toastr.info(
            'Se registro correctamente.'
          );
          this.lista = [];
          this.obtenerVerificaConeciones();
        } else {
          this.toastr.info(
            'Error al registrar.'
          );
        }
      })
      .catch((err) => {
        this.tableLoading = false;
      })
      ;
  }

}
