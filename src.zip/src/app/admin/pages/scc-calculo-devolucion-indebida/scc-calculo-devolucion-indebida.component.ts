import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { SccCalculosComponent } from './scc-calculos/scc-calculos.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';

@Component({
  selector: 'scc-calculo-devolucion-indevida',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    SccCalculosComponent,
    InformacionContribuyenteComponent],
  templateUrl: './scc-calculo-devolucion-indebida.component.html',
  styleUrl: './scc-calculo-devolucion-indebida.component.scss'
})
export class SccCalculoDevolucionIndebidaComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  contribuyente: ContribuyenteModel = {};
  consultaNit: Boolean = false;
  mensajeNit: string = '';
  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) { this.obtenerConsultaNit(); }

  ngOnInit(): void {
    this.getContribuyente();
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  ngOnDestroy(): void {
    this.contribuyente = {};
    this._datosContribuyente.setDataModel(this.contribuyente);
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {}
        }
      });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }
}