import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MaterialModule, Mensaje, MensajesService, SiatToastrService } from 'core-lib';
import { RespuestaCalculoIndebido } from '../../../../models/calculo-devolucion-indebida/respuesta-calculo-indebido.model';
import { SolicitudCalculoIndebido } from '../../../../models/calculo-devolucion-indebida/solicitud-calculo-indebido.model';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { CalculoDevolucionIndebidaService } from '../../../../services/calculo-devolucion-indevida/calculo.devolucion.indebida.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { Fecha } from '../../../../shared/utils/fecha';
import { Mensajes } from '../../../../shared/utils/mensajes.const';

@Component({
  selector: 'scc-calculos',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule],
  templateUrl: './scc-calculos.component.html',
  styleUrl: './scc-calculos.component.scss'
})
export class SccCalculosComponent implements OnInit, OnDestroy {
  formCalculoDevolucion: FormGroup;
  contribuyente: ContribuyenteModel = {};

  calculoAccesorioDeterminacionTable = [
    { descripcion: 'Parametros', columna1: 'Descripción', columna2: 'Valor' },
    { columna1: 'Impuesto determinado(Bs)', columna2: 0 },
    { columna1: 'Fecha de entrega CEDEIM', columna2: 0 },
    { columna1: 'UFV Fecha de entrega CEDEIM', columna2: 0 },
    { columna1: 'Fecha actualización', columna2: 0 },
    { columna1: 'UFV Fecha actualización', columna2: 0 },
    { columna1: 'Dias Mora', columna2: 0 },
    { columna1: 'Tasa de Interes (%)', columna2: '4, 6, 10' }
  ];

  calculoAccesorioTable = [
    { descripcion: 'Parametros', columna1: 'Descripción', columna2: 'Bs', columna3: 'UFV' },
    { columna1: 'Impuesto determinado(Bs)', columna2: 0, columna3: 0 },
    { columna1: 'Mantenimiento de valor', columna2: 0, columna3: 0 },
    { columna1: 'Intereses', columna2: 0, columna3: 0 },
    { columna1: 'Sancion 0% Conducta', columna2: 0, columna3: 0 },
    { columna1: 'Total General', columna2: 0, columna3: 0 },
  ];

  determinacionMantenimientoValorRestituido = [
    { descripcion: 'Parametros', columna1: 'Descripción', columna2: 'Monto' },
    { columna1: 'Monto observado(Bs)', columna2: 0 },
    { columna1: 'Fecha solicitud CEDEIM', columna2: 0 },
    { columna1: 'Ultimo dia hábil del periodo solicitado', columna2: 0 },
    { columna1: 'UFV Ultimo dia habil del periodo solicitado', columna2: 0 },
    { columna1: 'Fecha de entrega CEDEIM', columna2: 0 },
    { columna1: 'Ultimo dia hábil del periodo ant. Al que se entregaron CEDEIM', columna2: 0 },
    { columna1: 'Mantenimiento de valor del monto observado (BS)', columna2: '4, 6, 10' },
    { columna1: 'Total general', columna2: '4, 6, 10' }
  ];

  actualizacionMantenimientoValorRestituido1 = [
    { descripcion: 'Parametros', columna1: 'Descripción', columna2: 'Monto' },
    { columna1: 'Mantenimiento de valor(Bs)', columna2: 0 },
    { columna1: 'Fecha entrega CEDEIM', columna2: 0 },
    { columna1: 'UFV Fecha entrega CEDEIM', columna2: 0 },
    { columna1: 'Fecha actualizacion', columna2: 0 },
    { columna1: 'UFV Fecha actualizacion', columna2: 0 },
    { columna1: 'Dias mora', columna2: 0 }
  ];

  actualizacionMantenimientoValorRestituido2 = [
    { descripcion: 'Parametros', columna1: 'Descripción', columna2: 'Bs', columna3: 'UFV' },
    { columna1: 'Mantenimiento de valor restituido - observado', columna2: 0, columna3: 0 },
    { columna1: 'Mantenimiento de valor', columna2: 0, columna3: 0 },
    { columna1: 'Interes', columna2: 0, columna3: 0 },
    { columna1: 'Total general', columna2: 0, columna3: 0 }
  ];

  cuadroResumen = [
    { descripcion: 'Parametros', columna1: 'Monto observado(Bs)', columna2: 'Mantenimiento de valor(Bs)', columna3: 'Interes (Bs)', columna4: 'Sancion (Bs)', columna5: 'Total (Bs)' },
    { columna1: 'Importe indebidamente devuelto', columna2: 0, columna3: 0, columna4: 0, columna5: 0 },
    { columna1: 'Mantenimiento de valor observado', columna2: 0, columna3: 0, columna4: 0, columna5: 0 },
    { columna1: 'Total', columna2: 0, columna3: 0, columna4: 0, columna5: 0 },
  ]
  constructor(private formBuilder: FormBuilder,
    private calculoDevolucionIndebidaService: CalculoDevolucionIndebidaService,
    private _datosContribuyente: DatosContribuyenteService,
    private mensajesService: MensajesService,
    private toastr: SiatToastrService,
  ) {
    this.formCalculoDevolucion = new FormGroup({});
  }

  ngOnInit(): void {
    this.getContribuyente();
    this.crearFormulario();
  }

  ngOnDestroy(): void {
    this.contribuyente = {};
    this._datosContribuyente.setDataModel(this.contribuyente);
  }

  getContribuyente(): void {
    this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
      if (contribuyente && contribuyente.nit) {
        this.contribuyente = contribuyente;
      } else {
        this.contribuyente = {}
      }
    });
  }
  obtenerDatosDevolucion() {
    if (!this.formCalculoDevolucion.invalid) {
      const vNit = this.contribuyente.nit;
      const vDudie = this.formCalculoDevolucion.get('dudie')?.value;
      const vNumeroOrdenFiscalizacion = this.formCalculoDevolucion.get('numeroOrdenFiscalizacion')?.value;
      const vOficinaId = this.formCalculoDevolucion.get('oficinaId')?.value;
      const solicitud: SolicitudCalculoIndebido = {
        nitCur: vNit,
        dudie: vDudie,
        numeroOrdenFiscalizacion: vNumeroOrdenFiscalizacion,
        oficinaId: vOficinaId,
      };

      this.calculoDevolucionIndebidaService
        .calcularDebolucionIndebida(solicitud)
        .then((respuesta: RespuestaCalculoIndebido) => {
          if (respuesta.transaccion) {
            this.toastr.success(Mensajes.RegistroEncontrado);
            this.actualizarCalculoAccesorios(respuesta);
            this.actualizarMantenimientoValorRestituido(respuesta);
            this.actualizarMantenimientoValorActualizado(respuesta);
            this.actualizarCuadroResumen(respuesta);
          } else {
            var mensajes = respuesta.mensajes ? respuesta.mensajes : [];
            this.toastr.info(mensajes.toString());
          }
        });
    } else {
      this.toastr.info('Datos no validos...');
    }
  }
  crearFormulario() {
    this.formCalculoDevolucion = this.formBuilder.group({
      dudie: ['', [Validators.required]],
      numeroOrdenFiscalizacion: ['', [Validators.required]],
      oficinaId: ['', [Validators.required]],
    });
  }

  actualizarCalculoAccesorios(pDatos: RespuestaCalculoIndebido) {
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[1].columna2 = pDatos.calculoIndebidoDeterminacion?.montoDeudaBs;
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[2].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoDeterminacion?.fechaEntregaCedeim);
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[3].columna2 = pDatos.calculoIndebidoDeterminacion?.ufvFechaEntregaCedeim;
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[4].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoDeterminacion?.fechaActualizacion);
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[5].columna2 = pDatos.calculoIndebidoDeterminacion?.ufvFechaActualizacion;
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[6].columna2 = pDatos.calculoIndebidoDeterminacion?.diasMora;
    // @ts-ignore
    this.calculoAccesorioDeterminacionTable[7].columna2 = pDatos.calculoIndebidoDeterminacion?.tasaInteres;

    // @ts-ignore
    this.calculoAccesorioTable[1].columna2 = pDatos.calculoIndebidoDeterminacion?.montoDeudaBs;
    // @ts-ignore
    this.calculoAccesorioTable[1].columna3 = pDatos.calculoIndebidoDeterminacion?.montoDeudaUfv;
    // @ts-ignore
    this.calculoAccesorioTable[2].columna2 = pDatos.calculoIndebidoDeterminacion?.mantenimientoValorBs;
    // @ts-ignore
    this.calculoAccesorioTable[2].columna3 = pDatos.calculoIndebidoDeterminacion?.mantenimientoValorUfv;
    // @ts-ignore
    this.calculoAccesorioTable[3].columna2 = pDatos.calculoIndebidoDeterminacion?.interesBs;
    // @ts-ignore
    this.calculoAccesorioTable[3].columna3 = pDatos.calculoIndebidoDeterminacion?.interesUfv;
    // @ts-ignore
    this.calculoAccesorioTable[4].columna2 = pDatos.calculoIndebidoDeterminacion?.sancionBs;
    // @ts-ignore
    this.calculoAccesorioTable[4].columna3 = pDatos.calculoIndebidoDeterminacion?.sancionUfv;
    // @ts-ignore
    this.calculoAccesorioTable[5].columna2 = pDatos.calculoIndebidoDeterminacion?.totalGeneralAccesorioBs;
    // @ts-ignore
    this.calculoAccesorioTable[5].columna3 = pDatos.calculoIndebidoDeterminacion?.totalGeneralAccesorioBs;
  }

  actualizarMantenimientoValorRestituido(pDatos: RespuestaCalculoIndebido) {
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[1].columna2 = pDatos.calculoIndebidoDeterminacion?.montoDeudaBs;
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[2].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoMantenimientoValorRestituido?.fechaSolicitudCedeim);
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[3].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoMantenimientoValorRestituido?.ultimoDiaHabilPeriodoSolicitado);
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[4].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.ufvUltimoDiaHabilPeriodoSolicitado;
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[5].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoMantenimientoValorRestituido?.ultimoDiaHabilPeriodoAnteriorEntrega);
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[6].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.ufvUltimoDiaHabilPeriodoAnteriorEntrega;
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[7].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.mantenimientoValorMontoObservadoBs;
    // @ts-ignore
    this.determinacionMantenimientoValorRestituido[8].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.totalMantenimientoValorRestituido;
  }

  actualizarMantenimientoValorActualizado(pDatos: RespuestaCalculoIndebido) {
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[1].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.mantenimientoValorMontoObservadoBs;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[2].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoDeterminacion?.fechaEntregaCedeim);
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[3].columna2 = pDatos.calculoIndebidoDeterminacion?.ufvFechaEntregaCedeim;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[4].columna2 = Fecha.toStringLocalDate(pDatos.calculoIndebidoDeterminacion?.fechaActualizacion);
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[5].columna2 = pDatos.calculoIndebidoDeterminacion?.ufvFechaActualizacion;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido1[6].columna2 = pDatos.calculoIndebidoDeterminacion?.diasMora;

    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[1].columna2 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.mantenimientoValorRestituidoObservadoBs;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[1].columna3 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.mantenimientoValorRestituidoObservadoUfv;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[2].columna2 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.mantenimientoValorRestituidoAccesorioBs;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[2].columna3 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.mantenimientoValorRestituidoAccesorioUfv;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[3].columna2 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.interesAccesorioBs;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[3].columna3 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.interesAccesorioUfv;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[4].columna2 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.totalActualizacionMantenimientoValorRestituidoBs;
    // @ts-ignore
    this.actualizacionMantenimientoValorRestituido2[4].columna3 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.totalActualizacionMantenimientoValorRestituidoUfv
  }

  actualizarCuadroResumen(pDatos: RespuestaCalculoIndebido) {
    // @ts-ignore
    this.cuadroResumen[1].columna2 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.mantenimientoValorRestituidoObservadoBs;
    // @ts-ignore
    this.cuadroResumen[2].columna2 = pDatos.calculoIndebidoMantenimientoValorRestituido?.mantenimientoValorMontoObservadoBs;
    // @ts-ignore
    this.cuadroResumen[2].columna3 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.interesAccesorioBs;
    // @ts-ignore
    this.cuadroResumen[2].columna4 = 0;
    // @ts-ignore
    this.cuadroResumen[2].columna5 = pDatos.calculoIndebidoActualizacionMantenimientoValor?.totalActualizacionMantenimientoValorRestituidoBs;
  }
}
