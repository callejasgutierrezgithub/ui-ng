import { CommonModule } from "@angular/common";
import { Component, inject, OnDestroy, OnInit } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatNativeDateModule } from "@angular/material/core";
import { CoreService, MaterialModule, RespuestaObjeto, TitlePageComponent, UserInfoService } from "core-lib";
import { Subscription } from "rxjs";
import { ContribuyenteModel } from "../../../models/contribuyente/contribuyente.model";
import { DatosContribuyenteService } from "../../../services/comun/datos-contribuyente.service";
import { InformacionContribuyenteComponent } from "../../../shared/components/informacion-contribuyente/informacion-contribuyente.component";
import { SccGrillaExtractoTributarioComponent } from "../../../shared/components/scc-grilla-extracto-tributario/scc-grilla-extracto-tributario.component";


@Component({
  selector: 'app-extracto-contribuyente',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    SccGrillaExtractoTributarioComponent,
    InformacionContribuyenteComponent
  ],
  templateUrl: './extracto-contribuyente.component.html',
  styleUrl: './extracto-contribuyente.component.scss'
})
export class ExtractoContribuyenteComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  existeContribuyente: boolean;
  esContribuyente: Boolean = true
  private userInfoSubscription: Subscription | undefined;

  contribuyente: ContribuyenteModel = {};

  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private _userInfo: UserInfoService,
  ) {
    this.existeContribuyente = false;
  }

  ngOnInit(): void {
    this.obtenerDatosSesion();
  }

  obtenerDatosSesion(): void {
    this.userInfoSubscription = this._userInfo.contextInfo$.subscribe(
      (response) => {
        this.buscarContribuyente(response.userInfo.nitCur);
      }
    );
  }

  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
  }

  buscarContribuyente(nitCur: number): void {
    this.existeContribuyente = false;

    this._datosContribuyente
      .obtenerContribuyente(nitCur)
      .then((respuesta: RespuestaObjeto<ContribuyenteModel>) => {
        if (respuesta.transaccion && respuesta.objeto != null) {
          this.contribuyente = respuesta.objeto;
          this.existeContribuyente = true;
        }
      })
      .catch((err) => {
        this.existeContribuyente = false;
      });
  }
}
