import { CommonModule } from '@angular/common';
import {
  AfterViewInit,
  Component,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { MaterialModule, RespuestaLista, SiatToastrService } from 'core-lib';
import {
  ValoresSaldosDetalleModel,
  ValoresSaldosModel,
} from '../../../../models/consulta-valores/valores-saldos.model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { AlertService } from '../../../../services/comun/alert.service';
import { ValoresSaldosService } from '../../../../services/registro-boletas-de-pago/valores-saldos.service';
import { ConsultaValoresService } from '../../../../services/sub-cuenta-valores/consulta-valores.service';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { PasarDatosDialog } from '../../../../shared/utils/pasar-datos-dialog';

@Component({
  selector: 'scc-modal-detalle-uso-valor',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    LocaldatePipe,
    MatNativeDateModule,
  ],
  templateUrl: './modal-detalle-uso-valor.component.html',
  styleUrl: './modal-detalle-uso-valor.component.scss',
})
export class ModalDetalleUsoValorComponent implements OnInit, AfterViewInit {
  btnLoading: boolean;
  form!: FormGroup;
  displayedColumns: Array<string>;
  mensajeResultado: string;
  dataSource;
  mensajeGrilla: string;
  totalImputadosBs: number;
  contribuyente!: ValoresSaldosModel;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private consultaValoresService: ConsultaValoresService,
    @Inject(MAT_DIALOG_DATA)
    public data: PasarDatosDialog<ValoresSaldosModel>,
    private router: Router,
    private valoresSaldosDetalleService: ValoresSaldosService
  ) {
    this.btnLoading = false;
    this.form = new FormGroup({});
    this.mensajeGrilla = '';
    this.displayedColumns = [
      'impuestoId',
      'formularioId',
      'anio',
      'periodo',
      'numeroOrdenDocumento',
      'fechaRegistro',
      'montoBs',
    ];
    this.dataSource = new MatTableDataSource<ValoresSaldosDetalleModel>([]);
    this.mensajeResultado = '';
    this.totalImputadosBs = 0;
  }

  ngOnInit(): void {
    this.form = this.formBuilder.group({});
    this.obtenerValoresSaldosDetalle();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  obtenerValoresSaldosDetalle() {
    this.valoresSaldosDetalleService
      .obtenerValoresSaldosDetalle(this.data.datos.nitCur!, this.data.datos.id!)
      .then((respuesta: RespuestaLista<ValoresSaldosModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList
            ? respuesta.objetosList
            : [];
          this.mensajeResultado =
            this.dataSource.data.length === 0
              ? MensajeConstante.MSG_NOT_RESULT
              : '';
          respuesta.objetosList?.filter((item) => {
            this.totalImputadosBs = this.totalImputadosBs + (item.montoBs || 0);
          });
        } else {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        }
      })
      .catch((err) => {
        this.dataSource.data = [];
        this.dataSource.paginator = this.paginator;
        this.toastr.info(`${MensajeConstante.MSG_ERROR} ${err}`);
      });
  }
}
