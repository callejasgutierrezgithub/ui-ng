import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import {
  CoreService,
  MaterialModule,
  RespuestaObjeto,
  SiatToastrService,
  TitlePageComponent,
} from 'core-lib';
import { ExpresionRegularEnum } from '../../../enums/expresion-regular.enum';
import { ValoresSaldosModel } from '../../../models/consulta-valores/valores-saldos.model';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaValoresService } from '../../../services/sub-cuenta-valores/consulta-valores.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { MensajeConstante } from '../../../shared/utils/mensaje-constante';
import { GrillaSubCunsultaValoresComponent } from './grilla-sub-cunsulta-valores/grilla-sub-cunsulta-valores.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';

@Component({
  selector: 'scc-sub-cuenta-valores',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    GrillaSubCunsultaValoresComponent,
    InformacionContribuyenteComponent,
  ],
  templateUrl: './sub-cuenta-valores.component.html',
  styleUrl: './sub-cuenta-valores.component.scss',
})
export class SubCuentaValoresComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  consultaNit: Boolean = false;
  mensajeNit: string = '';
  formContribuyente: FormGroup;
  cargaBotonBuscar: boolean;
  cargaBotonConsulta: boolean;
  existeContribuyente: boolean;
  mensaje: string;
  contribuyente: ContribuyenteModel = {};
  anioActual: number;
  displayedColumns: Array<string>;
  mensajeResultado: string;
  dataSource;
  oficinaId?: number;

  constructor(
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private consultaValoresService: ConsultaValoresService,
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) {
    this.displayedColumns = [
      'tipoValor',
      'impuestoEspecifico',
      'nroEmision',
      'nroTramite',
      'nroOrdenRedencion',
      'fechaRedencion',
      'importeRedimido',
      'saldoValoresSin',
      'saldoValores',
      'detalle',
    ];
    this.dataSource = new MatTableDataSource<ValoresSaldosModel>([]);
    this.mensajeResultado = '';
    this.oficinaId = 0;
    this.formContribuyente = new FormGroup({});
    this.mensaje =
      'Ingrese el NIT y presione la tecla enter o haga clic en buscar';
    this.existeContribuyente = false;
    this.cargaBotonBuscar = false;
    this.cargaBotonConsulta = false;
    const fechaActual = new Date();
    this.anioActual = fechaActual.getFullYear();
    this.crearFormulario(this.anioActual);
    this.obtenerConsultaNit();
  }

  ngOnInit(): void {
    // this.getContribuyente();
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  crearFormulario(gestion: number) {
    this.formContribuyente = this.formBuilder.group({
      nit: [
        null,
        [
          Validators.required,
          Validators.maxLength(15),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$.subscribe(
        (contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyente = contribuyente;
            this.mensaje = MensajeConstante.MSG_NOT_FOUND;
          } else {
            this.contribuyente = {};
          }
        }
      );
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }

  buscarContribuyente(): void {
    if (this.formContribuyente.valid) {
      this.cargaBotonBuscar = true;
      this.existeContribuyente = false;
      this.oficinaId =
        this._datosContribuyente.obtenerUsuarioInfo().funcionario?.oficinaId;

      const datosForm = this.formContribuyente.value;
      this.contribuyente = {
        nit: datosForm.nit,
      };

      this._datosContribuyente
        .obtenerContribuyente(datosForm.nit)
        .then((respuesta: RespuestaObjeto<ContribuyenteModel>) => {
          this.cargaBotonBuscar = false;
          if (respuesta.transaccion) {
            if (respuesta.objeto != null) {
              this.contribuyente = respuesta.objeto;
              if (
                this.contribuyente.administracion == this.oficinaId ||
                this.oficinaId == 0
              ) {
                this.existeContribuyente = true;
              }
            } else if (respuesta.objeto == null) {
              this.mensaje = MensajeConstante.MSG_NOT_FOUND;
            }
          } else {
            this.toastr.info(MensajeConstante.MSG_ERROR);
          }
        })
        .catch((err) => {
          this.cargaBotonBuscar = false;
        });
    }
    const pContribuyente: ValoresSaldosModel = {};
    this.consultaValoresService.setDataModel(pContribuyente);
  }

  limpiarContribuyente(): void {
    this.formContribuyente.reset();
    this.existeContribuyente = false;
    const pContribuyente: ValoresSaldosModel = {};
    this.consultaValoresService.setDataModel(pContribuyente);
  }

  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }
}
