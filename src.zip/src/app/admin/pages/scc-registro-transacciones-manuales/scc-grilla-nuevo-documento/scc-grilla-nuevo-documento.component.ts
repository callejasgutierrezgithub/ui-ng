import { CommonModule } from '@angular/common';
import { Component, effect, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule, RespuestaLista, SiatToastrService } from 'core-lib';
import { ParametricasEnum } from '../../../../enums/parametricas.enum';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudActualizarDocumentos } from '../../../../models/documentos-agrupadores/solicitud-actualizar-documentos.model';
import { ParametricaGenericaModel, ParametroModel } from '../../../../models/parametrica/parametrica-generica.model';
import { ReporteAdeudoTributarioService } from '../../../../services/detalle-deuda-contribuyente/reporte-adeudo-tributario.service';
import { ParametricaService } from '../../../../services/parametricas/parametrica.service';
import { OtrDetalleDeudasService } from '../../../../services/registro-deudas-manuales/otr-detalle-deudas.service';
import { SccRegistroTransaccionesManualesStoreService } from '../../../../services/store/scc-registro-transacciones-manuales-store.service';
import { SelectFilterComponent } from '../../../../shared/components/select-filter/select-filter.component';
import { Fecha } from '../../../../shared/utils/fecha';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { DeudaCalculoActualizacion, SolicitudActualizaDeudas } from '../../../../models/deudas-actualizadas-model';
import { FORMATO_FECHA_DIA_MES_ANIO } from '../../../../shared/utils/formato-fecha-date-picker/date-format';
import { CustomDateAdapter } from '../../../../shared/utils/formato-fecha-date-picker/custom-date-adapter';
import { OFICINA_ENUM } from '../../../../enums/oficina.enum';
import { SccButtonLoadingComponent } from '../../../../shared/components/scc-button-loading/scc-button-loading.component';

@Component({
  selector: 'scc-grilla-nuevo-documento',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    SelectFilterComponent,
    SccButtonLoadingComponent,
  ],
  templateUrl: './scc-grilla-nuevo-documento.component.html',
  styleUrl: './scc-grilla-nuevo-documento.component.scss',
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: FORMATO_FECHA_DIA_MES_ANIO },
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    { provide: DateAdapter, useClass: CustomDateAdapter },
  ],
})
export class SccGrillaNuevoDocumentoComponent implements OnInit {
  @Input() contribuyente: ContribuyenteModel = {};
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  formDeudasManuales: FormGroup;
  tipoProceso: ParametricaGenericaModel[];
  tipoDocumento: ParametricaGenericaModel[];
  tipoOficina: ParametricaGenericaModel[];
  procesosFiltrado: ParametricaGenericaModel[];
  oficinasFiltrado: ParametricaGenericaModel[];
  tipoDocumentoFiltrado: ParametricaGenericaModel[];
  deudas: Array<number>;
  tablaCargando: boolean;
  dataSource;
  columnas: Array<string>;
  fechaMinimoDesde: Date;
  fechaActual: Date;
  formActualizarDeudasManuales: FormGroup;
  loading: boolean;
  constructor(
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private otrService: OtrDetalleDeudasService,
    private _actualizarListaDeudas: ReporteAdeudoTributarioService,
    private parametricaService: ParametricaService,
    private transaccionesManualesStore: SccRegistroTransaccionesManualesStoreService
  ) {
    this.formDeudasManuales = new FormGroup({});
    this.tablaCargando = false;
    this.tipoProceso = [];
    this.tipoDocumento = [];
    this.tipoOficina = [];

    this.procesosFiltrado = [];
    this.oficinasFiltrado = [];
    this.tipoDocumentoFiltrado = [];
    this.deudas = [];
    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);
    this.fechaMinimoDesde = new Date('1981/01/01');
    this.fechaActual = new Date();
    this.formActualizarDeudasManuales = new FormGroup({});
    this.columnas = [
      'deudaId',
      'documentoAgrupadorId',
      'numeroOrdenDocumentoAgrupador',
      'formularioId',
      'periodo',
      'anio',
      'montoDeudaBs', //tributo Omitido
      'mantenimientoValorBs',
      'interesBs',
      'sancionBs',
      'agravanteBs',
      'multaBs',
      'deudaTotalBs',
    ];
    this.loading = false;
    this.obtenerDeudas();
  }

  ngOnInit() {
    this.crearFormularioActualizacionDeudas();
    this.obtenerParametricas();
  }

  obtenerDeudas(): void {
    effect(() => {
      this.deudas = this.transaccionesManualesStore.getDeudas()();
    });
  }

  crearFormularioActualizacionDeudas() {
    this.formActualizarDeudasManuales = this.formBuilder.group({
      documentoActualizarId: [null, [Validators.required]],
      numeroOrdenAgrupadorActualizar: [null, [Validators.required]],
      fechaNotificacionActualizar: [null, [Validators.required]],
      oficinaId: [null, [Validators.required]],
    });
  }

  obtenerParametricas() {
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.documento_id}`
      },
    };
    this.parametricaService.obtenerParametricas(parametros).then(() => {
      this.parametricaService.dataModel$.subscribe((parametrica: any) => {
        this.tipoProceso = parametrica.proceso_id ?? [];
        this.tipoProceso = this.tipoProceso.map((item: any) => {
          item.descripcion = `${item.id} - ${item.descripcion}`;
          return item;
        });
        this.procesosFiltrado = this.tipoProceso.slice();
        if (this.tipoProceso.length === 0) {
          this.toastr.info('No se encontraron valores parametricos para proceso');
        }
        this.tipoDocumento = parametrica.documento_id ?? [];
        this.tipoDocumento = this.tipoDocumento.map((item: any) => {
          item.descripcion = `${item.id} - ${item.descripcion}`;
          return item;
        });
        this.tipoDocumentoFiltrado = this.tipoDocumento.slice();
        if (this.tipoProceso.length === 0) {
          this.toastr.info('No se encontraron valores parametricos para documento');
        }
      });
    });

    this.tipoOficina = OFICINA_ENUM;
    this.oficinasFiltrado = this.tipoOficina.slice();
  }

  actualizarDocumentos(): void {
    this.tablaCargando = true;
    this.loading = true;
    const datosForm = this.formActualizarDeudasManuales.value;
    const origenId = this.formActualizarDeudasManuales.get('oficinaId')?.value;
    const origen = this.tipoOficina.find(item => item.origenId == origenId);
    console.log("Origen -> ", origen);
    const solicitud: SolicitudActualizarDocumentos = {
      nitCur: this.contribuyente.nit!,
      nuevoDocumentoAgrupadorId: Number(datosForm.documentoActualizarId),
      nuevoNumeroOrdenAgrupador: Number(datosForm.numeroOrdenAgrupadorActualizar),
      nuevaFechaNotificacion: Fecha.toLocalDate(datosForm.fechaNotificacionActualizar),
      tramiteId: 20,
      // origenId: 270,//!OBS
      origenId: origen?.origenId!,
      deudas: this.deudas,
      oficinaId: this.contribuyente.administracion!,
      dependencia: origen?.descripcion,
      dependenciaId: origen?.dependenciaId
    };

    if (solicitud.deudas.length === 0) {
      this.toastr.info(MensajeConstante.MSG_DEUDAS);
    } else {
      this.otrService
        .actualizarDocumentos(solicitud)
        .then((respuesta: any) => {
          if (respuesta.transaccion) {
            this.toastr.success(MensajeConstante.MSG_SUCCESS_UPDATE);
            this.transaccionesManualesStore.setDeudas([]);
            this.listarDetalleDeudas();
          } else {
            this.toastr.info(
              respuesta.mensajes
                ? respuesta.mensajes[0].descripcion
                : MensajeConstante.MSG_ERROR
            );
          }
        }).catch(() => {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        })
        .finally(() => {
          this.tablaCargando = false;
          setTimeout(() => {
            this.loading = false;
          }, 500)
        });

    }
  }

  listarDetalleDeudas(): void {
    let solicitudDeudas: Array<DeudaCalculoActualizacion> = this.deudas.map(item => ({ deudaId: item }))

    this.tablaCargando = true;
    let solicitud: SolicitudActualizaDeudas = {
      nitCur: this.contribuyente.nit,
      oficinaId: this.contribuyente.administracion,
      // oficinaId: 29,
      origenId: 292,
      deudas: solicitudDeudas
    }
    this._actualizarListaDeudas
      .obtenerActualizadasDeudas(solicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList ?? [];
          this.dataSource.paginator = this.paginator;
        } else {
          this.dataSource.data = [];
          this.toastr.info(
            respuesta.mensajes
              ? respuesta.mensajes[0].descripcion
              : MensajeConstante.MSG_ERROR
          );
        }
        this.tablaCargando = false
      });
  }

}
