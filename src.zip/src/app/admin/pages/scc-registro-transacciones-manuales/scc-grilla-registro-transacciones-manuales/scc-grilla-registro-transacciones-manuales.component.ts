import { SelectionModel } from '@angular/cdk/collections';
import { CommonModule } from '@angular/common';
import { Component, effect, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule, SiatToastrService } from 'core-lib';
import { ParametricasEnum } from '../../../../enums/parametricas.enum';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DeudasManualesModel, ListaDeudasManualesTableModel, RepuestaListaDeudasManualesModel } from '../../../../models/documentos-agrupadores/deudas-manuales-model';
import { SolicitudDeudasManualesModel } from '../../../../models/documentos-agrupadores/solicitud-deudas-manuales.model';
import { ParametricaGenericaModel, ParametroModel } from '../../../../models/parametrica/parametrica-generica.model';
import { ParametricaService } from '../../../../services/parametricas/parametrica.service';
import { DocumentosAgrupadoresService } from '../../../../services/registro-deudas-manuales/documentos-agrupadores.service';
import { SccRegistroTransaccionesManualesStoreService } from '../../../../services/store/scc-registro-transacciones-manuales-store.service';
import { SelectFilterComponent } from '../../../../shared/components/select-filter/select-filter.component';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';

@Component({
  selector: 'scc-grilla-registro-transacciones-manuales',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    SelectFilterComponent,
  ],
  templateUrl: './scc-grilla-registro-transacciones-manuales.component.html',
  styleUrl: './scc-grilla-registro-transacciones-manuales.component.scss'
})
export class SccGrillaRegistroTransaccionesManualesComponent implements OnInit {
  @Input() contribuyente: ContribuyenteModel = {};
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  tablaCargando: boolean;
  dataSource;
  tipoProceso: ParametricaGenericaModel[];
  tipoDocumento: ParametricaGenericaModel[];
  tipoOficina: ParametricaGenericaModel[];
  tipoDocumentoFiltrado: ParametricaGenericaModel[];
  procesosFiltrado: ParametricaGenericaModel[];
  oficinasFiltrado: ParametricaGenericaModel[];
  formTransacionesManuales: FormGroup;
  deudaArray: Array<number>;
  columnas: Array<string>;
  selection = new SelectionModel<any>(true, []);
  loading: Boolean;

  constructor(
    private formBuilder: FormBuilder,
    private parametricaService: ParametricaService,
    private documentosAgrupadoresService: DocumentosAgrupadoresService,
    private toastr: SiatToastrService,
    private transaccionesManualesStore: SccRegistroTransaccionesManualesStoreService
  ) {
    this.tablaCargando = false;
    this.dataSource = new MatTableDataSource<ListaDeudasManualesTableModel>([]);
    this.tipoProceso = [];
    this.tipoDocumento = [];
    this.tipoOficina = [];

    this.procesosFiltrado = [];
    this.oficinasFiltrado = [];
    this.tipoDocumentoFiltrado = [];

    this.formTransacionesManuales = new FormGroup({});

    this.columnas = [
      'select',
      'deudaId',
      'documentoAgrupadorId',
      'numeroOrdenAgrupador',
      'formulario',
      'periodo',
      'anio',
      'tributoOmitido',
      'mantenimientoValor',
      'interes',
      'sancion',
      'agravante',
      'multa',
    ];
    this.loading = true;
    this.deudaArray = [];
    this.obtenerDeudas();
  }
  ngOnInit() {
    setTimeout(() => {
      const parametros: ParametroModel = {
        parametricas: {
          clasificadores: `${ParametricasEnum.tipo_moneda_id}`,
        },
      };
      this.obtenerParametricas();
    }, 300);
    this.crearFormularioDeudasManuales();

    this.obtenerDeudasManuales();
  }

  obtenerDeudas(): void {
    effect(() => {
      this.deudas = this.transaccionesManualesStore.getDeudas()();
      if (this.deudas.length === 0) this.obtenerDeudasManuales();
    });
  }

  crearFormularioDeudasManuales() {
    this.formTransacionesManuales = this.formBuilder.group({
      documentoAgrupadorId: [null, [Validators.required]],
      numeroOrdenAgrupadorManual: [null, [Validators.required]],
    });
  }

  obtenerParametricas() {
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.documento_id}`,
      },
    };
    this.parametricaService.obtenerParametricas(parametros).then(() => {
      this.parametricaService.dataModel$.subscribe((parametrica: any) => {
        this.tipoProceso = parametrica.proceso_id ?? [];
        this.tipoProceso = this.tipoProceso.map((item: any) => {
          item.descripcion = `${item.id} - ${item.descripcion}`;
          return item;
        });
        this.procesosFiltrado = this.tipoProceso.slice();
        if (this.tipoProceso.length === 0) {
          this.toastr.info('No se encontraron valores parametricos para proceso');
        }
        this.tipoDocumento = parametrica.documento_id ?? [];
        this.tipoDocumento = this.tipoDocumento.map((item: any) => {
          item.descripcion = `${item.id} - ${item.descripcion}`;
          return item;
        });
        this.tipoDocumentoFiltrado = this.tipoDocumento.slice();
        if (this.tipoProceso.length === 0) {
          this.toastr.info('No se encontraron valores parametricos para documento');
        }

        this.tipoOficina = parametrica.oficina ?? [];
        this.oficinasFiltrado = this.tipoOficina.slice();
      });
    });
  }

  obtenerDeudasManuales(): void {
    this.tablaCargando = true;
    const Solicitud: SolicitudDeudasManualesModel = {
      nitCur: this.contribuyente.nit,
      tipoContribuyentePdrId: 0,
    };

    this.documentosAgrupadoresService
      .obtenerDeudasManuales(Solicitud)
      .then((respuesta: RepuestaListaDeudasManualesModel) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.registro ?? [];
          this.dataSource.paginator = this.paginator;
          this.deudaArray = this.dataSource.data.map(
            (item: DeudasManualesModel) => {
              return item.deudaId;
            }
          );
          if (this.dataSource.data.length === 0) {
            this.toastr.success(
              MensajeConstante.MSG_ERROR_REGISTROS_MANUALES
            );
          }

        } else {
          this.dataSource.data = [];
          this.toastr.info(
            MensajeConstante.MSG_ERROR_REGISTROS_MANUALES
          );
        }
      })
      .catch(() => {
        this.dataSource.data = [];
        this.tablaCargando = false;
        this.toastr.info(MensajeConstante.MSG_ERROR);
      })
      .finally(() => {
        this.tablaCargando = false;
        setTimeout(() => {
          this.loading = false;
        }, 400)
      });
  }

  isAllSelected(): any {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle(): void {
    if (this.isAllSelected()) {
      this.selection.clear()
    } else {
      this.dataSource.data.forEach((row) => this.selection.select(row));
    }
    this.transaccionesManualesStore.setDeudas(this.selection.selected);
  }

  checkboxLabel(row?: any): string {
    if (!row) {
      return (this.isAllSelected() ? 'select' : 'deselect') + ' all';
    }
    return (this.selection.isSelected(row) ? 'deselect' : 'select') + ' row ' + (row.deudaId! + 1);
  }
  deudas: number[] = [];
  onCheckChange($event: any, element: any) {
    if ($event.checked) {
      this.deudas.push(element.deudaId);
    } else {
      const index = this.deudas.indexOf(element.deudaId);
      if (index > -1) {
        this.deudas.splice(index, 1);
      }
    }
    this.transaccionesManualesStore.setDeudas(this.deudas);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }
}