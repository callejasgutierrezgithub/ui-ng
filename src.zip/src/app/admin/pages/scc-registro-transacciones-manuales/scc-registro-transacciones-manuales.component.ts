import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { SccRegistroTransaccionesManualesStoreService } from '../../../services/store/scc-registro-transacciones-manuales-store.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { SccGrillaNuevoDocumentoComponent } from './scc-grilla-nuevo-documento/scc-grilla-nuevo-documento.component';
import { SccGrillaRegistroTransaccionesManualesComponent } from './scc-grilla-registro-transacciones-manuales/scc-grilla-registro-transacciones-manuales.component';

@Component({
  selector: 'scc-registro-transacciones-manuales',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    InformacionContribuyenteComponent,
    SccGrillaRegistroTransaccionesManualesComponent,
    SccGrillaNuevoDocumentoComponent],
  templateUrl: './scc-registro-transacciones-manuales.component.html',
  styleUrl: './scc-registro-transacciones-manuales.component.scss'
})
export class SccRegistroTransaccionesManualesComponent implements OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  deudas: Array<number>;
  mensajeNit: string = '';
  consultaNit: Boolean = false;
  contribuyente: ContribuyenteModel = {};
  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private transaccionesManualesStore: SccRegistroTransaccionesManualesStoreService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) {
    this.deudas = [];
    this.obtenerDeudas();
    this.obtenerConsultaNit();
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {}
        }
      });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }

  obtenerDeudas(): void {
    effect(() => {
      this.deudas = this.transaccionesManualesStore.getDeudas()();
    });
  }

  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }
}