import { UserInfo } from 'str-auth-lib';
import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { RouterModule } from '@angular/router';
import { CoreService, MaterialModule, Respuesta, SiatToastrService, TitlePageComponent, UserInfoService } from 'core-lib';
import { Subject, Subscription, takeUntil } from 'rxjs';
import { ConusltaIdEnum } from '../../../enums/general.enum';
import { ParametricasEnum } from '../../../enums/parametricas.enum';
import { SolicitudRegistroBitacoraModel } from '../../../models/bitacora-consultas/bitacora-consultas';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { ParametroModel } from '../../../models/parametrica/parametrica-generica.model';
import { MotivoConsultaModel } from '../../../models/reporte-adeudo-tributario/reporte-adeudo-tributario.model';
import { BitacoraConsultasService } from '../../../services/bitacora-consultas-service';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ParametricaService } from '../../../services/parametricas/parametrica.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { Mensajes } from '../../../shared/utils/mensajes.const';
import { BolsasComponent } from '../estado-cuenta-contribuyente/bolsas/bolsas.component';
import { SccBolsasCuentaComponent } from '../scc-bolsas-cuenta/scc-bolsas-cuenta.component';
import { SccDetalleDeudaContribuyenteComponent } from './scc-detalle-deuda-contribuyente/scc-detalle-deuda-contribuyente.component';
import { SccValoresEconomicosComponent } from './scc-valores-economicos/scc-valores-economicos.component';

@Component({
  selector: 'scc-consulta-deudas-por-contribuyente-internas',
  standalone: true,
  imports: [
    MaterialModule, ReactiveFormsModule, CommonModule, RouterModule, MatNativeDateModule, FormsModule,
    TitlePageComponent,
    DatosContribuyenteComponent, SccValoresEconomicosComponent, SccDetalleDeudaContribuyenteComponent, SccBolsasCuentaComponent,
    InformacionContribuyenteComponent, BolsasComponent],
  templateUrl: './scc-consulta-deudas-por-contribuyente-internas.component.html',
  styleUrl: './scc-consulta-deudas-por-contribuyente-internas.component.scss'
})
export class SccConsultaDeudasPorContribuyenteInternasComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  private destroy$ = new Subject<void>();
  private parametricaSubscription?: Subscription;
  consultaNit: Boolean = false;
  mensajeNit: string = '';
  formMotivoConsulta: FormGroup;
  contribuyente: ContribuyenteModel = {};
  motivoConsultaFiltrado: MotivoConsultaModel[] = [];
  tipoConsulta: MotivoConsultaModel[] = this.motivoConsultaFiltrado.filter(
    (item) => item.id
  );
  tipoUsuarioId: number = 0;
  nitLogin?: number;
  usuarioLogin?: string;
  constructor(
    private formBuilder: FormBuilder,
    private parametricaService: ParametricaService,
    private _datosContribuyente: DatosContribuyenteService,
    private _userInfo: UserInfoService,
    private bitacoraConsultasService: BitacoraConsultasService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
    private toastr: SiatToastrService,
  ) {
    this.formMotivoConsulta = new FormGroup({});
    this.obtenerConsultaNit();
  }

  ngOnInit() {
    this.crearFormulario();
    setTimeout(() => {
      this.obtenerParametricas();
    }, 500);

    setTimeout(() => {
      this.obtenerParametricaMotivo();
    }, 1000);
  }

  crearFormulario() {
    this.formMotivoConsulta = this.formBuilder.group({
      motivoConsulta: [null, [Validators.required]],
    });
  }

  obtenerParametricas() {
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.motivo_id}`,
      },
    };
    this.parametricaService.obtenerParametricas(parametros);
  }

  obtenerParametricaMotivo(): void {
    this.parametricaSubscription = this.parametricaService.dataModel$.subscribe((parametrica: any) => {
      this.tipoConsulta = parametrica.motivo_id ?? [];
      this.motivoConsultaFiltrado = this.tipoConsulta.slice();
      if (this.tipoConsulta.length === 0) {
        // this.toastr.info(
        //   'No se encontraron valores parametricos para MOTIVO CONSULTA'
        // );
      }
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$.pipe(takeUntil(this.destroy$)).subscribe((contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
          this.registrarBitacoraConsulta();
        } else {
          this.contribuyente = {}
        }
      });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }

  ngOnDestroy(): void {
    if (this.parametricaSubscription) {
      this.parametricaSubscription.unsubscribe();
      this._datosContribuyente.setDataModel({});
    }
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
    this.destroy$.next();
    this.destroy$.complete();
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  obtenerDatosSesion(): void {
    this._userInfo.contextInfo$.subscribe(
      (response) => {
        this.nitLogin = response.userInfo.nitCur;
        this.usuarioLogin = response.userInfo.login;
        this.tipoUsuarioId = response.userInfo.tipoUsuarioId;

      }
    );
  }

  registrarBitacoraConsulta(): void {
    this.obtenerDatosSesion();
    const solicitud: SolicitudRegistroBitacoraModel = {
      consultaId: ConusltaIdEnum.DEUDAS_CONTRIBUYENTE,
      nitCurLogin: this.nitLogin,
      usuarioLogin: this.usuarioLogin,
      nitCurConsultado: this.contribuyente.nit,
      motivo: this.formMotivoConsulta.value.motivoConsulta,
      tipoContribuyentePdrId: 0,
    };
    this.bitacoraConsultasService
      .registrarBitacoraConsultas(solicitud)
      .then((respuesta: Respuesta) => {
        if (!respuesta.transaccion) this.toastr.warning(Mensajes.MSG_NOT_ADD);
      });
  }
}