import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, SiatToastrService } from 'core-lib';
import { RespuestaValorEconomico } from '../../../../models/valores-economicos/respuesta-valor-economico.model';
import { SolicitudValorEconomico } from '../../../../models/valores-economicos/solicitud-valor-economico.model';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { ParametricaValoresEconomicosService } from '../../../../services/parametricas/parametrica-valores-economicos.service';
import { Fecha } from '../../../../shared/utils/fecha';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';

@Component({
  selector: 'scc-valores-economicos',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule, MatNativeDateModule, FormsModule],
  templateUrl: './scc-valores-economicos.component.html',
  styleUrl: './scc-valores-economicos.component.scss'
})
export class SccValoresEconomicosComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  ufv: number;
  tipoCambio: number;
  oficinaId: number;
  fechaActual: Date;
  loading: Boolean;
  constructor(
    private toastr: SiatToastrService,
    private _datosContribuyente: DatosContribuyenteService,
    private parametricasService: ParametricaValoresEconomicosService,
  ) {
    this.ufv = 0;
    this.tipoCambio = 0;
    this.fechaActual = new Date();
    this.oficinaId = 0;
    this.loading = true;
  }

  ngOnInit() {
    this.getContribuyten();
  }

  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
      if (contribuyente && contribuyente.nit) {
        this.oficinaId = contribuyente.administracion!;
        this.obtenerValoresEconomicos();
      } else {
        this.oficinaId = 0
        this.ufv = 0;
        this.tipoCambio = 0;
      }
      setTimeout(() => {
        this.loading = false;
      }, 1000)
    });
  }

  obtenerValoresEconomicos(): void {
    const solicitud: SolicitudValorEconomico = {
      fecha: Fecha.toLocalDate(this.fechaActual),
      oficinaId: this.oficinaId,
    };

    this.parametricasService
      .obtenerValoresEconomicos(solicitud)
      .then((respuesta: RespuestaValorEconomico) => {
        if (respuesta.transaccion) {
          this.ufv = respuesta.valorUfv;
          this.tipoCambio = respuesta.tipoCambio;
        } else {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        }
      });
  }
}