import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MaterialModule } from 'core-lib';

@Component({
  selector: 'scc-modal-detalle-deuda-actualizacion',
  standalone: true,
  imports: [MaterialModule, ReactiveFormsModule, CommonModule, MatNativeDateModule, FormsModule],
  templateUrl: './scc-modal-detalle-deuda-actualizacion.component.html',
  styleUrl: './scc-modal-detalle-deuda-actualizacion.component.scss'
})
export class SccModalDetalleDeudaActualizacionComponent {

}
