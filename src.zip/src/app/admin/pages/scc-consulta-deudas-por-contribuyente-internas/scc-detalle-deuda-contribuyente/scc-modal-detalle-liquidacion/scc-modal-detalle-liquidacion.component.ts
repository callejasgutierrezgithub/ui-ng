import { CommonModule } from '@angular/common';
import { Component, Inject, LOCALE_ID, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule, RespuestaLista } from 'core-lib';
import { DetalleDeudaModel } from '../../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { ReporteAdeudoTributarioService } from '../../../../../services/detalle-deuda-contribuyente/reporte-adeudo-tributario.service';
import { PasarDatosDialog } from '../../../../../shared/utils/pasar-datos-dialog';

@Component({
  selector: 'scc-modal-detalle-liquidacion',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-modal-detalle-liquidacion.component.html',
  styleUrl: './scc-modal-detalle-liquidacion.component.scss',
})
export class SccModalDetalleLiquidacionComponent implements OnInit {
  formLiquidaciones: FormGroup;
  tableLoading: boolean;
  tablaColumnas: string[];
  dataSource;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(
    public dialogRef: MatDialogRef<SccModalDetalleLiquidacionComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA)
    public data: PasarDatosDialog<DetalleDeudaModel>,
    private reporteAdeudoService: ReporteAdeudoTributarioService
  ) {
    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);

    this.tableLoading = false;
    this.formLiquidaciones = this.formBuilder.group({});

    this.tablaColumnas = [
      'fechaRegistro',
      'documentoAgrupador',
      'documento',
      'numeroOrdenDocumento',
      'origen',
      'dependencia',
      'fechaNotificacion',
      'montoDeudaBs',
      'interesBs',
      'interesDetalle',
      'mantenimientoValorBs',
      'sancionBs',
      'agravanteBs',
      'multaBs',
      'montoDeudaUfv',
      'interesUfv',
      'mantenimientoValorUfv',
      'sancionUfv',
      'agravanteUfv',
      'multaUfv',
    ];
  }

  ngOnInit(): void {
    this.crearFormulario();
    this.obtenerDetalleLiquidaciones();
  }
  crearFormulario() {
    this.formLiquidaciones = this.formBuilder.group({
      deudaId: [this.data.datos.deudaId],
    });
    this.formLiquidaciones.controls['deudaId'].disable();
  }
  obtenerDetalleLiquidaciones() {
    this.tableLoading = true;
    if (this.data) {
      const vSolicitud: any = {
        nitCur: this.data.datos.nitCur,
        tipoContribuyentePdrId: 0,
        deudaId: this.data.datos.deudaId,
      };
      this.reporteAdeudoService
        .obtenerDetalleLiquidacion(vSolicitud)
        .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
          this.dataSource.data = respuesta.objetosList ?? [];
          this.dataSource.data.map(function (item) {
            item.fechaNotificacion = item.fechaNotificacion! ?? '';
            item.fechaRegistro = item.fechaRegistro! ?? '';
            item.interesDetalle = JSON.parse(item.interesDetalle!);
            return item;
          });
          this.dataSource.paginator = this.paginator;
        })
        .finally(() => {
          this.tableLoading = false;
        });
    }
  }
}
