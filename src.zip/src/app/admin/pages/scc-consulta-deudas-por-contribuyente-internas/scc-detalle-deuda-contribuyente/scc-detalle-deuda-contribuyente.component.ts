import { SelectionModel } from '@angular/cdk/collections';
import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
} from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista, SiatToastrService } from 'core-lib';
import { Subscription } from 'rxjs';
import { ExpresionRegularEnum } from '../../../../enums/expresion-regular.enum';
import { MonedaEnum } from '../../../../enums/general.enum';
import { Operacion } from '../../../../enums/operaciones.enum';
import {
  FormularioModel,
  RespuestaFormulario,
  RespuestaFormularioDdjj,
} from '../../../../models/impuesto-asociado/formulario.model';
import {
  ImpuestoModel,
  RespuestaImpuestos,
} from '../../../../models/impuesto-asociado/impuesto.model';
import { ParametricaGenericaModel } from '../../../../models/parametrica/parametrica-generica.model';
import { DeudaContribuyenteModel } from '../../../../models/reporte-adeudo-tributario/deuda-contribuyente.model';
import { RespuestaValorEconomico } from '../../../../models/valores-economicos/respuesta-valor-economico.model';
import { SolicitudValorEconomico } from '../../../../models/valores-economicos/solicitud-valor-economico.model';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { ParametricaValoresEconomicosService } from '../../../../services/parametricas/parametrica-valores-economicos.service';
import { ParametricaService } from '../../../../services/parametricas/parametrica.service';
import { Fecha } from '../../../../shared/utils/fecha';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { PasarDatosDialog } from '../../../../shared/utils/pasar-datos-dialog';

import {
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
  MomentDateAdapter,
} from '@angular/material-moment-adapter';
import * as _moment from 'moment';
import { default as _rollupMoment, Moment } from 'moment';
import { TipoUsuarioIdEnum } from '../../../../enums/usuario-contexto';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudDetalleDeuda, SolicitudDetalleDeudaPeriodoFormulario } from '../../../../models/detalle-deudas-contribuyente/solicitud-detalle-deudas.model';
import { SolicitudActualizaDeudas } from '../../../../models/deudas-actualizadas-model';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';
import { ReporteAdeudoTributarioService } from '../../../../services/detalle-deuda-contribuyente/reporte-adeudo-tributario.service';
import { FormularioDdjjService } from '../../../../services/formularios-ddjj/formulario-ddjj.service';
import { SelectFilterComponent } from '../../../../shared/components/select-filter/select-filter.component';
import { FORMATO_FECHA_MES_ANIO } from '../../../../shared/utils/formato-fecha-date-picker/date-format';
import { SccModalDetalleDeudaActualizacionComponent } from './scc-modal-detalle-deuda-actualizacion/scc-modal-detalle-deuda-actualizacion.component';
import { SccModalDetalleLiquidacionComponent } from './scc-modal-detalle-liquidacion/scc-modal-detalle-liquidacion.component';
import { SccModalDetallePagosComponent } from './scc-modal-detalle-pagos/scc-modal-detalle-pagos.component';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'scc-detalle-deuda-contribuyente',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
    SelectFilterComponent,
    LocaldatePipe
  ],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: FORMATO_FECHA_MES_ANIO },
  ],
  templateUrl: './scc-detalle-deuda-contribuyente.component.html',
  styleUrl: './scc-detalle-deuda-contribuyente.component.scss',
})
export class SccDetalleDeudaContribuyenteComponent
  implements OnInit, OnDestroy {
  @Input() tipoUsuarioId: number = 0;
  private settings = inject(CoreService);
  optionsThema = this.settings.getOptions();
  private contribuyenteSubscription?: Subscription;
  loading: boolean = true;
  selectedDeudas: any[] = [];
  fechaMinimo: Date;
  formContribuyente: FormGroup;
  oficinaId?: number;
  impuestos: ImpuestoModel[];
  formularios: FormularioModel[];
  formulariosDDJJ: FormularioModel[];
  impuestosFiltrado: any;
  formulariosFiltrado: any;
  formulariosDDJJFiltrado: any;
  selectedFormularios: number[];
  totalSaldoDeudaBs: number;
  totalSaldoDeudaUsd: number;
  totalDeudaSeleccionadas: number;
  saldoDeudaBs: number;
  saldoDeudaUsd: number;
  contribuyente: ContribuyenteModel = {};
  fechaActual: Date;
  tipoCambio: number;
  tipoProceso: ParametricaGenericaModel[];
  procesosFiltrado: ParametricaGenericaModel[];
  dataSource;
  displayedColumns: string[] = [];
  selection = new SelectionModel<any>(true, []);
  mensajeTable: string;
  dataSourceAll;
  tableLoading: boolean = false;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  selectedRows = new Set<any>();
  dateDesde = new FormControl(moment('1981-01-01', 'YYYY-MM-DD'));
  dateHasta = new FormControl(moment());
  dateMesAnio = new FormControl(moment());
  options = [
    { value: 'porImpuesto', label: 'Impuesto' },
    { value: 'porProceso', label: 'Proceso' },
    { value: 'porDeudaVigente', label: 'Deuda Vigente' },
    { value: 'porDeudaHistorica', label: 'Deuda Historica' },
  ];
  mensageDeuda: String = "";
  paginatorAsignado: Boolean = false;
  obtenerDeudasBoolean: Boolean = true;
  constructor(
    private formBuilder: FormBuilder,
    private dialog: MatDialog,
    private parametricasService: ParametricaValoresEconomicosService,
    private reporteAdeudoService: ReporteAdeudoTributarioService,
    private parametricaValoresEconomicosService: ParametricaValoresEconomicosService,
    private parametricaService: ParametricaService,
    private toastr: SiatToastrService,
    private datosContribuyenteService: DatosContribuyenteService,
    private _formulariosDdjj: FormularioDdjjService,
  ) {
    this.formContribuyente = new FormGroup({});
    this.impuestos = [];
    this.formularios = [];
    this.formulariosDDJJ = [];
    this.selectedFormularios = [];
    this.fechaMinimo = new Date('1981/01/01');
    this.totalSaldoDeudaBs = 0;
    this.totalSaldoDeudaUsd = 0;
    this.totalDeudaSeleccionadas = 0;
    this.tipoCambio = 0;
    this.saldoDeudaBs = 0;
    this.saldoDeudaUsd = 0;
    this.fechaActual = new Date();
    this.tipoProceso = [];
    this.procesosFiltrado = [];
    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);
    this.dataSourceAll = new MatTableDataSource<DetalleDeudaModel>([]);
    this.mensajeTable = '';
  }

  ngOnInit() {
    if (this.tipoUsuarioId === TipoUsuarioIdEnum.FUNCIONARIO) {
      this.displayedColumns = [
        'select',
        'nro',
        'deudaId',
        'deudaTotalBs',
        'documentoId',
        'numeroOrdenDocumento',
        'documentoAgrupadorId',
        'numeroOrdenDocumentoAgrupador',
        'impuestoId',
        'dependencia',
        'documentoAgrupador',
        'proceso',
        'documento',
        'formularioId',
        'periodo',
        'anio',
        'fechaVencimiento',
        'fechaRegistro',
        'fechaNotificacion',
        'moneda',
        'montoDeudaInicialRepositorioBs', //montoDeudaInicialBs -> repositorio
        'montoDeudaInicialBs', //saldo monto_deuda_bs -> repositorio liquidaciones -> tributo omitido
        'interesBs',
        'mantenimientoValorBs',
        'sancionBs',
        'agravanteBs',
        'multaBs',
        'interesUfv',
        'mantenimientoValorUfv',
        'sancionUfv',
        'agravanteUfv',
        'multaUfv',
        'deudaTotalUfv',
        'deudaTotalUsd',
        'montoDeudaUsd',
        'interesDetalle',
        'acciones',
      ];
    } else if (this.tipoUsuarioId === TipoUsuarioIdEnum.CONTRIBUYENTE) {
      this.displayedColumns = [
        'select',
        'nro',
        'deudaId',
        'deudaTotalBs',
        'documentoId',
        'numeroOrdenDocumento',
        'documentoAgrupadorId',
        'numeroOrdenDocumentoAgrupador',
        'impuestoId',
        'dependencia',
        'documentoAgrupador',
        'proceso',
        'documento',
        'formularioId',
        'periodo',
        'anio',
        'fechaVencimiento',
        'fechaRegistro',
        'fechaNotificacion',
        'moneda',
        'montoDeudaInicialRepositorioBs', //montoDeudaInicialBs -> repositorio
        'montoDeudaInicialBs', //saldo monto_deuda_bs -> repositorio liquidaciones -> tributo omitido
        'interesBs',
        'mantenimientoValorBs',
        'sancionBs',
        'agravanteBs',
        'multaBs',
        'interesUfv',
        'mantenimientoValorUfv',
        'sancionUfv',
        'agravanteUfv',
        'multaUfv',
        'deudaTotalUfv',
        'deudaTotalUsd',
        'montoDeudaUsd',
        'acciones',
      ];
    }
    this.getContribuyten();
    this.crearFormulario();

    setTimeout(() => {
      this.obtenerImpuestos();
      this.limpiarAnioMes();
    }, 300);

    setTimeout(() => {
      this.obtenerParametricaTipoProceso();
    }, 1000);
    this.criterioBusquedaPorDefecto();
    this.obtenerFormulariosDdjj();
  }

  criterioBusquedaPorDefecto(): void {
    if (this.options.length > 0) {
      this.formContribuyente.get('selectOpcion')?.setValue(this.options[0].value);
      this.criterioBusqueda();
    }
  }

  obtenerFormulariosDdjj() {
    this._formulariosDdjj
      .obtenerFormularios()
      .then((respuesta: RespuestaFormularioDdjj) => {
        if (respuesta.transaccion) {
          this.formulariosDDJJ = respuesta.formularios.map(
            (item: FormularioModel) => {
              item.descripcionLarga = `${item.formulario} - ${item.descripcion}`;
              return item;
            }
          );
          this.formulariosDDJJFiltrado = this.formulariosDDJJ.slice();
        } else {
          this.toastr.info('Error en el servicio');
        }
      });
  }

  obtenerParametricaTipoProceso() {
    this.parametricaService.dataModel$.subscribe((parametrica: any) => {
      this.tipoProceso = parametrica.proceso_id ?? [];

      this.procesosFiltrado = parametrica.proceso_id.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.id} - ${item.descripcion}`;
          return item;
        }
      );

      this.procesosFiltrado = this.tipoProceso.slice();
      if (this.tipoProceso.length === 0) {
        this.toastr.info('No se encontraron valores parametricos para proceso');
      }
    });
  }

  detallePagos(deudaContribuyente: DeudaContribuyenteModel): void {
    deudaContribuyente.nitCur = this.contribuyente.nit;
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    this.dialog.open(SccModalDetallePagosComponent, {
      panelClass: 'border-dialog',
      width: '1100px',
      enterAnimationDuration: '300ms',
      exitAnimationDuration: '300ms',
      autoFocus: false,
      disableClose: true,
      data: datos,
    });
  }

  detalleLiquidaciones(deudaContribuyente: DetalleDeudaModel): void {
    deudaContribuyente.nitCur = this.contribuyente.nit;
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    this.dialog.open(SccModalDetalleLiquidacionComponent, {
      panelClass: 'border-dialog',
      width: '1500px',
      enterAnimationDuration: '300ms',
      exitAnimationDuration: '300ms',
      autoFocus: false,
      disableClose: true,
      data: datos,
    });
  }

  detalleDeudaActualizacion(deudaContribuyente: DeudaContribuyenteModel): void {
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    const dialogRef = this.dialog.open(
      SccModalDetalleDeudaActualizacionComponent,
      {
        disableClose: true,
        width: '500',
        data: datos,
      }
    );
  }

  crearFormulario() {
    this.formContribuyente = this.formBuilder.group({
      mesAnioDesde: [],
      mesAnioHasta: [],
      mesAnio: [],
      impuestoId: [0],
      formularioId: [0],
      formularioDdjjId: [0],
      procesoId: [0, [Validators.pattern(ExpresionRegularEnum.Numeros)]],
      deudaId: [0, [Validators.pattern(ExpresionRegularEnum.Numeros)]],
      selectOpcion: [null, [Validators.required]],
    });
  }

  criterioBusqueda(): void {
    this.mensageDeuda = ''
    var tipoDeuda = this.formContribuyente.value.selectOpcion;
    this.dataSource.data = this.dataSourceAll.data;
    this.dateDesde.reset();
    this.dateHasta.reset();
    this.dateMesAnio.reset();
    this.formContribuyente.get('formularioId')?.disable();
    if (tipoDeuda === 'porImpuesto') {
      this.selDos();
    }

    if (tipoDeuda === 'porProceso') {
      this.selTres()
    }

    if (tipoDeuda === 'porDeudaVigente') {
      this.selCuatro();
    }

    if (tipoDeuda === 'porDeudaHistorica') {
      this.selQuinto();
      this.dataSource.data = []
    }

    setTimeout(() => {
      this.dataSource.paginator = this.paginator;
    }, 150)
  }

  filtrarPorImpuesto(): void {
    const campoControl = this.formContribuyente.get('tributoOmitido')!;
    campoControl.setValue('');
    var tipoDeuda = this.formContribuyente.value.selectOpcion;
    if (tipoDeuda === 'bs' || tipoDeuda === 'usd') {
      campoControl.setValidators([
        Validators.required,
        Validators.min(0),
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
      ]);
      campoControl.enable();
    }

    if (tipoDeuda === 'ufv') {
      campoControl.clearValidators();
      campoControl.disable();
    }
    campoControl.updateValueAndValidity();
  }

  obtenerImpuestos() {
    this.limpiarFiltroParaImpuestoFormulario();
    this.parametricasService
      .obtenerImpuestos()
      .then((respuesta: RespuestaImpuestos) => {
        if (respuesta.transaccion) {
          this.impuestos = respuesta.objetosList.map((item: ImpuestoModel) => {
            item.descripcion = `${item.impuesto} - ${item.descripcion}`;
            return item;
          });
          this.impuestosFiltrado = this.impuestos.slice();
          if (this.formContribuyente.controls['impuestoId'].value) {
            this.obtenerFormularios();
          }
        } else {
          this.toastr.info('No se encontraron valores parametricos impuesto');
        }
      });
  }

  obtenerFormularios() {
    const impuesto: ImpuestoModel = {
      id: this.formContribuyente.value.impuestoId,
    };
    this.formContribuyente.get('formularioId')?.reset();
    this.formContribuyente.get('formularioId')?.enable();
    this.parametricasService
      .obtenerFormularios(impuesto)
      .then((respuesta: RespuestaFormulario) => {
        if (respuesta.transaccion) {
          this.formularios = respuesta.objetosList.map(
            (item: FormularioModel) => {
              item.descripcionLarga = `${item.formulario} - ${item.formularioDescripcion}`;
              return item;
            }
          );
          this.formulariosFiltrado = this.formularios.slice();
        }
      });
  }

  onSelectionChange(item: any) {
    if (item.selected) {
      this.selectedFormularios.push(item.formulario);
    } else {
      const index = this.selectedFormularios.indexOf(item.formulario);
      if (index > -1) {
        this.selectedFormularios.splice(index, 1);
      }
    }
  }

  consultaDetalleDeuda(): void {
    this.mensageDeuda = ''
    this.loading = true;
    this.totalSaldoDeudaBs = 0;
    this.totalSaldoDeudaUsd = 0;
    this.saldoDeudaBs = 0;
    this.saldoDeudaUsd = 0;
    const solicitud: SolicitudDetalleDeuda = {
      nitCur: Number(this.contribuyente.nit),
      deudaId: Number(this.formContribuyente.value.deudaId) || 0,
      impuestoId: this.formContribuyente.value.impuestoId || 0,
      formularioId: this.formContribuyente.value.formularioId || [],
      procesoId: this.formContribuyente.value.procesoId || 0,
      formularioDdjjId: this.formContribuyente.value.formularioDdjjId || 0,

      anioDesde: this.dateDesde.value?.year() || 0,
      periodoDesde: this.dateDesde.value?.month()! + 1 || 0,
      anioHasta: this.dateHasta.value?.year() || 0,
      periodoHasta: this.dateHasta.value?.month()! + 1 || 0,
      anio: this.dateMesAnio.value?.year() || 0,
      mes: this.dateMesAnio.value?.month()! + 1 || 0,
      oficinaId: this.contribuyente.administracion
    };
    let tipoDeuda = this.formContribuyente.value.selectOpcion;
    if (
      solicitud.anioDesde! > 0 &&
      solicitud.periodoDesde! > 0 &&
      solicitud.anioHasta! > 0 &&
      solicitud.periodoHasta! > 0
    ) {
      this.dataSource.data = this.dataSourceAll.data;
      this.dataSource.data = this.dataSource.data.filter((item) => {
        const valorItem = item.anio! * 100 + item.periodo!;
        const desde = solicitud.anioDesde! * 100 + solicitud.periodoDesde!;
        const hasta = solicitud.anioHasta! * 100 + solicitud.periodoHasta!;

        return valorItem >= desde && valorItem <= hasta;
      });
    }

    if (solicitud.impuestoId! > 0 && solicitud.formularioId!.length > 0) {
      this.dataSource.data = this.dataSourceAll.data;
      this.dataSource.data = this.dataSource.data.filter(
        (item) =>
          item.impuestoId == solicitud.impuestoId &&
          solicitud.formularioId!.includes(item.formularioId!)
      );
    }

    if (solicitud.procesoId! > 0) {
      this.dataSource.data = this.dataSourceAll.data;
      this.dataSource.data = this.dataSource.data.filter(
        (item) =>
          item.procesoId == solicitud.procesoId
      );
    }

    if (solicitud.deudaId! > 0) {
      if (tipoDeuda === 'porDeudaVigente') {
        this.dataSource.data = this.dataSourceAll.data;
        this.dataSource.data = this.dataSource.data.filter(
          (item) =>
            item.deudaId == solicitud.deudaId
        );
        if (this.dataSource.data.length <= 0) {
          this.buscarDeuda(this.contribuyente.nit!, solicitud.deudaId!, this.contribuyente.administracion!)
        }
      }

      if (tipoDeuda === 'porDeudaHistorica') {
        this.buscarDeudaHistorico(this.contribuyente.nit!, solicitud.deudaId!)
      }
    }

    if (solicitud.mes! > 0 && solicitud.anio! > 0 && solicitud.formularioDdjjId && solicitud.deudaId! === 0) {

      if (tipoDeuda === 'porDeudaHistorica') {

        this.buscarDeudaHistoricoPeriodoFormulario(solicitud)
      }
    }


    setTimeout(() => {
      this.loading = false;
      this.dataSource.paginator = this.paginator;
    }, 200)
  }
  obtenerDeudas() {
    this.loading = true;
    this.mensageDeuda = '';
    this.obtenerDeudasBoolean = true;
    const solicitud: SolicitudDetalleDeuda = {
      nitCur: Number(this.contribuyente.nit),
      oficinaId: this.contribuyente.administracion,
      origenId: 292,
    };
    this.tableLoading = true;
    this.reporteAdeudoService
      .obtenerDetalleDeuda(solicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        this.obtenerDeudasBoolean = respuesta.transaccion;
        this.mensajeTable =
          respuesta.objetosList!.length === 0
            ? MensajeConstante.MSG_NOT_RESULT
            : '';
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.dataSource.data = respuesta.objetosList ?? [];
            this.dataSource.data.map(function (dato) {
              dato.moneda =
                dato.monedaId === MonedaEnum.BOLIVIANOS_ID
                  ? MonedaEnum.BOLIVIANOS : dato.monedaId === MonedaEnum.DOLARES_ID
                    ? MonedaEnum.DOLARES : String(dato.monedaId);
              dato.interesDetalle = JSON.parse(dato.interesDetalle!);

              return dato;
            });

            this.tableLoading = false;
            this.dataSource.paginator = this.paginator;
            this.dataSourceAll.data = this.dataSource.data;
          } else {
            this.dataSource.data = [];
          }
          if (this.dataSource.data.length === 0) this.mensageDeuda = `El Nit: ${this.contribuyente.nit}, no tiene Deudas...`;
        } else {
          this.toastr.warning(respuesta.mensajes[0].descripcion);
          this.mensageDeuda = `Error en el servicio...`;
        }
      })
      .catch(() => {
        this.toastr.error('Error al Obtener Deudas...');
        this.mensageDeuda = "Error al Obtener Deudas...";
      }).finally(() => {
        setTimeout(() => {
          this.loading = false;
        }, 200);
      });
  }

  ngAfterViewChecked() {
    if (!this.paginatorAsignado && this.paginator && this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.paginatorAsignado = true;
    }
  }

  toggleSelectAll(checked: boolean) {
    if (checked) {
      this.dataSource.data.forEach((row) => this.selectedRows.add(row));
    } else {
      this.selectedRows.clear();
    }
    this.calculateTotal();
  }

  isIndeterminate(): boolean {
    return (
      this.selectedRows.size > 0 &&
      this.selectedRows.size < this.dataSource.data.length
    );
  }

  toggleSelection(row: any) {
    if (this.selectedRows.has(row)) {
      this.selectedRows.delete(row);
    } else {
      this.selectedRows.add(row);
    }
    this.calculateTotal();
  }

  isSelected(row: any): boolean {
    return this.selectedRows.has(row);
  }
  totalValues: Record<string, number> = {};

  calculateTotal(): void {
    const fields = [
      { field: 'deudaTotalBs', label: 'totalSaldoDeudaBs' },
      { field: 'deudaTotalUsd', label: 'totalSaldoDeudaUsd' },
      { field: 'montoDeudaBs', label: 'saldoDeudaBs' },
      { field: 'deudaTotalUsd', label: 'saldoDeudaUsd' },
    ];

    fields.forEach(({ field, label }) => {
      this.totalValues[label] = this.calculateSum(field);
    });
    this.totalSaldoDeudaBs = this.totalValues['totalSaldoDeudaBs'];
    this.totalSaldoDeudaUsd = this.totalValues['totalSaldoDeudaUsd'];
    this.saldoDeudaBs = this.totalValues['saldoDeudaBs'];
    this.saldoDeudaUsd = this.totalValues['saldoDeudaUsd'];
    this.totalDeudaSeleccionadas =
      this.totalSaldoDeudaBs + this.saldoDeudaUsd * this.tipoCambio;
  }

  calculateSum(field: string): number {
    return Array.from(this.selectedRows).reduce(
      (sum, deuda) => sum + (deuda[field] ?? 0),
      0
    );
  }

  obtenerValoresEconomicos(): void {
    const solicitud: SolicitudValorEconomico = {
      fecha: Fecha.toLocalDate(this.fechaActual),
      oficinaId: this.oficinaId!,
    };

    this.parametricaValoresEconomicosService
      .obtenerValoresEconomicos(solicitud)
      .then((respuesta: RespuestaValorEconomico) => {
        if (respuesta.transaccion) {
          this.tipoCambio = respuesta.tipoCambio;
        } else {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        }
      })
      .catch(() => {
        this.toastr.info(MensajeConstante.MSG_ERROR);
      });
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  toggleAllRows(event: any): void {
    if (event.checked) {
      this.selection.select(...this.dataSource.data);
      this.selectedDeudas = this.dataSource.data;
    } else {
      this.selection.clear();
      this.selectedDeudas = [];
    }
    this.calculateTotal();
  }

  onRowSelect(row: any, event: any): void {
    this.selection.toggle(row);

    if (event.checked) {
      if (row) {
        this.selectedDeudas.push(row);
      }
    } else {
      const index = this.selectedDeudas.findIndex((item) => item.id === row.id);
      if (index !== -1) {
        this.selectedDeudas.splice(index, 1);
      }
    }

    this.calculateTotal();
  }

  contribuyenteBoolean: Boolean = false;

  getContribuyten(): void {
    this.contribuyenteSubscription =
      this.datosContribuyenteService.dataModel$.subscribe(
        (contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyenteBoolean = true;
            this.contribuyente = contribuyente;
            this.oficinaId = contribuyente.administracion;
            this.obtenerDeudas();
            this.obtenerValoresEconomicos();
          } else {
            this.contribuyenteBoolean = false;
            this.contribuyente = {};
            this.dataSource.data = [];
            this.dataSourceAll.data = [];
            this.tipoCambio = 0;
            this.totalSaldoDeudaBs = 0;
            this.totalSaldoDeudaUsd = 0;
            this.saldoDeudaBs = 0;
            this.totalDeudaSeleccionadas = 0;
            this.saldoDeudaUsd = 0;
          }
        }
      );
  }

  applyFilter(event: Event) {
    this.loading = true;
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    setTimeout(() => {
      this.loading = false;
    }, 200)
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  limpiarImpuestoFormulario(): void {
    this.formContribuyente.get('impuestoId')?.setValue([]);
    this.formContribuyente.get('formularioId')?.setValue([]);
  }

  limpiarProcesoId(): void {
    this.formContribuyente.get('procesoId')?.setValue([]);
  }
  limpiarDeudaId(): void {
    this.formContribuyente.get('deudaId')?.setValue('');
  }

  limpiarAnioMes(): void {
    this.formContribuyente.get('mesAnioDesde')?.setValue(null);
    this.formContribuyente.get('mesAnioHasta')?.setValue(null);
  }

  limpiarFiltroParaDeudaId() {
    this.limpiarImpuestoFormulario();
    this.limpiarProcesoId();
  }

  limpiarFiltroParaDeudaHistorico() {
    this.limpiarImpuestoFormulario();
    this.limpiarProcesoId();
  }

  limpiarFiltroParaImpuestoFormulario(): void {
    this.limpiarProcesoId();
    this.limpiarDeudaId();
  }

  limpiarFiltroParaAnioMes(): void {
    this.limpiarProcesoId();
    this.limpiarDeudaId();
    this.limpiarImpuestoFormulario();
  }

  limpiarFiltroParaProceso(): void {
    this.limpiarDeudaId();
    this.limpiarImpuestoFormulario();
  }


  setMesAnioDesde(
    normalizedMonthAndYear: Moment,
    datepicker: MatDatepicker<Moment>
  ) {
    const fecha = moment(normalizedMonthAndYear).date(1);
    this.dateDesde.setValue(fecha);
    this.limpiarDeudaMesAnioFormulario();
    datepicker.close();
  }


  setMesAnioHasta(
    normalizedMonthAndYear: Moment,
    datepicker: MatDatepicker<Moment>
  ) {
    const fecha = moment(normalizedMonthAndYear).date(1);
    this.dateHasta.setValue(fecha);
    datepicker.close();
  }

  setMesAnio(
    normalizedMonthAndYear: Moment,
    datepicker: MatDatepicker<Moment>
  ) {
    const fecha = moment(normalizedMonthAndYear).date(1);
    this.dateMesAnio.setValue(fecha);
    this.formContribuyente.get('mesAnio')?.setValue(fecha);
    datepicker.close();
  }

  ngOnDestroy(): void {
    if (this.contribuyenteSubscription) {
      this.contribuyenteSubscription.unsubscribe();
    }
  }

  selDos() {
    this.actualizaValidadorFormulario('impuestoId', true);
    this.actualizaValidadorFormulario('formularioId', true);
    this.actualizaValidadorFormulario('mesAnioDesde', true);
    this.actualizaValidadorFormulario('mesAnioHasta', true);
    this.actualizaValidadorFormulario('procesoId', false);
    this.actualizaValidadorFormulario('deudaId', false);
    this.actualizaValidadorFormulario('mesAnio', false);
    this.actualizaValidadorFormulario('formularioDdjjId', false);
  }

  selTres() {
    this.actualizaValidadorFormulario('mesAnioDesde', true);
    this.actualizaValidadorFormulario('mesAnioHasta', true);
    this.actualizaValidadorFormulario('procesoId', true);
    this.actualizaValidadorFormulario('impuestoId', false);
    this.actualizaValidadorFormulario('formularioId', false);
    this.actualizaValidadorFormulario('deudaId', false);
    this.actualizaValidadorFormulario('mesAnio', false);
    this.actualizaValidadorFormulario('formularioDdjjId', false);
  }

  selCuatro() {
    this.actualizaValidadorFormulario('deudaId', true);
    this.actualizaValidadorFormulario('mesAnioDesde', false);
    this.actualizaValidadorFormulario('mesAnioHasta', false);
    this.actualizaValidadorFormulario('procesoId', false);
    this.actualizaValidadorFormulario('impuestoId', false);
    this.actualizaValidadorFormulario('formularioId', false);
    this.actualizaValidadorFormulario('mesAnio', false);
    this.actualizaValidadorFormulario('formularioDdjjId', false);
  }

  selQuinto() {
    this.actualizaValidadorFormulario('deudaId', true);
    this.actualizaValidadorFormulario('mesAnioDesde', false);
    this.actualizaValidadorFormulario('mesAnioHasta', false);
    this.actualizaValidadorFormulario('procesoId', false);
    this.actualizaValidadorFormulario('impuestoId', false);
    this.actualizaValidadorFormulario('formularioId', false);
    this.actualizaValidadorFormulario('mesAnio', true);
    this.actualizaValidadorFormulario('formularioDdjjId', true);
  }

  actualizaValidadorFormulario(nombreItem: string, req: boolean) {
    this.formContribuyente.get(nombreItem)?.reset();
    if (req) {
      this.formContribuyente.get(nombreItem)?.enable();
    } else {
      this.formContribuyente.get(nombreItem)?.disable();
    }
    this.formContribuyente.get(nombreItem)?.updateValueAndValidity();
  }

  activarFiltros(): void {
    this.criterioBusquedaPorDefecto();
    this.obtenerDeudas();
  }

  buscarDeuda(nitCur: number, deudaId: number, oficinaId: number) {
    const solicitud: SolicitudActualizaDeudas = {
      nitCur: nitCur,
      oficinaId: oficinaId,
      origenId: 105,
      deudas: [
        { deudaId: deudaId }
      ]
    }
    this.mensageDeuda = "";
    this.reporteAdeudoService
      .obtenerActualizadasDeudas(solicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.dataSource.data = respuesta.objetosList ?? [];
            this.dataSource.data.map(function (dato) {
              dato.moneda =
                dato.monedaId == MonedaEnum.BOLIVIANOS_ID
                  ? MonedaEnum.BOLIVIANOS : dato.monedaId === MonedaEnum.DOLARES_ID
                    ? MonedaEnum.DOLARES : String(dato.monedaId);
              return dato;
            });
            this.tableLoading = false;
            this.dataSource.data = this.dataSource.data;
          } else {
            this.dataSource.data = [];
          }
        }
        if (this.dataSource.data.length === 0) this.mensageDeuda = `No se encontraron Deuda Vigente con el Identificar de deuda: ${this.formContribuyente.get('deudaId')?.value}`;
      })
      .catch(() => {
        this.toastr.error('Error al Obtener Deudas...');
        this.mensageDeuda = "Error al Obtener Deudas...";
      }).finally(() => {
        setTimeout(() => {
          this.loading = false;
        }, 200);
      });
  }
  buscarDeudaHistorico(nitCur: number, deudaId: number) {
    this.mensageDeuda = ""
    this.reporteAdeudoService
      .obtenerDeudasHitoricas(nitCur, deudaId)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.dataSource.data = respuesta.objetosList ?? [];
            this.dataSource.data.map(function (dato) {
              dato.moneda =
                dato.monedaId == MonedaEnum.BOLIVIANOS_ID
                  ? MonedaEnum.BOLIVIANOS : dato.monedaId === MonedaEnum.DOLARES_ID
                    ? MonedaEnum.DOLARES : String(dato.monedaId);
              return dato;
            });
          } else {
            this.dataSource.data = [];
            this.mensageDeuda = "No se encontró la Deuda"
          }
        } else {
          this.dataSource.data = [];
        }
      })
      .catch(() => {
        this.mensageDeuda = "Error en el servicio...";
        this.dataSource.data = [];
      })
      .finally(() => {
        this.tableLoading = false;
      });
  }

  buscarDeudaHistoricoPeriodoFormulario(pSolicitud: SolicitudDetalleDeuda) {
    this.mensageDeuda = ""
    let vSolicitud: SolicitudDetalleDeudaPeriodoFormulario = {
      formularioId: pSolicitud.formularioDdjjId,
      periodo: pSolicitud.mes,
      anio: pSolicitud.anio,
      nitCur: pSolicitud.nitCur,
      oficinaId: pSolicitud.oficinaId
    }
    this.reporteAdeudoService
      .obtenerDeudasHitoricasPeriodoFormulario(vSolicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.dataSource.data = respuesta.objetosList ?? [];
            this.dataSource.data.map(function (dato) {
              dato.moneda =
                dato.monedaId == MonedaEnum.BOLIVIANOS_ID
                  ? MonedaEnum.BOLIVIANOS : dato.monedaId === MonedaEnum.DOLARES_ID
                    ? MonedaEnum.DOLARES : String(dato.monedaId);
              return dato;
            });
          } else {
            this.dataSource.data = [];
            this.mensageDeuda = "No se encontró la Deuda correspondiente al Periodo, Año y Formulario"
          }
        } else {
          this.dataSource.data = [];
          this.mensageDeuda = "No se encontró la Deuda correspondiente al Periodo, Año y Formulario"
        }
      })
      .catch(() => {
        this.mensageDeuda = "Error en el servicio...";
        this.dataSource.data = [];
      })
      .finally(() => {
        this.tableLoading = false;
      });
  }

  clearFilterFormulario(event: MouseEvent) {
    event.stopPropagation();
    this.formContribuyente.get('formularioDdjjId')?.reset();
    this.limpiarMesAnioFormulario();
  }

  clearFilterDeudaId() {
    this.limpiarDeudaId();
  }
  clearFilterMesAnio() {
    this.dateMesAnio.setValue(null);
    this.formContribuyente.get('mesAnio')?.setValue(null);
  }

  limpiarDeudaMesAnioFormulario() {
    this.formContribuyente.get('deudaId')?.reset();
    this.formContribuyente.get('deudaId')?.disable();
  }

  limpiarMesAnioFormulario() {
    this.formContribuyente.get('deudaId')?.reset();
    this.formContribuyente.get('deudaId')?.enable();

    this.formContribuyente.get('mesAnio')?.disable();
    this.formContribuyente.get('formularioDdjjId')?.disable();
  }

  limpiarMesAnioFormulario2() {
    if (this.formContribuyente.get('deudaId')?.value) {
      this.formContribuyente.get('mesAnio')?.disable();
      this.formContribuyente.get('formularioDdjjId')?.disable();
    } else {
      this.formContribuyente.get('mesAnio')?.enable();
      this.formContribuyente.get('formularioDdjjId')?.enable();
    }
  }

  limpiarMesAnioFormularioParaDeudaId() {
    this.formContribuyente.get('deudaId')?.reset();
    this.formContribuyente.get('deudaId')?.enable();

    this.formContribuyente.get('mesAnio')?.reset();
    this.formContribuyente.get('formularioDdjjId')?.reset();
    this.formContribuyente.get('mesAnio')?.enable();
    this.formContribuyente.get('formularioDdjjId')?.enable();
  }
}
