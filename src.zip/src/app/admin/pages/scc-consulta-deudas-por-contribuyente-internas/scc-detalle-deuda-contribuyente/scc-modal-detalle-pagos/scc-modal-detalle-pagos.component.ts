import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, Inject, LOCALE_ID, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MaterialModule, RespuestaLista } from 'core-lib';
import { EstadoPagoIdEnum, MonedaEnum } from '../../../../../enums/general.enum';
import { DeudaContribuyenteModel } from '../../../../../models/reporte-adeudo-tributario/deuda-contribuyente.model';
import { DeudaPagoTableModel } from '../../../../../models/reporte-adeudo-tributario/deuda-pago.model';
import { NumberFormatPipe } from '../../../../../pipes/number-format.pipe';
import { OtrDetalleDeudasService } from '../../../../../services/registro-deudas-manuales/otr-detalle-deudas.service';
import { PasarDatosDialog } from '../../../../../shared/utils/pasar-datos-dialog';

@Component({
  selector: 'scc-modal-detalle-pagos',
  standalone: true,
  imports: [
    MaterialModule,
    ReactiveFormsModule,
    CommonModule,
    MatNativeDateModule,
    FormsModule,
  ],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './scc-modal-detalle-pagos.component.html',
  styleUrl: './scc-modal-detalle-pagos.component.scss',
})
export class SccModalDetallePagosComponent implements OnInit, AfterViewInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  tablaColumnas: Array<string>;
  formPagos: FormGroup;
  listaPagos;
  tableLoading: boolean;
  constructor(
    private otrDetalleDeudasService: OtrDetalleDeudasService,
    private numberFormatPipe: NumberFormatPipe,
    public dialogRef: MatDialogRef<SccModalDetallePagosComponent>,
    private formBuilder: FormBuilder,
    @Inject(MAT_DIALOG_DATA)
    public data: PasarDatosDialog<DeudaContribuyenteModel>
  ) {
    this.listaPagos = new MatTableDataSource<DeudaPagoTableModel>([]);
    this.tablaColumnas = [
      'fechaRegistro',
      'tipoPago',
      'modenaDescripcion',
      'montoPago',
      'deudaTotalUfv',
      // 'pagoDeudaBs',
      'detalles',
      'transaccionBancaria',
      'pagoExceso',
      'estadoPago',
    ];

    this.tableLoading = false;
    this.formPagos = this.formBuilder.group({});
  }

  ngOnInit(): void {
    this.crearFormulario();
    this.obtenerDetallePagos();
  }

  ngAfterViewInit() {
    this.listaPagos.paginator = this.paginator;
  }

  crearFormulario() {
    this.formPagos = this.formBuilder.group({
      deudaId: [this.data.datos.deudaId],
    });

    this.formPagos.controls['deudaId'].disable();
  }
  obtenerDetallePagos() {
    this.tableLoading = true;
    var vDeudaId: number = this.data.datos.deudaId || 0;
    var vNitCur: number = this.data.datos.nitCur || 0;
    const vSolicitud: any = {
      nitCur: vNitCur,
      tipoContribuyentePdrId: 0,
      deudaId: vDeudaId,
    };
    this.otrDetalleDeudasService
      .obtenerDetallePagos(vSolicitud)
      .then((respuesta: RespuestaLista<DeudaPagoTableModel>) => {
        this.listaPagos.data = respuesta.objetosList ?? [];
        if (this.listaPagos.data.length > 0) {
          this.listaPagos.data.forEach((pago: DeudaPagoTableModel) => {
            let pagoDetalle = pago.pagoDetalle
              ? JSON.parse(pago.pagoDetalle)
              : null;

            if (pagoDetalle) {
              let interesFormateado = this.numberFormatPipe.transform(
                pagoDetalle.pagoInteresBs
              );
              let mantenimientoFormateado = this.numberFormatPipe.transform(
                pagoDetalle.pagoMantenimientoValorBs
              );
              let totalFormateado = this.numberFormatPipe.transform(
                pagoDetalle.pagoDeudaBs
              );

              let detalles = `I: ${interesFormateado}; MV: ${mantenimientoFormateado}; TO: ${totalFormateado}`;

              pago.detalles = detalles;
              pago.pagoExceso = pagoDetalle.montoPagoExceso;
              pago.pagoDeudaBs = pagoDetalle.pagoDeudaBs;

              pago.modenaDescripcion =
                pago.monedaId == MonedaEnum.BOLIVIANOS_ID
                  ? 'BOLIVIANO'
                  : pago.monedaId == MonedaEnum.DOLARES_ID
                    ? 'DOLAR'
                    : '';

              pago.estadoPago =
                pago.estadoPagoId == EstadoPagoIdEnum.VIGENTE
                  ? 'VIGENTE'
                  : pago.estadoPagoId == EstadoPagoIdEnum.VIGENTE_HISTORICO
                    ? 'VIGENTE'
                    : (pago.estadoPagoId == EstadoPagoIdEnum.REVERTIDO ?
                      'REVERTIDO' : ''
                    );
            }
          });
        }
      })
      .finally(() => {
        this.tableLoading = false;
      });
  }
}
