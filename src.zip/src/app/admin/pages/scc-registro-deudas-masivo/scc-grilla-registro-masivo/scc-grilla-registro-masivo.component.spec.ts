import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SccGrillaRegistroMasivoComponent } from './scc-grilla-registro-masivo.component';

describe('SccGrillaRegistroMasivoComponent', () => {
  let component: SccGrillaRegistroMasivoComponent;
  let fixture: ComponentFixture<SccGrillaRegistroMasivoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SccGrillaRegistroMasivoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SccGrillaRegistroMasivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
