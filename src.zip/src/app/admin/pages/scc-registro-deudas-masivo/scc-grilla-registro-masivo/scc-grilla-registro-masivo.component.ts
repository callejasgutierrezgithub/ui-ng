import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MaterialModule, RespuestaObjeto, SiatToastrService, TableComponent, UploadComponent } from 'core-lib';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';


import * as XLSX from 'xlsx';
import { ParProcesoEnum } from '../../../../enums/par-proceso.enum';
import { SolicitudXlsxDeudaBs, SolicitudDeudaBs } from '../../../../models/documentos-agrupadores/solicitud-deudas-bs.model';
import { FormularioModel, RespuestaFormulario } from '../../../../models/impuesto-asociado/formulario.model';
import { ImpuestoModel, RespuestaImpuestos } from '../../../../models/impuesto-asociado/impuesto.model';
import { ParametricaGenericaModel } from '../../../../models/parametrica/parametrica-generica.model';
import { ParametricaValoresEconomicosService } from '../../../../services/parametricas/parametrica-valores-economicos.service';
import { ParametricaService } from '../../../../services/parametricas/parametrica.service';
import { DocumentosAgrupadoresService } from '../../../../services/registro-deudas-manuales/documentos-agrupadores.service';
import { OtrDetalleDeudasService } from '../../../../services/registro-deudas-manuales/otr-detalle-deudas.service';
import { SccDatePickerYearComponent } from '../../../../shared/components/scc-datepicker-year/scc-datepicker-year.component';
import { SelectFilterComponent } from '../../../../shared/components/select-filter/select-filter.component';
import { Fecha } from '../../../../shared/utils/fecha';
import { validarCampoFormulario } from '../../../../shared/utils/validad-formulario/validar-campos';
import { SolicitudDeudaUfv, SolicitudXlsxDeudaUfv } from '../../../../models/documentos-agrupadores/solicitud-deudas-ufv.model';
import { DeudaMasivaModel, RespuestaDeudaGenerica } from '../../../../models/documentos-agrupadores/respuesta-deuda-generica.model';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { SolicitudValidarFecha, SolicitudValidarFechas, SolicitudValidarNitCur } from '../../../../models/documentos-agrupadores/solicitud-validar-fechas-model';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { ExcelService } from '../../../../services/sub-cuenta-valores/excel.service';

@Component({
  selector: 'scc-grilla-registro-masivo',
  standalone: true,
  imports: [
      MaterialModule,
      CommonModule,
      ReactiveFormsModule,
      FormsModule,
      MatNativeDateModule,
      SelectFilterComponent,
      NgxSpinnerModule,
      SccDatePickerYearComponent,
      UploadComponent,    
      MatCardModule,
      MatTableModule,
      MatPaginatorModule,
      TableComponent,],
  templateUrl: './scc-grilla-registro-masivo.component.html',
  styleUrl: './scc-grilla-registro-masivo.component.scss'
})
export class SccGrillaRegistroMasivoComponent implements OnInit, AfterViewInit, OnDestroy {
    tablaMostrar: boolean = false;
    fechasValidator: SolicitudValidarFecha[] = [];
    files: File[] = [];
    formGenerarDeudaMasivo!: FormGroup;
    formTablaDeudaMasivo!: FormGroup;
    tipoProceso = [];
    tipoFormulario : FormularioModel[];
    procesosFiltrado: ParametricaGenericaModel[];
    tipoImpuesto: ImpuestoModel[];
    tipoProcesoMasivo: ParametricaGenericaModel[] = [];
    formulariosFiltrado = [];
    deudasMasivas: DeudaMasivaModel[] = [];
    deudaMasiva: DeudaMasivaModel = {
      numero: 0,
      nitCur: 0,
      deudaId: 0,
      numeroOrdenDocumento: 0,
      formularioId: 0,
      periodo: 0,
      anio: 0,
      oficinaId: 0,
      montoUfv:0,
      montoBs:0,
    };
    searchText: string = '';
    btnLoading: boolean;
  constructor(
      private dialog: MatDialog,
      private formBuilder: FormBuilder,
      private toastr: SiatToastrService,
      private spinnerService: NgxSpinnerService,
      private otrService: OtrDetalleDeudasService,
      private parametricaService: ParametricaService,
      private ddjjService: ParametricaValoresEconomicosService,
      private _generarDeudaService: DocumentosAgrupadoresService,
      private excelService: ExcelService,
    ) {
      this.formGenerarDeudaMasivo = new FormGroup({});
      this.formTablaDeudaMasivo = new FormGroup({});
      this.tipoProceso = [];
      this.procesosFiltrado = [];
      this.btnLoading = false;
      this.tipoFormulario = [];
      this.formulariosFiltrado = [];
      this.tipoImpuesto = [];      
    }
    displayedColumns = [
      "numero",
      "nitCur",
      "deudaId",
      "numeroOrdenDocumento",
      "formularioId",
      "periodo",
      "anio",
      "oficinaId",
      "montoUfv",
      "montoBs"
      // "action",
    ];
    dataSource = new MatTableDataSource<DeudaMasivaModel>();

  ngOnDestroy(): void {
    throw new Error('Method not implemented.');
  }
  ngOnInit() {
    this.obtenerParametricaTipoProcesoMasivo();
    this.crearFormulario();
    this.armarTabla();
    this.ngAfterViewInit();
    this.actualizarVistaTable();
  }
  crearFormulario() {
    this.formGenerarDeudaMasivo = this.formBuilder.group({
      procesoMasivoId: [null, [Validators.required]]
    });

  }
  solicitudMasivoDeudasBs: SolicitudXlsxDeudaBs[]=[];
  solicitudMasivoDeudasUfv: SolicitudXlsxDeudaUfv[]=[];
  solicitudMasivoBs: SolicitudDeudaBs[]=[];
  solicitudMasivoUfv: SolicitudDeudaUfv[]=[];
  

  onFileChange(event: any): void {
    const datosForm = this.formGenerarDeudaMasivo.value;
    const procesoForm = datosForm.procesoMasivoId;
    const file = event.target.files[0];
    if (!file) return;
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheet = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheet];
      // Convierte a JSON con cabeceras
      const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
      // console.log("dataaa",jsonData )
      if (procesoForm === ParProcesoEnum.CONTROL_DE_CREDITOS){
          // Mapea a objeto deudaBs
          this.solicitudMasivoDeudasBs = jsonData.map((row: any) => ({
            procesoId: Number(row['proceso_id']),
            nitCur: Number(row['nit_cur']),
            documentoId: Number(row['documento_id']),
            documentoAgrupadorId: Number(row['documento_agrupador_id']) || 0,
            fechaVencimiento: row['fecha_vencimiento'],
            fechaNotificacion: row['fecha_notificacion'] || '',
            numeroOrdenDocumento: Number(row['numero_orden_documento']),
            numeroOrdenDocumentoAgrupador: Number(row['numero_orden_documento_agrupador']) || 0,
            formularioId: Number(row['formulario_id']),
            impuestoId: Number(row['impuesto_id']),
            oficinaId: Number(row['administracion']),
            periodo: Number(row['periodo']),
            anio: Number(row['anio']),
            tributoOmitido: Number(row['monto_deuda_bs']) || 0,      
            impuesto: row['impuesto_descripcion'],
            formulario: row['formulario_descripcion'],
            // contravencionId: Number(row['contravencion_id']),
            multaUfv: Number(row['monto_deuda_ufv']),
            
            asientoId: Number(row['asientoId']) || 39,//asiento para Bs
            tipoContribuyenteId: Number(row['contravencion_id']),
            
            tramiteId: Number(row['tramiteId']) || 0,
            origenId: Number(row['origenId']) || 377,
            sancionPorcentaje: Number(row['sancionPorcentaje']) || 0,
            agravantePorcentaje: Number(row['agravantePorcentaje']) || 0,
            tipoContribuyentePdrId: Number(row['tipoContribuyentePdrId']) || 0,
            monedaId: Number(row['edmonedaIdad']) || 688,
            moneda: row['nombre'] || 'BOLIVIANO'

          }));
      }else
         if(procesoForm === ParProcesoEnum.FACTURACION || procesoForm === ParProcesoEnum.PROCESO_MULTA_INCUMPLIMIENTO_DEBER_FORMAL ){
          // Mapea a objeto deudaBs
        this.solicitudMasivoDeudasUfv = jsonData.map((row: any) => ({
          procesoId: Number(row['proceso_id']),
          nitCur: Number(row['nit_cur']),
          documentoId: Number(row['documento_id']),
          documentoAgrupadorId: Number(row['documento_agrupador_id']),
          fechaVencimiento: row['fecha_vencimiento'],
          fechaNotificacion: row['fecha_notificacion'] || '',
          numeroOrdenDocumento: Number(row['numero_orden_documento']),
          numeroOrdenDocumentoAgrupador: Number(row['numero_orden_documento_agrupador']),
          formularioId: Number(row['formulario_id']),
          impuestoId: Number(row['impuesto_id']),
          oficinaId: Number(row['administracion']),
          periodo: Number(row['periodo']),
          anio: Number(row['anio']),
          tributoOmitido: Number(row['monto_deuda_bs']) || 0,      
          impuesto: row['impuesto_descripcion'],
          formulario: row['formulario_descripcion'],
          contravencionId: Number(row['contravencion_id']),
          multaUfv: Number(row['monto_deuda_ufv']),
          
          asientoId: Number(row['asientoId']) || 109,//Multa Incumplimiento
          tipoContribuyenteId: Number(row['contravencion_id']),//no sabemos
          
          tramiteId: Number(row['tramiteId']) || 0,
          origenId: Number(row['origenId']) || 377,
          sancionPorcentaje: Number(row['sancionPorcentaje']) || 0,
          agravantePorcentaje: Number(row['agravantePorcentaje']) || 0,
          tipoContribuyentePdrId: Number(row['tipoContribuyentePdrId']) || 0,
          monedaId: Number(row['edmonedaIdad']) || 688,
          moneda: row['nombre'] || 'BOLIVIANO'
        }));
      }else{
        this.toastr.info(
          MensajeConstante.ERROR_NO_EXISTE_CAUSISTICA_PARA_PARAMETRICA
        ); 
      }
      // console.log("solicitudMasivoDeudasUfv", this.solicitudMasivoDeudasUfv)
      console.log("solicitudMasivoDeudasBs", this.solicitudMasivoDeudasBs)
    
    };
    reader.readAsArrayBuffer(file);
  }


  async validarListaSolicitud(): Promise<void>{
    const datosForm = this.formGenerarDeudaMasivo.value;
    const procesoForm = datosForm.procesoMasivoId;

    if (procesoForm === ParProcesoEnum.CONTROL_DE_CREDITOS){
      let numero: number = 0;
      Object.entries(this.solicitudMasivoDeudasBs).forEach(([key, solicitud]) => {
        // console.log("solicitud", solicitud)
        if (!(solicitud.procesoId === procesoForm && solicitud.documentoId === 216 && solicitud.documentoAgrupadorId === 216)) {
          this.toastr.info(
            MensajeConstante.ERROR_XLSX_P_D_DA
          );        
          throw new Error(`El error ${key} no tiene un valor válido`);
        }
      });

      this. validarXlsBs();

      this.solicitudMasivoBs = this.solicitudMasivoDeudasBs.map(obj => ({
          ...obj,
          fechaVencimiento: obj.fechaVencimiento
          ? Fecha.stringToLocalDate(obj.fechaVencimiento, "YMD")
          : null,
        fechaNotificacion: obj.fechaNotificacion
          ? Fecha.stringToLocalDate(obj.fechaNotificacion, "YMD")
          : null
        })  
      );
      const listaFechas = Object.values(this.solicitudMasivoBs).map(solicitud => ({
        fecha: solicitud.fechaVencimiento,
        administracionId: solicitud.oficinaId
      }));
      const nitCurs = Object.values(this.solicitudMasivoBs).map(solicitud => solicitud.nitCur);

      const respuestaFechasValidas =  await this.validarFechas(listaFechas);
      const respuestaNitCurValidas =  await this.validarNitCur(nitCurs);
      console.log("respuesta nit", respuestaNitCurValidas);
      if(!respuestaFechasValidas.objeto || !respuestaNitCurValidas.objeto){
        this.mensajeValidatorNitFecha(respuestaNitCurValidas, respuestaFechasValidas)
      }else{
      Object.entries(this.solicitudMasivoBs).forEach(([key, solicitud]) => {          
      this._generarDeudaService
        .registrarDeudaGenericaBsUsd(solicitud)
        .then((respuesta: RespuestaDeudaGenerica) => {
          if (respuesta.transaccion) {
            this.btnLoading = false;
            numero= numero+1;
                this.deudaMasiva = {
                  numero : numero,
                  nitCur : solicitud.nitCur,
                  deudaId :respuesta.numeroDeuda,
                  numeroOrdenDocumento: solicitud.numeroOrdenDocumento,
                  formularioId: solicitud.formularioId,
                  periodo: solicitud.periodo,
                  anio: solicitud.anio,
                  oficinaId: solicitud.oficinaId,
                  montoBs:solicitud.tributoOmitido,
                  montoUfv:0
                }
                this.deudasMasivas.push(this.deudaMasiva);
                setTimeout(() => (this.dataSource.paginator = this.paginator));
          } else {
            this.btnLoading = false;
            this.toastr.info(
              respuesta.mensajes
                ? respuesta.mensajes[0].descripcion
                : MensajeConstante.MSG_ERROR
            );
          }
        })
        .catch(() => {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        });
        this.btnLoading = false;
        this.dataSource = new MatTableDataSource<DeudaMasivaModel>(this.deudasMasivas);
        setTimeout(() => (this.dataSource.paginator = this.paginator));
        this.armarTabla();

        this.tablaMostrar=true;
      });
    }
      
    }

    if (procesoForm === ParProcesoEnum.PROCESO_MULTA_INCUMPLIMIENTO_DEBER_FORMAL){
      let numero: number = 0;
      const encontrado = Object.entries(this.solicitudMasivoDeudasUfv).find(([key, solicitud]) => {
        return (solicitud.procesoId === procesoForm && 
                ( (solicitud.documentoId === 6079 && solicitud.documentoAgrupadorId === 6079) 
                  || (solicitud.documentoId === 216 && solicitud.documentoAgrupadorId === 216)
                ));
      });

      let generinca = 0;

      if(encontrado) {
        const [key, solicitud] = encontrado;
        if(solicitud.documentoId === 6079 && solicitud.documentoAgrupadorId === 6079) {
          generinca = 1;
        } else if(solicitud.documentoId === 216 && solicitud.documentoAgrupadorId === 216) {
          generinca = 2;
        }else{
          this.toastr.info(
            MensajeConstante.ERROR_NO_EXISTE_PARAMETRICA
          );        
        }
      }  

      Object.entries(this.solicitudMasivoDeudasUfv).forEach(([key, solicitud]) => {
        // console.log("generinca objeto", generinca);
          if (!((solicitud.procesoId === procesoForm && solicitud.documentoId === 6079 && solicitud.documentoAgrupadorId === 6079 && generinca === 1)
              || (solicitud.procesoId === procesoForm && solicitud.documentoId === 216 && solicitud.documentoAgrupadorId === 216 && generinca === 2)
            )) {
              this.toastr.info(
                MensajeConstante.ERROR_XLSX_P_D_DA
              );        
              throw new Error(`El error ${key} no tiene un valor válido`);
            }
          }); 
          this. validarXlsUfv();

          this.solicitudMasivoUfv = this.solicitudMasivoDeudasUfv.map(obj => ({
              ...obj,
              fechaVencimiento: obj.fechaVencimiento
              ? Fecha.stringToLocalDate(obj.fechaVencimiento, "YMD")
              : null,
            fechaNotificacion: obj.fechaNotificacion
              ? Fecha.stringToLocalDate(obj.fechaNotificacion, "YMD")
              : null
            })    
          );

          const listaFechas = Object.values(this.solicitudMasivoUfv).map(solicitud => ({
            fecha: solicitud.fechaVencimiento,
            administracionId: solicitud.oficinaId
          }));
          const nitCurs = Object.values(this.solicitudMasivoUfv).map(solicitud => solicitud.nitCur);

          const respuestaFechasValidas =  await this.validarFechas(listaFechas);
          const respuestaNitCurValidas =  await this.validarNitCur(nitCurs);
          if(!respuestaFechasValidas.objeto || !respuestaNitCurValidas.objeto){
            this.mensajeValidatorNitFecha(respuestaNitCurValidas, respuestaFechasValidas)
          }else{
          Object.entries(this.solicitudMasivoUfv).forEach(([key, solicitud]) => {          
          this._generarDeudaService
            .registrarDeudaGenericaUfv(solicitud)
            .then((respuesta: RespuestaDeudaGenerica) => {
              if (respuesta.transaccion) {
                this.btnLoading = false;
                numero= numero+1;
                this.deudaMasiva = {
                  numero : numero,
                  nitCur : solicitud.nitCur,
                  deudaId :respuesta.numeroDeuda,
                  numeroOrdenDocumento: solicitud.numeroOrdenDocumento,
                  formularioId: solicitud.formularioId,
                  periodo: solicitud.periodo,
                  anio: solicitud.anio,
                  oficinaId: solicitud.oficinaId,
                  montoUfv: solicitud.multaUfv,
                  montoBs:0
                }
                this.deudasMasivas.push(this.deudaMasiva);
                setTimeout(() => (this.dataSource.paginator = this.paginator));
              } else {
                this.btnLoading = false;
                this.toastr.info(
                  respuesta.mensajes
                    ? respuesta.mensajes[0].descripcion
                    : MensajeConstante.MSG_ERROR
                );
              }
            })
            .catch(() => {
              this.toastr.info(MensajeConstante.MSG_ERROR);
            });
          this.btnLoading = false;
          });
        }
        this.dataSource = new MatTableDataSource<DeudaMasivaModel>(this.deudasMasivas);
        setTimeout(() => (this.dataSource.paginator = this.paginator));
        this.armarTabla();

        this.tablaMostrar=true;
    }
  }

  obtenerImpuestos() {
    this.ddjjService
      .obtenerImpuestos()
      .then((respuesta: RespuestaImpuestos) => {
        this.tipoImpuesto = respuesta.objetosList;
        // console.log("tipoImpuesto   inicio...", this.tipoImpuesto);
      });
  }

  obtenerDetalleImpuesto(impuesto:number):string{
    // console.log("impuesto...", impuesto);
    const resultado = this.tipoImpuesto.find(item => item.id === impuesto);
      if (!resultado) {
      console.warn('Impuesto no encontrado:', impuesto);
      return 'Impuesto desconocido';
    }
  
    return resultado.descripcion!;
  }

  obtenerParametricaTipoProcesoMasivo() {
    this.parametricaService.dataModel$.subscribe((parametrica: any) => {
      this.tipoProcesoMasivo = parametrica.proceso_id ?? [];

      this.tipoProcesoMasivo = this.tipoProcesoMasivo.filter((item: any) => {
              if (
                item.id == ParProcesoEnum.CONTROL_DE_CREDITOS ||
                item.id == ParProcesoEnum.PROCESO_MULTA_INCUMPLIMIENTO_DEBER_FORMAL
              ) {
                return item;
              }
            });
      this.procesosFiltrado = this.tipoProcesoMasivo.slice();      
      if (this.tipoProcesoMasivo.length === 0) {
        // this.toastr.info('No se encontraron valores parametricos para proceso');
      }
    });
  }

  validarCampo(campo: string, label: string, maxlength?: number) {
    return new validarCampoFormulario().validarCampo(
      this.formGenerarDeudaMasivo,
      campo,
      label,
      maxlength
    );
  }
  
  validarXlsBs():void{
    Object.entries(this.solicitudMasivoDeudasBs).forEach(([key, solicitud]) => {
      if (!solicitud.nitCur 
        || !solicitud.procesoId  
        || !solicitud.documentoId  
        // || !solicitud.documentoAgrupadorId 
        || !solicitud.fechaVencimiento 
        || !solicitud.numeroOrdenDocumento 
        // || !solicitud.numeroOrdenDocumentoAgrupador 
        || !solicitud.formularioId 
        || !solicitud.impuestoId 
        || !solicitud.periodo 
        || !solicitud.anio 
        || !solicitud.oficinaId
        || !solicitud.tributoOmitido
      ) {
        this.toastr.info(
          MensajeConstante.ERROR_XLSX_VALIDACION
        );  
        // throw new Error(`El error ${key} no tiene un valor válido en la lista`);
      }
    });
  } 
  
  validarXlsUfv():void{
    Object.entries(this.solicitudMasivoDeudasUfv).forEach(([key, solicitud]) => {
      if (!solicitud.nitCur 
        || !solicitud.procesoId  
        || !solicitud.documentoId  
        || !solicitud.documentoAgrupadorId 
        || !solicitud.fechaVencimiento 
        || !solicitud.numeroOrdenDocumento 
        || !solicitud.numeroOrdenDocumentoAgrupador 
        || !solicitud.formularioId 
        || !solicitud.impuestoId 
        || !solicitud.periodo 
        || !solicitud.anio 
        || !solicitud.oficinaId
        || !solicitud.contravencionId
        || !solicitud.multaUfv
      ) {
        this.toastr.info(
          MensajeConstante.ERROR_XLSX_VALIDACION
        );  
        // console.log("lo que no cumple de los recuadros", key)
        throw new Error(`El error ${key} no tiene un valor válido en la lista`);
      }
    });
  } 

  async validarFechas(fechas: SolicitudValidarFecha[]):Promise<RespuestaObjeto<boolean>>{
      const solicitud: SolicitudValidarFechas = {
        fechas:fechas
      }
      return await this.otrService
      .validarFechas(solicitud)
  }
  async validarNitCur(nitCurs: number[]):Promise<RespuestaObjeto<boolean>>{
    console.log("ingreso a validar el nit", nitCurs)
        const solicitud: SolicitudValidarNitCur = {
          nitCurs:nitCurs
        }
        console.log("solicitud magi..", solicitud)
        return await this.otrService
        .validarNitCurs(solicitud)
    }


  @ViewChild(MatPaginator) paginator!: MatPaginator;

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  actionView(element: DeudaMasivaModel): void {
    console.log(element);
  }

  actionEdit(element: DeudaMasivaModel): void {
    console.log(element);
  }

  actionDelete(element: DeudaMasivaModel): void {
    console.log(element);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  armarTabla(){
    this.dataSource = new MatTableDataSource<DeudaMasivaModel>(this.deudasMasivas);
    setTimeout(() => (this.dataSource.paginator = this.paginator));
    this.crearFormulario();
  }

  actualizarVistaTable() {
    this.dataSource = new MatTableDataSource<DeudaMasivaModel>(this.deudasMasivas);
    setTimeout(() => (this.dataSource.paginator = this.paginator));
  }

  onSelectionChange(valor: any) {
    const datosForm = this.formGenerarDeudaMasivo.value;
    const procesoForm = datosForm.procesoMasivoId;
    if(!(procesoForm === ParProcesoEnum.PROCESO_MULTA_INCUMPLIMIENTO_DEBER_FORMAL || procesoForm === ParProcesoEnum.CONTROL_DE_CREDITOS)){
      this.toastr.info('No causisticas para proceso seleccionado');
    }
  }
  excelDeudasMasivas() {
      this.excelService.generarExcel(this.deudasMasivas, 'Deudas Masivas');
  }
  mensajeValidatorNitFecha(nitValidate: RespuestaObjeto<boolean>, fehcaValidate: RespuestaObjeto<boolean>){
    if(!nitValidate.objeto){
        this.toastr.info(MensajeConstante.ERROR_NIT_CUR, 
          nitValidate.mensajes
                  ? nitValidate.mensajes[0].descripcion
                  : MensajeConstante.ERROR_NIT_CUR
              );
    }else{
      this.toastr.info(
        fehcaValidate.mensajes
                  ? fehcaValidate.mensajes[0].descripcion
                  : MensajeConstante.ERROR_FECHA
              );  
    }                 

  }
}
