import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, RespuestaObjeto, TitlePageComponent, UserInfoService } from 'core-lib';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { SccGrillaRegistroMasivoComponent } from './scc-grilla-registro-masivo/scc-grilla-registro-masivo.component';
import { ParametricaGenericaModel, ParametroModel } from '../../../models/parametrica/parametrica-generica.model';
import { ParametricaService } from '../../../services/parametricas/parametrica.service';
import { ParametricasEnum } from '../../../enums/parametricas.enum';
import { Subscription } from 'rxjs';

@Component({
  selector: 'scc-registro-deudas-masivo',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    InformacionContribuyenteComponent,
    SccGrillaRegistroMasivoComponent],
  templateUrl: './scc-registro-deudas-masivo.component.html',
  styleUrl: './scc-registro-deudas-masivo.component.scss'
})
export class SccRegistroDeudasMasivoComponent implements OnDestroy {
  tipoUsuarioId: number = 0;
  esContribuyente: Boolean = true
  existeContribuyente: boolean;
  private parametricaSubscription?: Subscription;
  tipoProceso: ParametricaGenericaModel[];
  private settings = inject(CoreService);
  optionsThema = this.settings.getOptions();
  options = this.settings.getOptions();
  mensajeNit: string = '';
  consultaNit: Boolean = false;
  contribuyente: ContribuyenteModel = {};
  private userInfoSubscription: Subscription | undefined;
  
  constructor(
     private _userInfo: UserInfoService,
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
    private parametricaService: ParametricaService,
  ) { this.obtenerConsultaNit(); this.tipoProceso = [];
    this.existeContribuyente = false;
   }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }
  ngOnInit() {
    // this.obtenerDatosSesion();
    if (this.userInfoSubscription) {
      this.userInfoSubscription.unsubscribe();
    }
        this.obtenerParametricas();  
    }
  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$
        .subscribe((contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyente = contribuyente;
          } else {
            this.contribuyente = {}
          }
        });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }
  obtenerParametricas() {
      // this.formGenerarDeuda.get('gerenciaId')?.setValue(this.tipoGerencia[0]);
      const parametros: ParametroModel = {
        parametricas: {
          parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.documento_id}`
        },
      };

      this.parametricaService.obtenerParametricas(parametros).then(() => {
        this.parametricaSubscription =
          this.parametricaService.dataModel$.subscribe((parametrica: any) => {
            this.tipoProceso = parametrica.proceso_id ?? [];
          });
      });
    }

      buscarContribuyente(nitCur: number): void {
        this.existeContribuyente = false;
    
        this._datosContribuyente
          .obtenerContribuyente(nitCur)
          .then((respuesta: RespuestaObjeto<ContribuyenteModel>) => {
            if (respuesta.transaccion && respuesta.objeto != null) {
              this.contribuyente = respuesta.objeto;
              this.existeContribuyente = true;
            }
          })
          .catch((err) => {
            this.existeContribuyente = false;
          })
      }
      obtenerDatosSesion(): void {
        this.userInfoSubscription = this._userInfo.contextInfo$.subscribe(
          (response) => {
            this.buscarContribuyente(response.userInfo.nitCur);
            this.tipoUsuarioId = response.userInfo.tipoUsuarioId;
          }
        );
      }
}
