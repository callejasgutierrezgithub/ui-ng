import { CommonModule } from '@angular/common';
import { Component, effect, inject } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { SccGrillaExtractoTributarioComponent } from '../../../shared/components/scc-grilla-extracto-tributario/scc-grilla-extracto-tributario.component';

@Component({
  selector: 'app-extracto-tributario',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    SccGrillaExtractoTributarioComponent,
    InformacionContribuyenteComponent],
  templateUrl: './extracto-tributario.component.html',
  styleUrl: './extracto-tributario.component.scss'
})
export class ExtractoTributarioComponent {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  mensajeNit: string = '';
  consultaNit: Boolean = false;
  contribuyente: ContribuyenteModel = {};
  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) {
    this.obtenerConsultaNit();
  }

  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$
        .subscribe((contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyente = contribuyente;
          } else {
            this.contribuyente = {}
          }
        });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }
}
