import { CommonModule } from '@angular/common';
import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTableDataSource } from '@angular/material/table';
import {
  CoreService,
  MaterialModule,
  RespuestaObjeto,
  TitlePageComponent,
  UserInfoService,
} from 'core-lib';
import { ValoresSaldosModel } from '../../../models/consulta-valores/valores-saldos.model';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';

import { Subject, Subscription } from 'rxjs';
import { InfoContribuyenteComponent } from '../../../shared/components/info-contribuyente/info-contribuyente.component';
import { BolsasComponent } from './bolsas/bolsas.component';
import { DeudasComponent } from './deudas/deudas.component';
import { SccDetalleDeudaContribuyenteComponent } from '../scc-consulta-deudas-por-contribuyente-internas/scc-detalle-deuda-contribuyente/scc-detalle-deuda-contribuyente.component';
import { ParametroModel } from '../../../models/parametrica/parametrica-generica.model';
import { ParametricasEnum } from '../../../enums/parametricas.enum';
import { ParametricaService } from '../../../services/parametricas/parametrica.service';

@Component({
  selector: 'estado-cuenta-contribuyente',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    BolsasComponent,
    InfoContribuyenteComponent,
    DeudasComponent,
    SccDetalleDeudaContribuyenteComponent
  ],
  templateUrl: './estado-cuenta-contribuyente.component.html',
  styleUrl: './estado-cuenta-contribuyente.component.scss',
})
export class EstadoCuentaContribuyenteComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  private destroy$ = new Subject<void>();
  cargaBotonConsulta: boolean;
  existeContribuyente: boolean;
  contribuyente: ContribuyenteModel = {};
  esContribuyente: Boolean = true
  displayedColumns: Array<string>;
  mensajeResultado: string;
  dataSource;
  oficinaId?: number;
  tipoUsuarioId: number = 0;
  private userInfoSubscription: Subscription | undefined;

  constructor(
    private _userInfo: UserInfoService,
    private parametricaService: ParametricaService,
    private _datosContribuyente: DatosContribuyenteService
  ) {
    this.displayedColumns = [
      'tipoValor',
      'impuestoEspecifico',
      'nroEmision',
      'nroTramite',
      'nroOrdenRedencion',
      'fechaRedencion',
      'importeRedimido',
      'saldoValoresSin',
      'saldoValores',
      'detalle',
    ];
    this.dataSource = new MatTableDataSource<ValoresSaldosModel>([]);
    this.mensajeResultado = '';
    this.oficinaId = 0;
    this.existeContribuyente = false;
    this.cargaBotonConsulta = false;
  }

  ngOnInit(): void {
    this.obtenerDatosSesion();
    setTimeout(() => {
      this.obtenerParametricas();
    }, 500);
  }

  ngOnDestroy(): void {
    if (this.userInfoSubscription) {
      this.userInfoSubscription.unsubscribe();
    }
    this.contribuyente = {};
    this._datosContribuyente.setDataModel(this.contribuyente);
    this.destroy$.next();
    this.destroy$.complete();
  }

  obtenerDatosSesion(): void {
    this.userInfoSubscription = this._userInfo.contextInfo$.subscribe(
      (response) => {
        this.buscarContribuyente(response.userInfo.nitCur);
        this.tipoUsuarioId = response.userInfo.tipoUsuarioId;
      }
    );
  }

  obtenerContribuyente(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
        } else {
          this.contribuyente = {};
        }
      }
    );
  }

  buscarContribuyente(nitCur: number): void {
    this.existeContribuyente = false;

    this._datosContribuyente
      .obtenerContribuyente(nitCur)
      .then((respuesta: RespuestaObjeto<ContribuyenteModel>) => {
        if (respuesta.transaccion && respuesta.objeto != null) {
          this.contribuyente = respuesta.objeto;
          this.existeContribuyente = true;
        }
      })
      .catch((err) => {
        this.existeContribuyente = false;
      })
  }

  obtenerParametricas() {
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id}`,
      },
    };
    this.parametricaService.obtenerParametricas(parametros);
  }
}
