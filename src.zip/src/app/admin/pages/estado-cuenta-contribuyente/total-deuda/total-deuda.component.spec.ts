import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalDeudaComponent } from './total-deuda.component';

describe('TotalDeudaComponent', () => {
  let component: TotalDeudaComponent;
  let fixture: ComponentFixture<TotalDeudaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TotalDeudaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TotalDeudaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
