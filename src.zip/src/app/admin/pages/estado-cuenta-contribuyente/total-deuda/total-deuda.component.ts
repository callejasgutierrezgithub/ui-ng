import { Component, Input } from '@angular/core';
import { TotalDeuda } from '../../../../models/consulta-deudas/total-deuda.model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-total-deuda',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './total-deuda.component.html',
  styleUrl: './total-deuda.component.scss',
})
export class TotalDeudaComponent {
  @Input() data: TotalDeuda = {
    totalSaldoDeudaBs: 0,
    saldoDeudaUsd: 0,
    totalDeudaSeleccionadas: 0,
    tipoCambio: 0,
  };

  constructor() {}
}
