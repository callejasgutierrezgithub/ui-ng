import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, signal } from '@angular/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { CoreService, MaterialModule } from 'core-lib';
import { BolsaCreditosModel } from '../../../../models/bolsas/bolsa-creditos';
import { BolsaCreditoExternoModel } from '../../../../models/bolsas/bolsa-creditos-externo';
import { BolsaFapModel } from '../../../../models/bolsas/bolsa-fap';
import { BolsaIceModel } from '../../../../models/bolsas/bolsa-ice';
import { BolsaIueModel } from '../../../../models/bolsas/bolsa-iue';
import { BolsaPagosModel } from '../../../../models/bolsas/bolsa-pagos';
import { BolsaPagosExcesosModel } from '../../../../models/bolsas/bolsa-pagos-excesos';
import { BolsaRcIvaModel } from '../../../../models/bolsas/bolsa-rc-iva';
import { BolsaStiModel } from '../../../../models/bolsas/bolsa-sti';
import { SieteRgModel } from '../../../../models/bolsas/siete-rg.model';
import { RespuestaSliBolsas } from '../../../../models/bolsas/sli-bolsas';
import { ValoresSaldosModel } from '../../../../models/consulta-valores/valores-saldos.model';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { SliBolsasService } from '../../../../services/bolsas/sli-bolsas.service';
import { DatosContribuyenteService } from '../../../../services/comun/datos-contribuyente.service';
import { SccBolsasComponent } from '../../../../shared/components/scc-bolsas/scc-bolsas.component';
import { SccBolsaCompensacionIdhComponent } from '../../scc-bolsas-cuenta/scc-bolsa-compensacion-idh/scc-bolsa-compensacion-idh.component';
import { SccBolsaCreditoExternoComponent } from '../../scc-bolsas-cuenta/scc-bolsa-credito-externo/scc-bolsa-credito-externo.component';
import { SccBolsaCreditosComponent } from '../../scc-bolsas-cuenta/scc-bolsa-creditos/scc-bolsa-creditos.component';
import { SccBolsaFapComponent } from '../../scc-bolsas-cuenta/scc-bolsa-fap/scc-bolsa-fap.component';
import { SccBolsaIceComponent } from '../../scc-bolsas-cuenta/scc-bolsa-ice/scc-bolsa-ice.component';
import { SccBolsaIueComponent } from '../../scc-bolsas-cuenta/scc-bolsa-iue/scc-bolsa-iue.component';
import { SccBolsaPagosExcesosComponent } from '../../scc-bolsas-cuenta/scc-bolsa-pagos-excesos/scc-bolsa-pagos-excesos.component';
import { SccBolsaPagosComponent } from '../../scc-bolsas-cuenta/scc-bolsa-pagos/scc-bolsa-pagos.component';
import { SccBolsaRcIvaComponent } from '../../scc-bolsas-cuenta/scc-bolsa-rc-iva/scc-bolsa-rc-iva.component';
import { SccBolsaSieteRgComponent } from '../../scc-bolsas-cuenta/scc-bolsa-sieterg/scc-bolsa-sieterg.component';
import { SccBolsaStiComponent } from '../../scc-bolsas-cuenta/scc-bolsa-sti/scc-bolsa-sti.component';
import { SccBolsaValoresSaldosComponent } from '../../scc-bolsas-cuenta/scc-bolsa-valores-saldos/scc-bolsa-valores-saldos.component';

@Component({
  selector: 'app-bolsas',
  standalone: true,
  imports: [
    MaterialModule,
    MatExpansionModule,
    SccBolsaCreditosComponent,
    SccBolsaFapComponent,
    SccBolsaIueComponent,
    SccBolsaPagosComponent,
    SccBolsaValoresSaldosComponent,
    SccBolsaSieteRgComponent,
    SccBolsaPagosExcesosComponent,
    SccBolsaIceComponent,
    SccBolsaStiComponent,
    SccBolsaCreditoExternoComponent,
    SccBolsaRcIvaComponent,
    SccBolsasComponent,
    SccBolsaCompensacionIdhComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './bolsas.component.html',
  styleUrl: './bolsas.component.scss',
})
export class BolsasComponent implements OnInit {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  readonly panelOpenState = signal(false);

  creditos = false;
  pagos = false;
  bolsasRcIva = false;
  pagadosIue = false;
  creditoExterno = false;
  facilidadesPago = false;
  sieteRg = false;
  valoresSaldo = false;
  bolsasIce = false;
  bolsasSti = false;
  pagosExceso = false;

  compensacionIdh = true;
  fap = true;
  perdidasIue = true;

  contribuyente!: ContribuyenteModel;
  dataSourceCreditoInterno: BolsaCreditosModel[] = [];
  dataSourceBolsaPagos: BolsaPagosModel[] = [];
  dataSourceBolsaRcIva: BolsaRcIvaModel[] = [];
  dataSourceBolsaIue: BolsaIueModel[] = [];
  dataSourceCreditoExterno: BolsaCreditoExternoModel[] = [];
  dataSourceBolsaFap: BolsaFapModel[] = [];

  dataSourceSieteRG: SieteRgModel[] = [];
  dataSourcePagosExceso: BolsaPagosExcesosModel[] = [];
  dataSourceValoresSaldos: ValoresSaldosModel[] = [];
  dataSourceBolsaIce: BolsaIceModel[] = [];
  dataSourceBolsaSti: BolsaStiModel[] = [];
  mensageDeuda: String = ""

  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private _sliBolsasService: SliBolsasService,
    private cd: ChangeDetectorRef
  ) {
  }

  ngOnInit(): void {
    this.getContribuyten();
    this.mensageDeuda = "No tiene Saldo Disponible Creditos..."
  }
  getContribuyten(): void {
    this._datosContribuyente.dataModel$.subscribe(
      (contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente;
          this.obtenerSliBolsas(this.contribuyente.nit!);
        } else {
          this.contribuyente = {};
          this.dataSourceCreditoInterno = [];
        }
      }
    );
  }

  obtenerSliBolsas(nit: number) {
    const tipoContribuyentePdr = 0;
    this._sliBolsasService
      .sliBolsas(nit, tipoContribuyentePdr)
      .then((respuesta: RespuestaSliBolsas) => {
        if (respuesta.transaccion && Object.keys(respuesta.objeto!).length > 0) {
          this.dataSourceCreditoInterno = [...respuesta.objeto?.creditosInterno!]
          this.dataSourceBolsaPagos = [...respuesta.objeto?.pagos!]
          this.dataSourceBolsaRcIva = [...respuesta.objeto?.rcIva!]

          this.dataSourceBolsaIue = [...respuesta.objeto?.iue!]
          this.dataSourceCreditoExterno = [...respuesta.objeto?.creditosExterno!]
          this.dataSourceBolsaFap = [...respuesta.objeto?.facilidadesPago!]

          this.dataSourceSieteRG = [...respuesta.objeto?.sieteRg!]
          this.dataSourcePagosExceso = [...respuesta.objeto?.pagosExceso!]
          this.dataSourceValoresSaldos = [...respuesta.objeto?.valoresSaldos!]
          this.dataSourceBolsaIce = [...respuesta.objeto?.ice!]
          this.dataSourceBolsaSti = [...respuesta.objeto?.sti!]

          if ((respuesta.objeto?.creditosInterno!).length > 0) this.creditos = true;
          if ((respuesta.objeto?.pagos!).length > 0) this.pagos = true;
          if ((respuesta.objeto?.rcIva!).length > 0) this.bolsasRcIva = true;

          if ((respuesta.objeto?.iue!).length > 0) this.pagadosIue = true;
          if ((respuesta.objeto?.creditosExterno!).length > 0) this.creditoExterno = true;
          if ((respuesta.objeto?.facilidadesPago!).length > 0) this.facilidadesPago = true;

          if ((respuesta.objeto?.sieteRg!).length > 0) this.sieteRg = true;
          if ((respuesta.objeto?.pagosExceso!).length > 0) this.pagosExceso = true;
          if ((respuesta.objeto?.valoresSaldos!).length > 0) this.valoresSaldo = true;
          if ((respuesta.objeto?.ice!).length > 0) this.bolsasIce = true;
          if ((respuesta.objeto?.sti!).length > 0) this.bolsasSti = true;

          this.cd.detectChanges();
        };
      })
  }
}
