import { SelectionModel } from '@angular/cdk/collections';
import { CommonModule } from '@angular/common';
import { Component, inject, Input, LOCALE_ID, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, RespuestaLista, SiatToastrService } from 'core-lib';
import { MonedaEnum } from '../../../../enums/general.enum';
import { Operacion } from '../../../../enums/operaciones.enum';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DetalleDeudaModel } from '../../../../models/detalle-deudas-contribuyente/detalle-deuda.model';
import { SolicitudDetalleDeuda } from '../../../../models/detalle-deudas-contribuyente/solicitud-detalle-deudas.model';
import { DeudaContribuyenteModel } from '../../../../models/reporte-adeudo-tributario/deuda-contribuyente.model';
import { RespuestaValorEconomico } from '../../../../models/valores-economicos/respuesta-valor-economico.model';
import { SolicitudValorEconomico } from '../../../../models/valores-economicos/solicitud-valor-economico.model';
import { ReporteAdeudoTributarioService } from '../../../../services/detalle-deuda-contribuyente/reporte-adeudo-tributario.service';
import { ParametricaValoresEconomicosService } from '../../../../services/parametricas/parametrica-valores-economicos.service';
import { Fecha } from '../../../../shared/utils/fecha';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { PasarDatosDialog } from '../../../../shared/utils/pasar-datos-dialog';
import { SccModalDetalleDeudaActualizacionComponent } from '../../scc-consulta-deudas-por-contribuyente-internas/scc-detalle-deuda-contribuyente/scc-modal-detalle-deuda-actualizacion/scc-modal-detalle-deuda-actualizacion.component';
import { SccModalDetalleLiquidacionComponent } from '../../scc-consulta-deudas-por-contribuyente-internas/scc-detalle-deuda-contribuyente/scc-modal-detalle-liquidacion/scc-modal-detalle-liquidacion.component';
import { SccModalDetallePagosComponent } from '../../scc-consulta-deudas-por-contribuyente-internas/scc-detalle-deuda-contribuyente/scc-modal-detalle-pagos/scc-modal-detalle-pagos.component';
import { LocaldatePipe } from '../../../../pipes/localdate.pipe';

@Component({
  selector: 'app-deudas',
  standalone: true,
  imports: [MaterialModule, CommonModule, LocaldatePipe],
  providers: [{ provide: LOCALE_ID, useValue: 'es' }],
  templateUrl: './deudas.component.html',
  styleUrl: './deudas.component.scss',
})
export class DeudasComponent {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  @Input() contribuyente: ContribuyenteModel = {};
  dataSource;
  displayedColumns: string[];
  tableLoading: boolean = true;
  mensajeTable: String;
  selectedRows = new Set<any>();
  selection = new SelectionModel<any>(true, []);
  totalSaldoDeudaBs: number = 0;
  totalSaldoDeudaUsd: number = 0;
  totalDeudaSeleccionadas: number = 0;
  saldoDeudaBs: number = 0;
  saldoDeudaUsd: number = 0;
  tipoCambio: number = 0;
  fechaActual: Date;
  paginatorAsignado: Boolean = false;
  loading: Boolean;
  mensageDeuda: String = "";

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(
    private dialog: MatDialog,
    private toastr: SiatToastrService,
    private reporteAdeudoService: ReporteAdeudoTributarioService,
    private parametricaValoresEconomicosService: ParametricaValoresEconomicosService,
  ) {
    this.dataSource = new MatTableDataSource<DetalleDeudaModel>([]);
    this.displayedColumns = [
      'select',
      'deudaId',
      'numeroOrdenDocumento',
      'documentoAgrupador',
      'numeroOrdenDocumentoAgrupador',
      'impuestoId',
      'formularioId',
      'periodo',
      'anio',
      'dependencia',
      'proceso',
      'documento',
      'fechaVencimiento',
      'fechaRegistro',
      'moneda',
      'montoDeudaInicialRepositorioBs', //montoDeudaInicialBs -> repositorio
      'montoDeudaInicialBs',
      'montoDeudaUsd',
      'deudaTotalBs',
      'deudaTotalUfv',
      'deudaTotalUsd',
      'acciones',
    ];
    this.mensajeTable = '';
    this.fechaActual = new Date();
    this.loading = false;
  }

  ngOnInit(): void {
    this.obtenerDeudas();
    this.obtenerValoresEconomicos();
  }

  ngAfterViewChecked() {
    if (!this.paginatorAsignado && this.paginator && this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.paginatorAsignado = true;
    }
  }
  obtenerValoresEconomicos(): void {
    const solicitud: SolicitudValorEconomico = {
      fecha: Fecha.toLocalDate(this.fechaActual),
      oficinaId: this.contribuyente.administracion!,
    };

    this.parametricaValoresEconomicosService
      .obtenerValoresEconomicos(solicitud)
      .then((respuesta: RespuestaValorEconomico) => {
        if (respuesta.transaccion) {
          this.tipoCambio = respuesta.tipoCambio;
        } else {
          this.toastr.info(MensajeConstante.MSG_ERROR);
        }
      })
      .catch(() => {
        this.toastr.info(MensajeConstante.MSG_ERROR);
      });
  }

  obtenerDeudas() {
    const solicitud: SolicitudDetalleDeuda = {
      nitCur: this.contribuyente.nit,
      oficinaId: this.contribuyente.administracion,
      origenId: 292,
    };
    this.loading = true;
    this.mensageDeuda = "";
    this.tableLoading = true;
    this.reporteAdeudoService
      .obtenerDetalleDeuda(solicitud)
      .then((respuesta: RespuestaLista<DetalleDeudaModel>) => {
        this.mensajeTable =
          respuesta.objetosList!.length === 0
            ? MensajeConstante.MSG_NOT_RESULT
            : '';
        if (respuesta.transaccion) {
          if (respuesta.objetosList!.length > 0) {
            this.dataSource.data = respuesta.objetosList ?? [];
            this.dataSource.paginator = this.paginator;
            this.dataSource.data.map(function (dato) {
              dato.moneda =
                dato.monedaId == MonedaEnum.BOLIVIANOS_ID
                  ? MonedaEnum[MonedaEnum.BOLIVIANOS_ID]
                  : MonedaEnum[MonedaEnum.DOLARES_ID];
              return dato;
            });
            this.tableLoading = false;
            this.dataSource.data = this.dataSource.data;
          } else {
            this.dataSource.data = [];
          }
        } else {
          this.toastr.warning(respuesta.mensajes[0].descripcion);
        }
        if (this.dataSource.data.length === 0) this.mensageDeuda = `El Nit: ${this.contribuyente.nit}, no tiene Deudas...`;
      })
      .catch(() => {
        this.toastr.error('Error al Obtener Deudas...');
        this.mensageDeuda = "Error al Obtener Deudas...";
      }).finally(() => {
        setTimeout(() => {
          this.loading = false;
        }, 700);
      });
  }

  toggleSelectAll(checked: boolean) {
    if (checked) {
      this.dataSource.data.forEach((row) => this.selectedRows.add(row));
    } else {
      this.selectedRows.clear();
    }
    this.calculateTotal();
  }

  toggleSelection(row: any) {
    if (this.selectedRows.has(row)) {
      this.selectedRows.delete(row);
    } else {
      this.selectedRows.add(row);
    }
    this.calculateTotal();
  }

  isAllSelected(): boolean {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  isIndeterminate(): boolean {
    return (
      this.selectedRows.size > 0 &&
      this.selectedRows.size < this.dataSource.data.length
    );
  }

  isSelected(row: any): boolean {
    return this.selectedRows.has(row);
  }

  totalValues: Record<string, number> = {};

  calculateTotal(): void {
    const fields = [
      { field: 'deudaTotalBs', label: 'totalSaldoDeudaBs' },
      { field: 'deudaTotalUsd', label: 'totalSaldoDeudaUsd' },
      { field: 'montoDeudaBs', label: 'saldoDeudaBs' },
      { field: 'deudaTotalUsd', label: 'saldoDeudaUsd' },
    ];

    fields.forEach(({ field, label }) => {
      this.totalValues[label] = this.calculateSum(field);
    });
    this.totalSaldoDeudaBs = this.totalValues['totalSaldoDeudaBs'];
    this.totalSaldoDeudaUsd = this.totalValues['totalSaldoDeudaUsd'];
    this.saldoDeudaBs = this.totalValues['saldoDeudaBs'];
    this.saldoDeudaUsd = this.totalValues['saldoDeudaUsd'];
    this.totalDeudaSeleccionadas =
      this.totalSaldoDeudaBs + this.saldoDeudaUsd * this.tipoCambio;
  }

  calculateSum(field: string): number {
    return Array.from(this.selectedRows).reduce(
      (sum, deuda) => sum + (deuda[field] ?? 0),
      0
    );
  }

  detallePagos(deudaContribuyente: DeudaContribuyenteModel): void {
    deudaContribuyente.nitCur = this.contribuyente.nit;
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    const dialogRef = this.dialog.open(SccModalDetallePagosComponent, {
      disableClose: true,
      width: '500',
      data: datos,
    });
  }

  detalleLiquidaciones(deudaContribuyente: DetalleDeudaModel): void {
    deudaContribuyente.nitCur = this.contribuyente.nit;
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    const dialogRef = this.dialog.open(SccModalDetalleLiquidacionComponent, {
      disableClose: true,
      width: '500',
      data: datos,
    });
  }

  detalleDeudaActualizacion(deudaContribuyente: DeudaContribuyenteModel): void {
    const datos: PasarDatosDialog<DeudaContribuyenteModel> = {
      operacion: Operacion.READ,
      datos: deudaContribuyente,
    };
    const dialogRef = this.dialog.open(
      SccModalDetalleDeudaActualizacionComponent,
      {
        disableClose: true,
        width: '500',
        data: datos,
      }
    );
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }
}
