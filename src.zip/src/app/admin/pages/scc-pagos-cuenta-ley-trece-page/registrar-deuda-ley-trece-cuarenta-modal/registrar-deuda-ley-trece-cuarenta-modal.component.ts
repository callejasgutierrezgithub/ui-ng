import { Component, Inject, OnInit } from '@angular/core';
import { MaterialModule, SiatToastrService, TitlePageComponent } from 'core-lib';
import { DatosContribuyenteComponent } from '../../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatNativeDateModule } from '@angular/material/core';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { RequestRepositorioPagosLeyTreceCuarentaModel } from '../../../../models/deudas-trece-cuarenta/pagos-treceCuarenta.model';
import { Fecha } from '../../../../shared/utils/fecha';
import { ExpresionRegularEnum } from '../../../../enums/expresion-regular.enum';
import { AlertService } from '../../../../services/comun/alert.service';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { DeudasTreceCuarentaService } from '../../../../services/ley-trece-cuarenta-service/deudas-trece-cuarenta.service';
import { PasarDatosDialog } from '../../../../shared/utils/pasar-datos-dialog';

@Component({
  selector: 'app-registrar-deuda-ley-trece-cuarenta-modal',
  standalone: true,
  imports: [
    MaterialModule,    
    ReactiveFormsModule, CommonModule, RouterModule, MatNativeDateModule, FormsModule
  ],
  templateUrl: './registrar-deuda-ley-trece-cuarenta-modal.component.html',
  styleUrl: './registrar-deuda-ley-trece-cuarenta-modal.component.scss'
})
export class RegistrarDeudaLeyTreceCuarentaModalComponent implements OnInit {
  form!: FormGroup;
  swModalRegistrarPagoTreceCuarenta: boolean = false;
  FechaDesde: Date;
  FechaHasta: Date;

  constructor(
      private dialog: MatDialog,
      private alertService: AlertService,
      public dialogRef: MatDialogRef<RegistrarDeudaLeyTreceCuarentaModalComponent>,
      private deudasTreceCuarentaService: DeudasTreceCuarentaService,
      private formBuilder: FormBuilder,
      private toastr: SiatToastrService,
      @Inject(MAT_DIALOG_DATA)
      public data: PasarDatosDialog<RequestRepositorioPagosLeyTreceCuarentaModel>
    ) {
      this.form = this.formBuilder.group({});
      this.FechaDesde = new Date('01/01/1990');
      this.FechaHasta = new Date('07/30/2016');
  }

  ngOnInit(): void {    
    this.crearFormulario();
  }

  crearFormulario (): void {
    this.form = this.formBuilder.group({                    
      fechaPago: [null, [Validators.required]],
      montoInteresBs: [null, [
          Validators.required, 
          Validators.minLength(1),
          Validators.maxLength(10),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros)]
      ],            
      montoTributoOmitidoBs: [null, [
        Validators.required, 
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.min(1),
        Validators.pattern(ExpresionRegularEnum.Numeros)]
      ],     
      montoSancionBs: [null, [
        Validators.required, 
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.min(1),
        Validators.pattern(ExpresionRegularEnum.Numeros)]
      ],     
      montoMantenimientoValorBs: [null, [
        Validators.required, 
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.min(1),
        Validators.pattern(ExpresionRegularEnum.Numeros)]
      ],     
      montoMultaBs: [null, [
        Validators.required, 
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.min(1),
        Validators.pattern(ExpresionRegularEnum.Numeros)]
      ],       
    });      
  }

  registrarPagoTreceCuarenta(){    
    var vSolicitud: RequestRepositorioPagosLeyTreceCuarentaModel = {
      deudaId: this.data.datos.deudaId,
      nitCur: this.data.datos.nitCur,
      fechaPago: Fecha.toLocalDate(this.form.get('fechaPago')?.value)!,
      montoInteresBs: this.form.get('montoInteresBs')?.value,
      montoTributoOmitidoBs: this.form.get('montoTributoOmitidoBs')?.value,
      montoSancionBs: this.form.get('montoSancionBs')?.value,
      montoMantenimientoValorBs: this.form.get('montoMantenimientoValorBs')?.value,
      montoMultaBs: this.form.get('montoMultaBs')?.value,
      periodo: this.data.datos.periodo,
      anio: this.data.datos.anio,
      tipoContribuyentePdrId: 0,
    }
    
    this.deudasTreceCuarentaService
      .registrarRepositorioPagoTreceCuarenta(vSolicitud).then( response => {
        this.dialogRef.close(response);
        if(response.transaccion){          
          this.toastr.success(MensajeConstante.MSG_ADD);                    
        } else {
          this.toastr.info(MensajeConstante.MSG_ERROR);            
        }
      });
  }
}
