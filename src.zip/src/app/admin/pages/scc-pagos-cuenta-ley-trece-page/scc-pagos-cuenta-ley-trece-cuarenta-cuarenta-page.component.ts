import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { CoreService, MaterialModule, Respuesta, SiatToastrService, TitlePageComponent } from 'core-lib';
import { Subscription } from 'rxjs';
import { ExpresionRegularEnum } from '../../../enums/expresion-regular.enum';
import { Operacion } from '../../../enums/operaciones.enum';
import { ParametricasEnum } from '../../../enums/parametricas.enum';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { RequestRepositorioPagosLeyTreceCuarentaModel, ResponseRepositorioPagosLeyTreceCuarentaModel, SolicitudPagosTreceCuarenta } from '../../../models/deudas-trece-cuarenta/pagos-treceCuarenta.model';
import { ParametricaGenericaModel, ParametroModel } from '../../../models/parametrica/parametrica-generica.model';
import { RespuestaParametrica } from '../../../models/parametrica/respuesta-parametrica-generica.model';
import { LocaldatePipe } from '../../../pipes/localdate.pipe';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { DeudasTreceCuarentaService } from '../../../services/ley-trece-cuarenta-service/deudas-trece-cuarenta.service';
import { ParametricaService } from '../../../services/parametricas/parametrica.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { SelectFilterComponent } from '../../../shared/components/select-filter/select-filter.component';
import { Fecha } from '../../../shared/utils/fecha';
import { MensajeConstante } from '../../../shared/utils/mensaje-constante';
import { PasarDatosDialog } from '../../../shared/utils/pasar-datos-dialog';
import { RegistrarDeudaLeyTreceCuarentaModalComponent } from './registrar-deuda-ley-trece-cuarenta-modal/registrar-deuda-ley-trece-cuarenta-modal.component';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';

@Component({
  selector: 'app-scc-pagos-cuenta-ley-trece-cuarenta-page',
  standalone: true,
  imports: [
    MaterialModule,
    DatosContribuyenteComponent,
    TitlePageComponent,
    ReactiveFormsModule, CommonModule, RouterModule, MatNativeDateModule, FormsModule, SelectFilterComponent, LocaldatePipe,
    InformacionContribuyenteComponent],
  templateUrl: './scc-pagos-cuenta-ley-trece-cuarenta-page.component.html',
  styleUrls: ['./scc-pagos-cuenta-ley-trece-cuarenta-page.component.css']
})
export class SccPagosCuentaLeyTreceCuarentaPageComponent implements OnInit, OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  private contribuyenteSubscription?: Subscription;
  private parametricaSubscription?: Subscription;
  formRegistrarPagoCuenta: FormGroup;
  formRepositorioLiquidacion: FormGroup;
  dataSource;
  loadingTable: boolean = true;
  tablaCargando: boolean;

  btnSearchLoading: boolean;
  btnLoading: boolean;
  listaAlertas: string[];
  columnas: Array<string>;
  tipoProceso: ParametricaGenericaModel[];
  procesosFiltrado: ParametricaGenericaModel[];
  contribuyente: ContribuyenteModel = {};
  existeResultado: boolean;
  contribuyenteBoolean: Boolean = false;
  obtenerRepositorioLiquidacionBoolean: Boolean = false;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  consultaNit: Boolean = false;
  mensajeNit: string = '';
  constructor(
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private parametricaService: ParametricaService,
    private _datosContribuyente: DatosContribuyenteService,
    private deudasTreceCuarentaService: DeudasTreceCuarentaService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) {
    this.columnas = [
      'fechaPago',
      'montoTributoOmitidoBs',
      'montoMantenimientoValorBs',
      'montoInteresBs',
      'montoSancionBs',
      'montoMultaBs',
      'totalPago',
    ];
    this.formRegistrarPagoCuenta = new FormGroup({});
    this.formRepositorioLiquidacion = new FormGroup({});
    this.tipoProceso = [];
    this.btnSearchLoading = false;
    this.btnLoading = false;
    this.dataSource = new MatTableDataSource<ResponseRepositorioPagosLeyTreceCuarentaModel>([]);
    this.tablaCargando = false;
    this.procesosFiltrado = [];
    this.listaAlertas = [];
    this.existeResultado = false;
    this.obtenerConsultaNit();
  }

  ngOnInit(): void {
    setTimeout(() => {
      this.obtenerParametricas();
    }, 500)
    this.crearFormulario();
    this.crearFormularioRepositorioLiquidacion();
    this.disableFormularios();
    // this.getContribuyente();      
  }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }

  crearFormulario() {
    this.formRegistrarPagoCuenta = this.formBuilder.group({
      procesoId: [null, [Validators.required]],
      deudaId: [null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(15),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ]
      ],
    });
  }

  crearFormularioRepositorioLiquidacion(): void {
    this.formRepositorioLiquidacion = this.formBuilder.group({
      periodo: [null, Validators.required],
      anio: [null, Validators.required],
      monto: [null, Validators.required],
      fechaVencimiento: [null, Validators.required],
    });
  }
  obtenerParametricas() {
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.documento_id}`,
      },
    };
    this.parametricaService.obtenerParametricas(parametros).then(() => {
      this.parametricaSubscription = this.parametricaService.dataModel$.subscribe(
        (parametrica: RespuestaParametrica<ParametricaGenericaModel>) => {
          this.tipoProceso = parametrica.proceso_id ?? [];
          this.procesosFiltrado = parametrica.proceso_id.map(
            (item: ParametricaGenericaModel) => {
              item.descripcion = `${item.id} - ${item.descripcion}`;
              return item;
            }
          );
          this.procesosFiltrado = this.tipoProceso.slice();
          if (this.tipoProceso.length === 0) {
            this.listaAlertas.push('Procesos');
          }
        }
      );
    });
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this.contribuyenteSubscription = this._datosContribuyente.dataModel$.subscribe((contribuyente: ContribuyenteModel) => {
        if (contribuyente && contribuyente.nit) {
          this.contribuyente = contribuyente!;
          this.enableformRegistrarPagoCuenta();
        } else {
          this.limpiarFormulario();
          this.limpiarFormRegistrarPagoCuenta();
          this.contribuyente = {}
          this.dataSource.data = [];
          this.obtenerRepositorioLiquidacionBoolean = false;
        }
      });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }

  obtenerRepositorioLiquidacionLey1340(): void {
    this.obtenerRepositorioLiquidacionBoolean = false;
    const vNitCur: number = this.contribuyente.nit!;
    const vDeudaId: number = this.formRegistrarPagoCuenta.get('deudaId')?.value;
    this.deudasTreceCuarentaService
      .obtenerDatosDeudaTreceCuarenta(vNitCur, vDeudaId).then(response => {
        if (response.transaccion) {
          this.obtenerRepositorioLiquidacionBoolean = response.transaccion;
          this.toastr.success(MensajeConstante.MSG_SUCCESS_FOUND);
          this.formRepositorioLiquidacion.get('periodo')?.setValue(response.objeto?.periodo);
          this.formRepositorioLiquidacion.get('anio')?.setValue(response.objeto?.anio);
          this.formRepositorioLiquidacion.get('monto')?.setValue(response.objeto?.montoDeudaBs);
          this.formRepositorioLiquidacion.get('fechaVencimiento')?.setValue(Fecha.format(response.objeto?.fechaVencimiento!));
          this.obtenerListaRepositoriosPagosTreceCuarenta();
        } else {
          this.toastr.info(MensajeConstante.MSG_NOT_RESULT);
          this.limpiarFormulario();
        }
      });
  }

  obtenerListaRepositoriosPagosTreceCuarenta(): void {
    const vNitCur: number = this.contribuyente.nit!;
    const vDeudaId: number = this.formRegistrarPagoCuenta.get('deudaId')?.value;
    const vProcesoId: number = this.formRegistrarPagoCuenta.get('procesoId')?.value;
    let vSolicitud: SolicitudPagosTreceCuarenta = {
      nitCur: vNitCur,
      deudaId: vDeudaId,
      procesoId: vProcesoId
    }
    this.deudasTreceCuarentaService
      .obtenerListaDeudasTreceCuarenta(vSolicitud).then(response => {
        if (response.transaccion) {
          this.dataSource.data = response.objetosList || [];
          this.dataSource.paginator = this.paginator;
          this.toastr.success(MensajeConstante.MSG_SUCCESS_FOUND);
          this.loadingTable = false;
        }
      });
  }

  registroPagoTreceCuarenta(): void {
    const pSolicitud: RequestRepositorioPagosLeyTreceCuarentaModel = {
      nitCur: this.contribuyente.nit!,
      deudaId: this.formRegistrarPagoCuenta.get('deudaId')?.value,
      periodo: this.formRepositorioLiquidacion.get('periodo')?.value,
      anio: this.formRepositorioLiquidacion.get('anio')?.value,
    }

    const datos: PasarDatosDialog<RequestRepositorioPagosLeyTreceCuarentaModel> = {
      operacion: Operacion.CREATE,
      datos: pSolicitud,
    };
    const dialogRef = this.dialog.open(RegistrarDeudaLeyTreceCuarentaModalComponent, {
      panelClass: 'border-dialog',
      width: '900px',
      enterAnimationDuration: '300ms',
      exitAnimationDuration: '300ms',
      autoFocus: false,
      disableClose: true,
      data: datos,
    });
    dialogRef.afterClosed().subscribe((respuesta: Respuesta) => {
      if (respuesta != null && respuesta.transaccion) {
        this.obtenerListaRepositoriosPagosTreceCuarenta();
      }
    });
  }

  disableFormularios(): void {
    this.formRegistrarPagoCuenta.get('razonSocial')?.disable();
    this.formRepositorioLiquidacion.get('periodo')?.disable();
    this.formRepositorioLiquidacion.get('anio')?.disable();
    this.formRepositorioLiquidacion.get('monto')?.disable();
    this.formRepositorioLiquidacion.get('fechaVencimiento')?.disable();
  }

  enableformRegistrarPagoCuenta(): void {
    this.formRegistrarPagoCuenta.get('procesoId')?.enable();
    this.formRegistrarPagoCuenta.get('deudaId')?.enable();
  }

  limpiarFormulario(): void {
    this.formRepositorioLiquidacion.get('periodo')?.setValue('');
    this.formRepositorioLiquidacion.get('anio')?.setValue('');
    this.formRepositorioLiquidacion.get('monto')?.setValue('');
    this.formRepositorioLiquidacion.get('fechaVencimiento')?.setValue('');
    this.dataSource.data = [];
  }

  limpiarFormRegistrarPagoCuenta(): void {
    this.formRegistrarPagoCuenta.get('procesoId')?.disable();
    this.formRegistrarPagoCuenta.get('deudaId')?.disable();
    this.formRegistrarPagoCuenta.get('procesoId')?.reset('');
    this.formRegistrarPagoCuenta.get('deudaId')?.reset('');
  }

  ngOnDestroy(): void {
    if (this.parametricaSubscription) {
      this.parametricaSubscription.unsubscribe();
    }
    if (this.contribuyenteSubscription) {
      this.contribuyenteSubscription.unsubscribe();
    }
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }
}
