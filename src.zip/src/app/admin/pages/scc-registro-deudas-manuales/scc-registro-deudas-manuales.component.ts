import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { CoreService, MaterialModule, TitlePageComponent } from 'core-lib';
import { ContribuyenteModel } from '../../../models/contribuyente/contribuyente.model';
import { DatosContribuyenteService } from '../../../services/comun/datos-contribuyente.service';
import { ConsultaContribuyenteStoreService } from '../../../services/store/consulta-contribuyente-store.service';
import { DatosContribuyenteComponent } from '../../../shared/components/datos-contribuyente/datos-contribuyente.component';
import { InformacionContribuyenteComponent } from '../../../shared/components/informacion-contribuyente/informacion-contribuyente.component';
import { SccGrillaRegistroDeudasManualesComponent } from './scc-grilla-registro-deudas-manuales/scc-grilla-registro-deudas-manuales.component';

@Component({
  selector: 'app-scc-registro-deudas-manuales',
  standalone: true,
  imports: [
    MaterialModule, CommonModule, ReactiveFormsModule, FormsModule,
    MatNativeDateModule,
    TitlePageComponent,
    DatosContribuyenteComponent,
    SccGrillaRegistroDeudasManualesComponent,
    InformacionContribuyenteComponent,
  ],
  templateUrl: './scc-registro-deudas-manuales.component.html',
  styleUrl: './scc-registro-deudas-manuales.component.scss'
})
export class SccRegistroDeudasManualesComponent implements OnDestroy {
  private settings = inject(CoreService);
  options = this.settings.getOptions();
  mensajeNit: string = '';
  consultaNit: Boolean = false;
  contribuyente: ContribuyenteModel = {};
  constructor(
    private _datosContribuyente: DatosContribuyenteService,
    private _consultaContribuyenteStore: ConsultaContribuyenteStoreService,
  ) { this.obtenerConsultaNit(); }

  obtenerConsultaNit(): void {
    effect(() => {
      this.consultaNit = this._consultaContribuyenteStore.getConsultaNit()();
      this.getContribuyente();
    });
  }
  ngOnDestroy(): void {
    this._datosContribuyente.setDataModel({});
    this._consultaContribuyenteStore.setMensaje('');
    this._consultaContribuyenteStore.setConsultaNit(false);
  }

  getContribuyente(): void {
    if (this.consultaNit) {
      this._datosContribuyente.dataModel$
        .subscribe((contribuyente: ContribuyenteModel) => {
          if (contribuyente && contribuyente.nit) {
            this.contribuyente = contribuyente;
          } else {
            this.contribuyente = {}
          }
        });
    } else {
      this.mensajeNit = this._consultaContribuyenteStore.getMensaje()();
    }
  }
}
