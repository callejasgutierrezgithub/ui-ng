import { animate, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, inject, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
  MatNativeDateModule,
} from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CoreService, MaterialModule, Respuesta, RespuestaLista, SiatToastrService } from 'core-lib';
import { NgxSpinnerModule } from 'ngx-spinner';
import { Subscription } from 'rxjs';
import { TipoContribuyenteIdEnum } from '../../../../enums/contribuyente';
import { ExpresionRegularEnum } from '../../../../enums/expresion-regular.enum';
import { MensajesGenericoEnum, MonedaEnum } from '../../../../enums/general.enum';
import { ParProcesoEnum } from '../../../../enums/par-proceso.enum';
import { ParametricasEnum } from '../../../../enums/parametricas.enum';
import { ConfirmarDialogModel } from '../../../../models/confirmar-dialog/confirmar-dialog.model';
import { ContribuyenteModel } from '../../../../models/contribuyente/contribuyente.model';
import { DeudaGenericaDetalle } from '../../../../models/documentos-agrupadores/deuda-generica-detalle.model';
import { RespuestaDeudaGenerica } from '../../../../models/documentos-agrupadores/respuesta-deuda-generica.model';
import { SolicitudDeudaBs } from '../../../../models/documentos-agrupadores/solicitud-deudas-bs.model';
import { SolicitudDeudaUfv } from '../../../../models/documentos-agrupadores/solicitud-deudas-ufv.model';
import { SolicitudDeudaMontoCongelarRd } from '../../../../models/documentos-agrupadores/solicitud-registros-manuales';
import {
  FormularioModel,
  RespuestaFormulario,
} from '../../../../models/impuesto-asociado/formulario.model';
import {
  ImpuestoModel,
  RespuestaImpuestos,
} from '../../../../models/impuesto-asociado/impuesto.model';
import {
  ParContravencionesModel,
  RespuestaContravenciones,
} from '../../../../models/parametrica/par-contravenciones.model';
import {
  ParametricaGenericaModel,
  ParametroModel,
} from '../../../../models/parametrica/parametrica-generica.model';
import { ParametricaValoresEconomicosService } from '../../../../services/parametricas/parametrica-valores-economicos.service';
import { ParametricaService } from '../../../../services/parametricas/parametrica.service';
import { DocumentosAgrupadoresService } from '../../../../services/registro-deudas-manuales/documentos-agrupadores.service';
import { OtrDetalleDeudasService } from '../../../../services/registro-deudas-manuales/otr-detalle-deudas.service';
import { SccButtonLoadingComponent } from '../../../../shared/components/scc-button-loading/scc-button-loading.component';
import { SccConfirmDialogComponent } from '../../../../shared/components/scc-confirm-dialog/scc-confirm-dialog.component';
import { SccDatePickerYearComponent } from '../../../../shared/components/scc-datepicker-year/scc-datepicker-year.component';
import { SelectFilterComponent } from '../../../../shared/components/select-filter/select-filter.component';
import { Fecha } from '../../../../shared/utils/fecha';
import { CustomDateAdapter } from '../../../../shared/utils/formato-fecha-date-picker/custom-date-adapter';
import { FORMATO_FECHA_DIA_MES_ANIO } from '../../../../shared/utils/formato-fecha-date-picker/date-format';
import { MensajeConstante } from '../../../../shared/utils/mensaje-constante';
import { validarCampoFormulario } from '../../../../shared/utils/validad-formulario/validar-campos';

@Component({
  selector: 'scc-grilla-registro-deudas-manuales',
  standalone: true,
  imports: [
    MaterialModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatNativeDateModule,
    SelectFilterComponent,
    NgxSpinnerModule,
    SccDatePickerYearComponent,
    SccButtonLoadingComponent,
  ],
  templateUrl: './scc-grilla-registro-deudas-manuales.component.html',
  styleUrl: './scc-grilla-registro-deudas-manuales.component.scss',
  providers: [
    { provide: MAT_DATE_FORMATS, useValue: FORMATO_FECHA_DIA_MES_ANIO },
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    { provide: DateAdapter, useClass: CustomDateAdapter },
  ],
  animations: [
    trigger('highlightRow', [
      transition(':enter', [
        style({ backgroundColor: 'yellow', opacity: 0 }),
        animate('1s ease-out', style({ backgroundColor: 'transparent', opacity: 1 }))
      ])
    ])
  ],
})
export class SccGrillaRegistroDeudasManualesComponent
  implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  @Input() contribuyente: ContribuyenteModel = {};
  private settings = inject(CoreService);
  optionsThema = this.settings.getOptions();
  private parametricaSubscription?: Subscription;
  formDocumentoAgrupador: FormGroup;
  formActualizarDeudasManuales: FormGroup;
  fechaMinimoDesde: Date;
  fechaActual: Date;
  dataSource;
  tablaCargando: boolean;
  tipoProceso: ParametricaGenericaModel[];
  tipoProcesoFiltrado: ParametricaGenericaModel[];
  tipoDocumento: ParametricaGenericaModel[];
  tipoDocumento2: ParametricaGenericaModel[];
  tipoOficina: ParametricaGenericaModel[];
  tipoDocumentoFiltrado: ParametricaGenericaModel[];
  tipoDocumentoFiltrado2: ParametricaGenericaModel[];
  procesosFiltrado: ParametricaGenericaModel[];
  oficinasFiltrado: ParametricaGenericaModel[];
  deudas: Array<number>;
  btnSearchLoading: boolean;
  existeResultado: boolean;
  btnLoading: boolean;
  tablaColumnas: Array<string>;
  tipoPeriodo: ParametricaGenericaModel[];
  tipoDeuda = new FormControl();
  formGenerarDeuda!: FormGroup;
  impuestosFiltrado: ImpuestoModel[];
  documentosFiltrado: ParametricaGenericaModel[];
  formulariosFiltrado: FormularioModel[];
  asientosFiltrado: ParametricaGenericaModel[];
  asientosFiltrado2: ParametricaGenericaModel[];
  contravencionesFiltrado: ParametricaGenericaModel[];

  tipoImpuesto: ImpuestoModel[];
  tipoImpuesto2: ImpuestoModel[];
  tipoFormulario: FormularioModel[];
  tipoAsiento: ParametricaGenericaModel[];
  tipoAsiento2: ParametricaGenericaModel[];
  tipoContravencion: ParContravencionesModel[];
  tipoGerencia: ParametricaGenericaModel[];
  contravencionId: number = 0;
  sw: boolean = false;

  BsRegistro: number = 0;
  UfvRegistro: number = 0;
  UsdRegistro: number = 0;
  options = [
    { value: 'ufv', label: 'Generica Deuda en UFV' },
    { value: 'bs', label: 'Generica Deuda en Bs' },
    { value: 'usd', label: 'Generica Deuda en Dolar' },
  ];
  anioBooleanP: boolean = false;
  loading: Boolean;
  paginatorAsignado: Boolean = false;
  constructor(
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private toastr: SiatToastrService,
    private otrService: OtrDetalleDeudasService,
    private parametricaService: ParametricaService,
    private ddjjService: ParametricaValoresEconomicosService,
    private _generarDeudaService: DocumentosAgrupadoresService
  ) {
    this.formGenerarDeuda = new FormGroup({});
    this.tablaColumnas = [
      'nro',
      'deudaId',
      'impuestoId',
      'documentoAgrupador',
      'numeroOrdenDocumentoAgrupador',
      'documento',
      'formularioId',
      'numeroOrdenDocumento',
      'periodo',
      'anio',
      'deudaTotalBs',
      'sancionBs',
      'agravanteBs',
      'multaUfv',
    ];

    this.impuestosFiltrado = [];
    this.documentosFiltrado = [];
    this.formulariosFiltrado = [];
    this.asientosFiltrado = [];
    this.contravencionesFiltrado = [];

    this.formDocumentoAgrupador = new FormGroup({});
    this.formActualizarDeudasManuales = new FormGroup({});
    this.fechaMinimoDesde = new Date('1981/01/01');
    this.fechaActual = new Date();
    this.dataSource = new MatTableDataSource<DeudaGenericaDetalle>([]);
    this.tablaCargando = false;
    this.tipoDocumento = [];
    this.tipoOficina = [];
    this.btnSearchLoading = false;
    this.existeResultado = false;
    this.btnLoading = false;
    this.procesosFiltrado = [];
    this.oficinasFiltrado = [];
    this.tipoDocumentoFiltrado = [];
    this.tipoDocumentoFiltrado2 = [];
    this.deudas = [];
    this.tipoProceso = [];
    this.tipoProcesoFiltrado = [];
    this.tipoDocumento2 = [];
    this.tipoImpuesto = [];
    this.tipoImpuesto2 = [];
    this.tipoFormulario = [];
    this.tipoAsiento = [];
    this.tipoAsiento2 = [];
    this.tipoContravencion = [];
    this.fechaMinimoDesde = new Date('1981/01/01');
    this.fechaActual = new Date();

    this.impuestosFiltrado = [];
    this.documentosFiltrado = [];
    this.formulariosFiltrado = [];
    this.asientosFiltrado2 = [];
    this.contravencionesFiltrado = [];

    this.tipoGerencia = [
      { id: 100000014, descripcion: 'DEPARTAMENTO DE FISCALIZACION' },
      // {
      //   id: 100000010,
      //   descripcion: 'GERENCIA DE RECAUDACION Y EMPADRONAMIENTO',
      // },
      // { id: 100000019, descripcion: 'GERENCIA JURIDICA Y NORMAS TRIBUTARIAS' },
    ];

    this.tipoPeriodo = [
      { id: 1, descripcion: 'ENERO' },
      { id: 2, descripcion: 'FEBRERO' },
      { id: 3, descripcion: 'MARZO' },
      { id: 4, descripcion: 'ABRIL' },
      { id: 5, descripcion: 'MAYO' },
      { id: 6, descripcion: 'JUNIO' },
      { id: 7, descripcion: 'JULIO' },
      { id: 8, descripcion: 'AGOSTO' },
      { id: 9, descripcion: 'SEPTIEMBRE' },
      { id: 10, descripcion: 'OCTUBRE' },
      { id: 11, descripcion: 'NOVIEMBRE' },
      { id: 12, descripcion: 'DICIEMBRE' },
    ];
    this.loading = true;
  }

  isNew: boolean = false;
  ngOnInit() {
    this.crearFormulario();
    this.obtenerImpuestos();
    setTimeout(() => {
      const parametros: ParametroModel = {
        parametricas: {
          clasificadores: `${ParametricasEnum.tipo_moneda_id}`,
        },
      };
      this.obtenerParametricas();
      this.formGenerarDeuda.get('formularioId')!.disable();
    }, 300);
    this.obtenerParametricaContravenciones();
    this.listarDetalleDeudas();

    this.isNew = true;
    setTimeout(() => {
      this.isNew = false;
    }, 3000);


  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.sort.active = 'deudaId';
    this.sort.direction = 'desc';
    this.sort.sortChange.emit();
  }

  crearFormulario() {
    this.formGenerarDeuda = this.formBuilder.group({
      // gerenciaId: [null, [Validators.required]],
      gerenciaId: [null, [Validators.required]],
      procesoId: [null, [Validators.required]],
      documentoId: [null, [Validators.required]],
      numeroOrden: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(15),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      impuestoId: [null, [Validators.required]],
      formularioId: [null, [Validators.required]],
      periodo: [
        null,
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(2),
          Validators.min(1),
          Validators.max(12),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      anio: [
        null,
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(4),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      fechaVencimiento: [null, [Validators.required]],
      fechaNotificacion: [null],
      tributoOmitido: [
        null,
        [
          Validators.min(0),
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(10),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      multaUfv: [
        null,
        [
          Validators.min(0),
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(10),
          Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
        ],
      ],
      sancion: [
        0,
        [
          Validators.min(0),
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(10),
          Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
        ],
      ],
      agravante: [
        0,
        [
          Validators.min(0),
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(10),
          Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
        ],
      ],
      contravencionId: [null, Validators.required],
      asientoId: [null, [Validators.required]],
      documentoAgrupadorId: [null],
      numeroDocumentoAgrupador: [
        null,
        [
          Validators.minLength(1),
          Validators.maxLength(15),
          Validators.min(1),
          Validators.pattern(ExpresionRegularEnum.Numeros),
        ],
      ],
      selectOpcion: [null, [Validators.required]],
      congelarRd: [false],
    });
  }

  // listarDetalleDeudas(): void {
  //   this.tablaCargando = true;
  //   this.otrService
  //     .obtenerDetalleDeudasPorNitCUr(this.contribuyente.nit!)
  //     .then((respuesta: RespuestaDetalleDeudas) => {
  //       if (respuesta.transaccion) {
  //         this.dataSource.data = respuesta.data ?? [];
  //         this.dataSource.data.sort
  //       } else {
  //         this.dataSource.data = [];
  //         this.toastr.info(
  //           respuesta.mensajes
  //             ? respuesta.mensajes[0].descripcion
  //             : MensajeConstante.MSG_ERROR
  //         );
  //       }
  //       setTimeout(() => {
  //         this.loading = false;
  //       }, 700)
  //       this.tablaCargando = false;
  //     });
  // }

  listarDetalleDeudas(): void {
    this.tablaCargando = true;
    const vSolicitud = {
      nitCur: this.contribuyente.nit!,
      origenId: 270,
      oficinaId: this.contribuyente.administracion
    }


    this.otrService
      .obtenerDetalleDeudasPorNitCUr(vSolicitud)
      .then((respuesta: RespuestaLista<DeudaGenericaDetalle>) => {
        if (respuesta.transaccion) {
          this.dataSource.data = respuesta.objetosList ?? [];
          this.dataSource.data.sort
        } else {
          this.dataSource.data = [];
          this.toastr.info(
            respuesta.mensajes
              ? respuesta.mensajes[0].descripcion
              : MensajeConstante.MSG_ERROR
          );
        }
        setTimeout(() => {
          this.loading = false;
        }, 700)
        this.tablaCargando = false;
      });
  }

  obtenerParametricas() {
    this.formGenerarDeuda.get('gerenciaId')?.setValue(this.tipoGerencia[0]);
    const parametros: ParametroModel = {
      parametricas: {
        parametricas: `${ParametricasEnum.proceso_id},${ParametricasEnum.documento_id}`,
        asientos: `${ParametricasEnum.asiento_id}`,
        contravenciones: `${ParametricasEnum.contravencion_id}`,
      },
    };
    this.parametricaService.obtenerParametricas(parametros).then(() => {
      this.parametricaSubscription =
        this.parametricaService.dataModel$.subscribe((parametrica: any) => {
          this.tipoProceso = parametrica.proceso_id ?? [];

          this.tipoDocumento = parametrica.documento_id ?? [];
          this.tipoDocumento.forEach((item) => {
            if (item.id === 6060) {
              item.descripcion = "RESOLUCIÓN DETERMINATIVA"
            }
            return item
          });

          const documento_id = [
            {
              "id": 7013,
              "descripcion": "MULTA INCUMPLIMIENTO AL DEBER FORMAL",
            },
            {
              "id": 7532,
              "descripcion": "ORDEN DE VERIFICACIÓN EXTERNA IGF",
            },
            {
              "id": 7533,
              "descripcion": "ORDEN DE VERIFICACIÓN EXTERNA CEDEIM",
            },
            {
              "id": 7525,
              "descripcion": "ACTA DE INFRACCIÓN POR NO EMISIÓN DE FACTURA",
            },
          ];
          this.tipoDocumento = [
            ...this.tipoDocumento, ...documento_id
          ]

          this.tipoDocumento2 = this.tipoDocumento;
          if (this.tipoDocumento.length === 0) {
            this.toastr.info(
              'No se encontraron valores parametricos para documento'
            );
          }

          this.tipoOficina = parametrica.oficina ?? [];
          this.oficinasFiltrado = this.tipoOficina.slice();

          this.tipoAsiento = parametrica.transaccion ?? [];
          this.asientosFiltrado = this.tipoAsiento.map(
            (item: ParametricaGenericaModel) => {
              item.descripcion = `${item.descripcion}`;
              return item;
            }
          );
          this.asientosFiltrado = this.tipoAsiento.slice();
          if (this.tipoAsiento.length === 0) {
            this.toastr.info('No se encontraron valores parametricos asiento');
          }
          this.tipoAsiento = parametrica.transaccion ?? [];

        });
    });
  }

  obtenerProcesoFiltrado(): void {
    this.tipoDocumentoFiltrado = []
    this.tipoProcesoFiltrado = [];
    this.asientosFiltrado2 = [];

    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'ufv') {
      this.asientosFiltrado2 = this.tipoAsiento.filter(item => item.id === 106);
      this.tipoProcesoFiltrado = this.tipoProceso.filter((item: any) => {
        if (
          item.id == ParProcesoEnum.PROCESO_AUTO_INICIAL_DE_SUMARIO_CONTRAVENCIONAL ||//298
          item.id == ParProcesoEnum.PROCESO_MULTA_INCUMPLIMIENTO_DEBER_FORMAL ||//81
          item.id == ParProcesoEnum.PROCESO_INFRACCION//127
        ) {
          this.UfvRegistro++;
          return item;
        }
      });

      /* IMPUESTO */
      const impuesto = this.tipoImpuesto.filter(item => item.impuesto === 8)
      this.tipoImpuesto2 = impuesto.map((item: ImpuestoModel) => {
        item.descripcionLarga = `${item.impuesto} - ${item.descripcion}`;
        return item;
      });
      this.impuestosFiltrado = this.tipoImpuesto2.slice();

      /* DOCUMENTO AGRUPADOR */
      const idsPermitidos = [354, 6079, 7520, 7531, 7504, 7532, 7533, 7012, 6060]; //7013 7532 7533

      const filtradosdoc2 = this.tipoDocumento2.filter(doc =>
        idsPermitidos.includes(doc.id)
      );
      console.log("filtrados ", filtradosdoc2);


      this.tipoDocumentoFiltrado2 = filtradosdoc2.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado2 = filtradosdoc2.slice();

    }

    if (tipoDeuda === 'bs') {
      this.asientosFiltrado2 = this.tipoAsiento.filter(item => item.id === 110);
      this.tipoProcesoFiltrado = this.tipoProceso.filter((item: any) => {
        if (
          item.id == ParProcesoEnum.PROCESO_ORDEN_FISCALIZACION_EXTERNA ||
          item.id == ParProcesoEnum.PROCESO_ORDEN_VERIFICACION_INTERNA ||
          item.id == ParProcesoEnum.PROCESO_ORDEN_VERIFICACION_EXTERNA ||
          item.id == ParProcesoEnum.PROCESO_BAJA_DE_ACTIVO ||//363
          item.id == ParProcesoEnum.PROCESO_ACTA_DE_INFRACCIÓN_POR_NO_EMISIÓN_DE_FACTURA//364
        ) {
          this.BsRegistro++;
          return item;
        }
      });

      /* DOCUMENTOS */
      const idsPermitidos = [7504, 7531, 7520, 7532, 7533, 7090, 7525];

      const filtrados = this.tipoDocumento.filter(doc =>
        idsPermitidos.includes(doc.id)
      );
      console.log("filtrados ", filtrados);


      this.tipoDocumentoFiltrado = filtrados.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado = filtrados.slice();
    }


    if (tipoDeuda === 'usd') {
      this.asientosFiltrado2 = this.tipoAsiento.filter(item => item.id === 110);
      this.tipoProcesoFiltrado = this.tipoProceso.filter((item: any) => {
        if (
          item.id == ParProcesoEnum.PROCESO_ORDEN_VERIFICACION_EXTERNA//80    
        ) {
          this.UsdRegistro++;
          return item;
        }
      });

      const idsPermitidos = [7532];

      const filtrados = this.tipoDocumento.filter(doc =>
        idsPermitidos.includes(doc.id)
      );


      this.tipoDocumentoFiltrado = filtrados.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado = filtrados.slice();

      /* IMPUESTO */
      const impuesto = this.tipoImpuesto.filter(item => item.impuesto === 22)
      this.tipoImpuesto2 = impuesto.map((item: ImpuestoModel) => {
        item.descripcionLarga = `${item.impuesto} - ${item.descripcion}`;
        return item;
      });
      this.impuestosFiltrado = this.tipoImpuesto2.slice();
    }

    if (
      this.UfvRegistro === this.tipoProcesoFiltrado.length ||
      this.BsRegistro === this.tipoProcesoFiltrado.length ||
      this.UsdRegistro === this.tipoProcesoFiltrado.length
    ) {
      this.procesosFiltrado = this.tipoProcesoFiltrado.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
    } else {
      this.procesosFiltrado = this.tipoProcesoFiltrado.slice();
    }
    this.asientoImpuestoSelect();
  }


  documentoImpuestoSelect() {
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'ufv') {
      var documenntoId = this.formGenerarDeuda.get('documentoId')?.value;
      const impuesto = this.tipoImpuesto.filter(item => item.impuesto === 8)
      this.tipoImpuesto2 = impuesto.map((item: ImpuestoModel) => {
        item.descripcionLarga = `${item.impuesto} - ${item.descripcion}`;
        return item;
      });
      this.impuestosFiltrado = this.tipoImpuesto2.slice();
    }

    if (tipoDeuda === 'bs') {
      var documenntoId = this.formGenerarDeuda.get('documentoId')?.value;
      if (parseInt(documenntoId) === 7525) {
        const impuesto = this.tipoImpuesto.filter(item => item.impuesto === 8)
        this.tipoImpuesto2 = impuesto.map((item: ImpuestoModel) => {
          item.descripcionLarga = `${item.impuesto} - ${item.descripcion}`;
          return item;
        });
        this.impuestosFiltrado = this.tipoImpuesto2.slice();
      } else {
        const impuesto = this.tipoImpuesto;

        this.tipoImpuesto2 = impuesto.map((item: ImpuestoModel) => {
          item.descripcionLarga = `${item.impuesto} - ${item.descripcion}`;
          return item;
        });
        this.impuestosFiltrado = this.tipoImpuesto2.slice();
      }

    }
  }

  procesoDocumentoSelect() {
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    var procesoId = this.formGenerarDeuda.get('procesoId')?.value;
    if (tipoDeuda === 'ufv') {
      if (parseInt(procesoId) === 127) {
        const idsPermitidos = [354];

        const filtrados = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );


        this.tipoDocumentoFiltrado = filtrados.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtrados.slice();
      }

      if (parseInt(procesoId) === 298) {
        // const idsPermitidos = [354, 6079, 7013];
        const idsPermitidos = [6079];

        const filtrados = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );


        this.tipoDocumentoFiltrado = filtrados.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtrados.slice();
      }
      if (parseInt(procesoId) === 81) {
        // const idsPermitidos = [354, 6079, 7013];
        const idsPermitidos = [7013];

        const filtrados = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );


        this.tipoDocumentoFiltrado = filtrados.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtrados.slice();
      }

    }

    /* BS */
    if (tipoDeuda === 'bs') {
      if (parseInt(procesoId) === 62) {

        const idsPermitidos = [7504];

        const filtradosdoc = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );


        this.tipoDocumentoFiltrado = filtradosdoc.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc.slice();
      }

      if (parseInt(procesoId) === 80) {

        const idsPermitidos = [7531, 7532, 7533];
        const filtradosdoc = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );
        this.tipoDocumentoFiltrado = filtradosdoc.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc.slice();
      }

      if (parseInt(procesoId) === 163) {
        const idsPermitidos = [7520];
        const filtradosdoc = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );
        this.tipoDocumentoFiltrado = filtradosdoc.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc.slice();
      }

      if (parseInt(procesoId) === 363) {

        const idsPermitidos = [7090];
        const filtradosdoc = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );
        this.tipoDocumentoFiltrado = filtradosdoc.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc.slice();
      }


      if (parseInt(procesoId) === 364) {

        const idsPermitidos2 = [7525];
        const filtradosdoc2 = this.tipoDocumento.filter(doc =>
          idsPermitidos2.includes(doc.id)
        );
        this.tipoDocumentoFiltrado = filtradosdoc2.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc2.slice();
      }
    }

    /* BS */
    if (tipoDeuda === 'usd') {
      if (parseInt(procesoId) === 80) {
        const idsPermitidos = [7532];
        const filtradosdoc = this.tipoDocumento.filter(doc =>
          idsPermitidos.includes(doc.id)
        );

        this.tipoDocumentoFiltrado = filtradosdoc.map(
          (item: ParametricaGenericaModel) => {
            item.descripcion = `${item.descripcion}`;
            return item;
          }
        );
        this.tipoDocumentoFiltrado = filtradosdoc.slice();
      }
    }
    this.formGenerarDeuda.get('documentoId')?.enable();
  }

  asientoImpuestoSelect(): void {
    this.tipoDocumentoFiltrado2 = [];
    const tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'bs') {
      const idsPermitidos = [7504, 7531, 7520, 7532, 7533];
      const filtrados = this.tipoDocumento2.filter(doc =>
        idsPermitidos.includes(doc.id)
      );


      this.tipoDocumentoFiltrado2 = filtrados.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado2 = filtrados.slice();
    }

    if (tipoDeuda === 'ufv') {
      const idsPermitidos = [7520, 7531, 7504, 7532, 7533, 7012, 6060];
      const filtrados = this.tipoDocumento2.filter(doc =>
        idsPermitidos.includes(doc.id)
      );

      this.tipoDocumentoFiltrado2 = filtrados.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado2 = filtrados.slice();
    }

    if (tipoDeuda === 'usd') {

      const idsPermitidos = [7532];
      const filtrados = this.tipoDocumento2.filter(doc =>
        idsPermitidos.includes(doc.id)
      );
      this.tipoDocumentoFiltrado2 = filtrados.map(
        (item: ParametricaGenericaModel) => {
          item.descripcion = `${item.descripcion}`;
          return item;
        }
      );
      this.tipoDocumentoFiltrado2 = filtrados.slice();
    }
  }


  obtenerParametricaContravenciones(): void {
    this.parametricaService
      .obtenerContravenciones()
      .then((respuesta: RespuestaContravenciones) => {
        this.tipoContravencion = respuesta.objetosList ?? [];
        this.contravencionesFiltrado = this.tipoContravencion.map(
          (item: ParContravencionesModel) => {
            item.descripcion = `${item.codigoContravencion} - ${item.descripcion}`;
            return item;
          }
        );
        this.contravencionesFiltrado = this.tipoContravencion.slice();
        if (this.tipoContravencion.length === 0) {
          this.toastr.info(
            'No se encontraron valores parametricos Contravenciones'
          );
        }
      });
  }

  changeContravencion($event: any): void {

    //723 -> Natural - 1
    //722 -> Juridico - 2
    this.contravencionId = $event.value.id;
    if (this.contribuyente.tipoContribuyenteId === TipoContribuyenteIdEnum.NATURAL) {
      this.formGenerarDeuda.get('multaUfv')?.setValue($event.value.naturalUfv);
    }

    if (this.contribuyente.tipoContribuyenteId === TipoContribuyenteIdEnum.JURIDICA) {
      this.formGenerarDeuda.get('multaUfv')?.setValue($event.value.juridaUfv);
    }

    this.formGenerarDeuda.get('multaUfv')?.enable();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  clearFilter(): void {
    this.dataSource.filter = '';
  }

  obtenerImpuestos() {
    this.ddjjService
      .obtenerImpuestos()
      .then((respuesta: RespuestaImpuestos) => {
        this.tipoImpuesto = respuesta.objetosList;
      });
  }

  obtenerFormularios() {
    this.formGenerarDeuda.get('formularioId')!.reset(null);
    const impuesto: ImpuestoModel = {
      id: this.formGenerarDeuda.value.impuestoId,
    };

    this.ddjjService
      .obtenerFormularios(impuesto)
      .then((respuesta: RespuestaFormulario) => {
        if (respuesta.transaccion) {
          this.tipoFormulario = respuesta.objetosList.map(
            (item: FormularioModel) => {
              item.descripcionLarga = `${item.formulario} - ${item.formularioDescripcion}`;
              return item;
            }
          );
          this.formulariosFiltrado = this.tipoFormulario.slice();

          if (this.tipoFormulario.length > 0) {
            this.formGenerarDeuda.get('formularioId')!.enable();
          } else {
            this.formGenerarDeuda.get('formularioId')!.disable();
          }
        } else {
          var mensajes = respuesta.mensajes ? respuesta.mensajes : [];
          this.toastr.info(
            respuesta.mensajes
              ? respuesta.mensajes[0].descripcion
              : MensajeConstante.MSG_ERROR
          );
        }
      })
      .catch(() => {
        this.tipoFormulario = [];
      });
  }

  generarDeuda2() {
    this.btnLoading = true;
    setTimeout(() => {
      this.btnLoading = false;
    }, 1000);
  }

  generarDeuda() {
    const tipoDeuda = this.tipoDeuda.value;
    if (this.formGenerarDeuda.valid) {
      const propiedadesMensajeConfirmacion: ConfirmarDialogModel = {
        content:
          MensajesGenericoEnum.ADICION_DEUDA +
          MensajesGenericoEnum.ADICION_DEUDA2,
      };

      const dialogRef = this.dialog.open(SccConfirmDialogComponent, {
        disableClose: true,
        width: '350px',
        data: propiedadesMensajeConfirmacion,
      });

      dialogRef.afterClosed().subscribe((respuesta: boolean) => {
        if (respuesta) {
          if (this.formGenerarDeuda.value.selectOpcion === 'ufv') {
            this.generarDeudaUFV();
          }
          if (this.formGenerarDeuda.value.selectOpcion === 'bs') {
            this.generarDeudaBS();
          }
          if (this.formGenerarDeuda.value.selectOpcion === 'usd') {
            this.generarDeudaUSD();
          }
        }
      });
    }
  }

  generarDeudaUFV() {
    this.btnLoading = true;
    const datosForm = this.formGenerarDeuda.value;
    const impuesto = this.tipoImpuesto.find(
      (item) => item.impuesto == datosForm.impuestoId
    );
    const formulario = this.tipoFormulario.find(
      (item) => item.formulario == datosForm.formularioId
    );

    let solicitud: SolicitudDeudaUfv = {
      nitCur: this.contribuyente.nit!,
      procesoId: datosForm.procesoId,
      documentoId: Number(datosForm.documentoId),
      numeroOrdenDocumento: Number(datosForm.numeroOrden),
      impuestoId: Number(datosForm.impuestoId),
      formularioId: Number(datosForm.formularioId),
      impuesto: impuesto!.descripcion,
      formulario: formulario!.formularioDescripcion,
      periodo: parseInt(datosForm.periodo),
      anio: Number(datosForm.anio),
      fechaVencimiento: Fecha.toLocalDate(datosForm.fechaVencimiento),
      fechaNotificacion: Fecha.toLocalDate(datosForm.fechaNotificacion),
      multaUfv: this.formGenerarDeuda.get('multaUfv')!.value,
      contravencionId: this.contravencionId,
      asientoId: Number(datosForm.asientoId),
      origenId: 270,
      oficinaId: this.contribuyente.administracion!,
      numeroOrdenDocumentoAgrupador: datosForm.numeroDocumentoAgrupador,
      documentoAgrupadorId: datosForm.documentoAgrupadorId,
      tipoContribuyentePdrId: 0,
      tramiteId: 0,
      tipoContribuyenteId: this.contribuyente.tipoContribuyenteId!, //AJUSTAR DATOS CONTRIBUENTE
    };

    this._generarDeudaService
      .registrarDeudaGenericaUfv(solicitud)
      .then((respuesta: RespuestaDeudaGenerica) => {
        if (respuesta.transaccion) {
          this.toastr.success(
            MensajeConstante.MSG_NUMERO_DEUDA + respuesta.numeroDeuda
          );
          this.habilitarFormulario();
        } else {
          this.toastr.info(
            respuesta.mensajes
              ? respuesta.mensajes[0].descripcion
              : MensajeConstante.MSG_ERROR
          );
        }
        this.listarDetalleDeudas();
      })
      .catch(() => {
        this.toastr.info(MensajeConstante.MSG_ERROR);
      })
      .finally(() => {
        this.btnLoading = false;
      });
  }

  generarDeudaBS() {
    this.generarDeudaBsUsd(Number(MonedaEnum.BOLIVIANOS_ID), String(MonedaEnum.BOLIVIANOS));
  }
  generarDeudaUSD() {
    this.generarDeudaBsUsd(Number(MonedaEnum.DOLARES_ID), String(MonedaEnum.DOLARES));
  }

  generarDeudaBsUsd(monedaId: number, moneda: string): void {
    this.btnLoading = true;
    const datosForm = this.formGenerarDeuda.value;
    const impuesto = this.tipoImpuesto.find(
      (item) => item.impuesto == datosForm.impuestoId
    );
    const formulario = this.tipoFormulario.find(
      (item) => item.formulario == datosForm.formularioId
    );
    let solicitud: SolicitudDeudaBs = {
      nitCur: this.contribuyente.nit!,
      tramiteId: 0,
      impuestoId: Number(datosForm.impuestoId),
      formularioId: Number(datosForm.formularioId),
      impuesto: impuesto!.descripcion,
      formulario: formulario!.formularioDescripcion,
      documentoId: Number(datosForm.documentoId),
      numeroOrdenDocumento: Number(datosForm.numeroOrden),
      periodo: Number(datosForm.periodo),
      anio: Number(datosForm.anio),
      fechaVencimiento: Fecha.toLocalDate(datosForm.fechaVencimiento),
      fechaNotificacion: Fecha.toLocalDate(datosForm.fechaNotificacion),
      asientoId: Number(datosForm.asientoId),
      procesoId: datosForm.procesoId,
      origenId: 270,
      tributoOmitido: Number(datosForm.tributoOmitido),
      sancionPorcentaje: Number(datosForm.sancion) || 0,
      agravantePorcentaje: Number(datosForm.agravante) || 0,
      multaUfv: Number(datosForm.multaUfv),
      oficinaId: this.contribuyente.administracion!,
      numeroOrdenDocumentoAgrupador: datosForm.numeroDocumentoAgrupador,
      documentoAgrupadorId: datosForm.documentoAgrupadorId,
      tipoContribuyentePdrId: 0,
      monedaId: monedaId,
      moneda: moneda,
    };

    this._generarDeudaService
      .registrarDeudaGenericaBsUsd(solicitud)
      .then((respuesta: RespuestaDeudaGenerica) => {
        if (respuesta.transaccion) {
          this.toastr.success(
            MensajeConstante.MSG_NUMERO_DEUDA + respuesta.numeroDeuda
          );
          if (datosForm.congelarRd && respuesta.numeroDeuda > 0) {
            this.congelarRD(respuesta.numeroDeuda);
          }
        } else {
          this.toastr.info(
            respuesta.mensajes
              ? respuesta.mensajes[0].descripcion
              : MensajeConstante.MSG_ERROR
          );
        }
      })
      .catch(() => {
        this.toastr.info(MensajeConstante.MSG_ERROR);
      })
      .finally(() => {
        this.btnLoading = false;
        this.habilitarFormulario();
        this.listarDetalleDeudas();
      });
  }

  congelarRD(pDeudaId: number): void {
    const datosForm = this.formGenerarDeuda.value;
    const vSolicitud: SolicitudDeudaMontoCongelarRd = {
      deudaId: pDeudaId,
      nitCur: this.contribuyente.nit,
      documentoId: datosForm.documentoId,
      documentoAgrupadorId: datosForm.documentoAgrupadorId,
      procesoId: datosForm.procesoId,
      origenId: 270,
      montoDeudaBs: Number(datosForm.tributoOmitido),
    }
    this._generarDeudaService
      .deudaMontoCongelarRd(vSolicitud)
      .then((respuesta: Respuesta) => {
        if (respuesta.transaccion) {
          this.toastr.success("Vista de Cargo / Rd");
        }
      });
  }

  validarCampo(campo: string, label: string, maxlength?: number) {
    return new validarCampoFormulario().validarCampo(
      this.formGenerarDeuda,
      campo,
      label,
      maxlength
    );
  }

  validarCamposGenerarDeuda(): void {
    this.formGenerarDeuda.get('documentoId')?.disable();
    this.formGenerarDeuda.get('procesoId')?.reset();
    this.obtenerProcesoFiltrado();
    setTimeout(() => {
      this.validarCampoTributoOmitido();
      this.validarCampoSancion();
      this.validarCampoAgravante();
      this.validarCampoContravencion();
      this.validarCampoMultaUFV();
      this.validarCampoImpuestoFormulario();
    }, 500);
  }
  validarCampoTributoOmitido(): void {
    const campoControl = this.formGenerarDeuda.get('tributoOmitido')!;
    campoControl.setValue('');
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'bs' || tipoDeuda === 'usd') {
      campoControl.setValidators([
        Validators.required,
        Validators.min(0),
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
      ]);
      campoControl.enable();
    }

    if (tipoDeuda === 'ufv') {
      campoControl.clearValidators();
      campoControl.disable();
    }
    campoControl.updateValueAndValidity();
  }

  validarCampoSancion(): void {
    const campoControl = this.formGenerarDeuda.get('sancion')!;
    campoControl.setValue(0);
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'bs' || tipoDeuda === 'usd') {
      campoControl.setValidators([
        Validators.min(0),
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
      ]);
      campoControl.enable();
    }

    if (tipoDeuda === 'ufv') {
      campoControl.clearValidators();
      campoControl.disable();
    }
    campoControl.updateValueAndValidity();
  }

  validarCampoAgravante(): void {
    const campoControl = this.formGenerarDeuda.get('agravante')!;
    campoControl.setValue(0);
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'bs' || tipoDeuda === 'usd') {
      campoControl.setValidators([
        Validators.min(0),
        Validators.minLength(1),
        Validators.maxLength(10),
        Validators.pattern(ExpresionRegularEnum.NumerosConDosDecimales),
      ]);
      campoControl.enable();
    }

    if (tipoDeuda === 'ufv') {
      campoControl.clearValidators();
      campoControl.disable();
    }
    campoControl.updateValueAndValidity();
  }
  validarCampoContravencion(): void {
    const campoControl = this.formGenerarDeuda.get('contravencionId')!;
    campoControl.setValue('');
    var tipoDeuda = this.formGenerarDeuda.value.selectOpcion;
    if (tipoDeuda === 'bs' || tipoDeuda === 'usd') {
      campoControl.clearValidators();
      campoControl.disable();
      this.formGenerarDeuda.get('multaUfv')!.reset();
    }

    if (tipoDeuda === 'ufv') {
      campoControl.setValidators([Validators.required]);
      campoControl.enable();
    }
    campoControl.updateValueAndValidity();
  }

  validarCampoMultaUFV(): void {
    const campoControl = this.formGenerarDeuda.get('multaUfv')!;
    campoControl.clearValidators();
    campoControl.disable();
  }

  validarCampoImpuestoFormulario(): void {
    this.formGenerarDeuda.get('impuestoId')!.reset();
    this.formGenerarDeuda.get('formularioId')!.reset();
    this.formGenerarDeuda.get('formularioId')!.disable();
  }

  habilitarFormulario(): void {
    this.formGenerarDeuda.reset();
    this.formGenerarDeuda.markAsUntouched();
    this.formGenerarDeuda.markAsPristine();
  }

  seleccionarAnio(event: any): void {
    this.formGenerarDeuda.get('anio')?.setValue(event);
  }

  ngOnDestroy(): void {
    if (this.parametricaSubscription) {
      this.parametricaSubscription.unsubscribe();
    }
  }

  ngAfterViewChecked() {
    if (!this.paginatorAsignado && this.paginator && this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.paginatorAsignado = true;
    }
  }
}
