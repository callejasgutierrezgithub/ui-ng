import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

import {
  DialogMessageServiceComponent,
  LayoutComponent,
  LoadingComponent,
} from 'core-lib';

import { NgxSpinnerModule } from 'ngx-spinner';
import { TestContextService } from './services/test-context.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    LayoutComponent,
    DialogMessageServiceComponent,
    LoadingComponent,
    NgxSpinnerModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
})
export class AppComponent {
  titleApp: string = 'SUBSISTEMA DE CUENTA CORRIENTE';
  subAplicacionId: number = 10622; //Sub aplicacionId de su proyecto para mostrar en menu de opciones

  constructor(
    private contextService: TestContextService,
    private router: Router
  ) { }
  async ngOnInit() {
    await this.contextService.obtenerDatos();
  }

  get isErrorPage(): boolean {
    return this.router.url === '/error';
  }
}
