export enum ExpresionRegularEnum {
  Alfanumerico = '[a-zA-ZñÑ0-9áéúíóÁÉÚÍÓ \\.,]*',
  Numeros = '[0-9]*',
  //NumerosConDosDecimales = '^\d+(\,\d{1,2})?$'
 //NumerosConDosDecimales = '^([0-9])+([.][0-9])+([.][0-9])+([,][0-9]{1,2})?$',
 NumerosConDosDecimales = '^[0-9]+([.][0-9]{1,2})?$',
}
