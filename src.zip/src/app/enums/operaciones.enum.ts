export enum Operacion {
  CREATE = 'CREATE',
  READ = 'READ',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
}

export type Operaciones = keyof typeof Operacion;

export enum FormatoFechaEnum {
  YYYYMMDD,
}
