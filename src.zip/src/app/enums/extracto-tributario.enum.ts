export enum MovimientoEnum {
  ASIENTO_19 = 19,
}

export enum MonedaEnum {
  BOLIVIANOS_ID = 688,
  BOLIVIANOS = "BOLIVIANO",
  DOLARES_ID = 689,
  DOLARES = "DOLAR",
}

export enum ConusltaIdEnum {
  DEUDAS_CONTRIBUYENTE = 331,
}

export enum ExtractoEnum {
  DEBE = 361,
  HABER = 362,
  RESTAR_EXTRACTO = 359
}