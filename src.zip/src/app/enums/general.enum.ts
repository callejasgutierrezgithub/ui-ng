export enum MensajesGenericoEnum {
  REFERENCIA = 'Se eliminara el registro:',
  ADICION = '¿Está seguro/a de registrar la información?',
  MODIFICAR = '¿Está seguro/a de registrar la información?',
  ELIMINAR = '¿Está seguro/a de eliminar?',

  ADICION_DEUDA = '¿Está seguro/a de registrar el componente ?.',
  VERIFICACION_BOLETA_PAGO = 'Verifico que el archivo PDF corresponda a la Boleta de Pago seleccionada',
  VERIFICACION_BOLETA_PAGO_DESCRIPCION = 'Es responsabilidad del usuario la verificación del archivo que corresponda a la Boleta que está siendo procesada',

  ADICION_DEUDA2 = 'Una vez registrado no se puede revertir la generación del santificador de deuda',
  RegistroCreado = 'Registro adicionado con exito',
  RegistroActualizado = 'Registro actualizado con exito',

  REDIS = 'Registro de parametricas en REDIS',
}

export enum MovimientoEnum {
  DEBE = 56,
  HABER = 55,
}

export enum MonedaEnum {
  BOLIVIANOS_ID = 688,
  BOLIVIANOS = "BOLIVIANO",
  DOLARES_ID = 689,
  DOLARES = "DOLAR",
}

export enum ConusltaIdEnum {
  DEUDAS_CONTRIBUYENTE = 331,
}


export enum EstadoPagoIdEnum {
  VIGENTE = 271,
  VIGENTE_HISTORICO = 272,
  REVERTIDO = 273,
}