export enum TipoUsuarioIdEnum {
  FUNCIONARIO = 861,
  CONTRIBUYENTE = 862
}