export enum TipoContribuyenteIdEnum {
  NATURAL = 723,
  JURIDICA = 722
}