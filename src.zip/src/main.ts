import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));

// document.addEventListener('keydown', function (event) {
//   if (
//     event.key === 'F12' ||
//     (event.ctrlKey && event.shiftKey && event.key === 'I') ||
//     (event.ctrlKey && event.key === 'U')
//   ) {
//     event.preventDefault();
//   }
// });